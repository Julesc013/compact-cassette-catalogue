Private Sub btnSearch_Click Handles btnSearch.Click

	'search archive from this year back to MAXYEAR years in the past
	For each i = CURRENTYEAR - MAXYEAR to CURRENTYEAR'(CY = Date.Today.Year - 2019)

		totalShifts = 0
		totalHours = 0
		earliestStart = convertTime("12:00 PM", "integer")
		latestEnd = convertTime("06:00 AM", "integer")

		'if MAXYEARs have not elapsed since 2019, search from oldest archive
		If i < 0 then
			i = 0
		end if

		if "rosterY[i]W[*any*]" exists then

			for each j = 0 to 52

				if "rosterY[i]W[j]" exists then

					Try

						'try to open the file
						Open Excel Application
						Open "rosterY[i]W[j]" Workbook
						Open primary Worksheet as shtSearch
						
						for each k = 1 to 7

							for each record in sheet

								if name field = cmbEmployeeSearch text 'if we find a match

									results.year add i
									results.week add j
									results.date add k header in sheet
									results.timeStart add convertTime(corresponding shift field substring(first half), "integer")
									results.timeEnd add convertTime(corresponding shift field substring(second half), "integer")

									add "i & j & k & timeStart & timeEnd" to lstShiftsWorked

									increment totalShifts
									totalHours add on (timeEnd - timeStart)
									if timeStart is earlier than earliestStart then
										earliestStart = timeStart
									end If
									if timeEnd is later than latestEnd then
										latestEnd = timeEnd
									end if

								end if

							end for

						end for
						
						'clean up and close files
						releaseObject(excel app)
						releaseObject(workbook)
						releaseObject(worksheet)

					Catch
						Display error message
					
					End Try

				end if

			end for

		end if

	end for

	'populate text boxes
	populate every text-box with corresponding data

	'enable buttons
	btnSortResults enabled = true
	btnSaveResults enables = true

End Sub