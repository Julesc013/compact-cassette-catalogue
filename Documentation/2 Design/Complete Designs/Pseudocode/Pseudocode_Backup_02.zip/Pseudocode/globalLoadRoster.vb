sub loadRoster(fileName)

	If fileName excel file exists

		Try
			
			Open Excel Application
			Open fileName Workbook
			Open primary Worksheet as shtRoster
			
			For i = 1 to 7 'for each day of the week
				For j = 1 to 2 * MAXSTAFF 'for each staff box (*2 for shift box)
					
					'load data into combination boxes
					colDay(i)(2 * j).Text = shtRoster.Cells(i, 2 * j)
					colDay(i)(2 * j + 1).Text = shtRoster.Cells(i, 2 * j + 1)
					
				End For
			End For
			
			'clean up and close files
			releaseObject(excel app)
			releaseObject(workbook)
			releaseObject(worksheet)

		Catch
			Display error message
		
		End Try
		
	Else

		Display "no roster to load" message
		
	End If

End Sub
