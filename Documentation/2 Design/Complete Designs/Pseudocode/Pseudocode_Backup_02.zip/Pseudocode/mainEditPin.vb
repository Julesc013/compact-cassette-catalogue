Private Sub btnEditPin_Click Handles btnEditPin.Click

	Try
			
		Open Excel Application
		Open PINDATA Workbook
		Open primary Worksheet as shtPins
		
		pinTry = inputBox 'verify existing password
		pinReal = shtPins.Cells(1, userGroup)

		If pinTry = pinReal Then

			pinNew = inputBox 'get new password
			pinRedo = inputBox 're-enter new password
			
			While pinNew <> pinRedo
			
				'if password mismatch, re-get
				pinNew = inputBox 'get new password
				pinRedo = inputBox 're-enter new password
			
			End While

			If pinNew = pinRedo
				
				shtPins.Cells(1, userGroup) = pinNew 'set new password
				show success message

			Else
				
				show failed message
				
			End If

		Else

			show incorrect message

		End If
		
		'clean up and close files
		releaseObject(excel app)
		releaseObject(workbook)
		releaseObject(worksheet)

	Catch
		Display error message

	End Try

End Sub
