Private Sub btnAddData_Click Handles btnAddData.Click

    selected = lstNameFirst.SelectedIndex 'modify the currently selected person

    'get data from user
    phoneNumberNew = input box
    while phoneNumberNew does not match regexPhone
        phoneNumberNew = input box
    end while

    emailAddressNew = input box
    while emailAddressNew does not match regexEmail
        emailAddressNew = input box
    end while

    openCloseNew = input box
    while openCloseNew is not boolean
        openCloseNew = input box
    end while

    colourCodeNew = input box
    while colourCodeNew is not in list colours() 'if not a recognised colour that can become a byte code...
        colourCodeNew = input box
    end while


    'add all data to internal record structure
    overwrite employeeData(selected).phoneNumber = phoneNumberNew
    overwrite employeeData(selected).emailAddress = emailAddressNew
    overwrite employeeData(selected).openClose = openCloseNew
    overwrite employeeData(selected).colourCode = colourCodeNew

    'add all to external sheet
    shtData.Cells(3, selected + 1) = employeeData(selected).phoneNumber
    shtData.Cells(4, selected + 1) = employeeData(selected).emailAddress
    shtData.Cells(5, selected + 1) = employeeData(selected).openClose
    shtData.Cells(7, selected + 1) = employeeData(selected).colourCode

    'add all to list box
    overwrite lstPhoneNumber(selected) = employeeData(selected).phoneNumber
    overwrite lstEmailAddress(selected) = employeeData(selected).emailAddress = emailAddress
    overwrite lstOpenClose(selected) = employeeData(selected).openClose = openClose
    'no listbox for colour codes

End Sub