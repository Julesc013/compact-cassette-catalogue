Private Sub btnSaveResults_Click Handles btnSaveResults.Click

	show dlgSaveResuts and get filePath

    try

        create/overwrite text file

        'write header
        write "Search results" & date & time
        write cmbEmployeeSearch text 'employee's name
        
        for each item in results()
            write "year & week & date & timeStart & timeEnd"
        end for

        write "Employee statistics:"
        write totalShifts, totalHours, earliestStart, latestEnd

        close text file

    except
        show error message

    end try

End Sub
