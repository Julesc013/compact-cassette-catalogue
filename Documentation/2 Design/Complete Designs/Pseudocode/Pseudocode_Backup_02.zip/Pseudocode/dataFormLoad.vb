Private Sub frmData_Load Handles frmData.Load

	if EMPLOYEEDATA does not exist then

		try

			Create Workbook
			Open primary Worksheet as shtData

		Catch
			Display error message
		
		End Try

	else

		try

			Open Excel Application
			Open EMPLOYEEDATA Workbook
			Open primary Worksheet as shtData

			shiftCount = 0 'reset each time form is loaded

			'populate list box
			for each record in shifts structure
				lstNameFirst add (employeeData(index).nameFirst)
				lstNameLast add (employeeData(index).nameLast)
				... 'inclusive except for "colourCode" and the "availability" array
				lstAvailabilityStored add (employeeData(index).availabilityStored)

				increment dataCount by 1
			end for

			'leave file open for use in the form

		Catch
			Display error message
		
		End Try

	end if

End Sub
