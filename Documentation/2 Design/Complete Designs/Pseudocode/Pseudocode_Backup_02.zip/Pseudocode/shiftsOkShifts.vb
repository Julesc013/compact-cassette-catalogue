Private Sub btnRemoveShifts_Click Handles btnRemoveShift.Click

    'clean up and close files
    releaseObject(excel app)
    releaseObject(workbook)
    releaseObject(worksheet)

    close frmShifts

End Sub