Private Sub cmbStaff[Weekday][#]_IndexSelected Handles cmbStaff[Weekday][#].IndexSelected

    comboBox text colour = employeeData(name) colour field value

End Sub
