Private Sub frmShifts_Load Handles frmShifts.Load

	if SHIFTDATA does not exist then

		try

			Create Workbook
			Open primary Worksheet as shtShifts

		Catch
			Display error message
		
		End Try

	else

		try

			Open Excel Application
			Open SHIFTDATA Workbook
			Open primary Worksheet as shtShifts

			shiftCount = 0 'reset each time form is loaded

			'populate list box
			for each record in shifts structure
				lstShifts add (shifts.startTime and shifts.endTime)

				increment shiftCount
			end for

			'leave file open for use in the form

		Catch
			Display error message
		
		End Try

	end if

End Sub
