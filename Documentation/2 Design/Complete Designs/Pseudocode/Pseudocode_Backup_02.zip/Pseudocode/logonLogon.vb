Private Sub btnLogon_Click Handles btnLogon.Click

	'figure out whose PIN to use
	if cmbUserLogon text = "Owner" then
					frmMain.userGroup = 1
				else
					frmMain.userGroup = 2
				end if

	If PINDATA file does not exist then

		initialise Excel object

		If excel is installed

			Create Workbook
			Open primary Worksheet

			PinNew = input box 'ask for new PIN

			while not 4 charaters long and only numbers
				PinNew = input box 'ask again
			end while

			shtPins.Cells("A", usergroup) = PinNew

			close files

			'logon now
			show main form
			close this form

		Else

		Display "excel not installed" "Cannot log on" message
		
		End If

	else

		Open PINDATA Workbook
		Open primary Worksheet
		
		PinReal = shtPins.Cells(1, userGroup)
		PinTry = txtPinLogon text
		
		close files

		if PinReal = PinTry then
			'logon
			show frmMain
			close this form
		else
			display PIN wrong message
		end if

	end If
	
End Sub
