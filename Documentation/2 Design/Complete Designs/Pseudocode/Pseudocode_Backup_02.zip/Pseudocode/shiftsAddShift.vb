Private Sub btnAddShifts_Click Handles btnAddShift.Click

    'get times from user
    startTime = input box
    while startTime does not match regexTime
        startTime = input box
    end while

    endTime = input box
    while endTime does not match regexTime or endTime earlier than startTime
        endTime = input box
    end while
    If endTime is past midnight then
        endTime = "close"
    end If

    'add to internal record structure
    add new shifts.startTime = startTime converted to integer
    add new shifts.endTime = endTime converted to integer
    'add to external sheet
    shtShifts.Cells(1, shiftCount) = shifts(shiftCount - 1).startTime
    shtShifts.Cells(2, shiftCount) = shifts(shiftCount - 1).endTime
    'add to list box
    lstShifts add (shifts(shiftCount - 1).startTime & shifts(shiftCount - 1).endTime)

    increment shiftCount by 1

End Sub