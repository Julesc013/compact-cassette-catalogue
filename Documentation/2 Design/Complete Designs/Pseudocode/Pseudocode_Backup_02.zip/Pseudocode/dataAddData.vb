Private Sub btnAddData_Click Handles btnAddData.Click

    'get data from user
    nameFirstNew = input box
    while nameFirstNew does not match regexName
        nameFirstNew = input box
    end while

    nameLastNew = input box
    while nameLastNew does not match regexName
        nameLastNew = input box
    end while

    phoneNumberNew = input box
    while phoneNumberNew does not match regexPhone
        phoneNumberNew = input box
    end while

    emailAddressNew = input box
    while emailAddressNew does not match regexEmail
        emailAddressNew = input box
    end while

    openCloseNew = input box
    while openCloseNew is not boolean
        openCloseNew = input box
    end while

    colourCodeNew = input box
    while colourCodeNew is not in list colours() 'if not a recognised colour that can become a byte code...
        colourCodeNew = input box
    end while

    availabilityStored = "Missing" 'by default... availability has not yet been entered


    'add all data to internal record structure
    add new employeeData(dataCount - 1).nameFirst = nameFirstNew
    add new employeeData(dataCount - 1).nameLast = nameLastNew
    ... 'etc
    add new employeeData(dataCount - 1).openClose = openCloseNew
    add new employeeData(dataCount - 1).availabilityStored = availabilityStoredNew
    add new employeeData(dataCount - 1).colourCode = colourCodeNew

    'add all to external sheet
    shtData.Cells(1, dataCount) = employeeData(dataCount - 1).nameFirst
    shtData.Cells(2, dataCount) = employeeData(dataCount - 1).nameLast
    ... 'etc
    shtData.Cells(5, dataCount) = employeeData(dataCount - 1).openClose
    shtData.Cells(6, dataCount) = employeeData(dataCount - 1).availabilityStored
    shtData.Cells(7, dataCount) = employeeData(dataCount - 1).colourCode

    'add all to list box
    lstNameFirst add employeeData(dataCount - 1).nameFirst
    lstNameLast add employeeData(dataCount - 1).nameLast
    ... 'etc
    lstAvailabilityStored add employeeData(dataCount - 1).availabilityStored
    'no listbox for colour codes

    increment dataCount by 1

End Sub