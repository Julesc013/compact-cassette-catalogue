Private Sub btnCancelAvailability_Click Handles btnCancelAvailability.Click

    close frmAvailability

End Sub