Private Sub btnSendRoster_Click Handles btnSendRoster.Click

    saveRoster("send") 'save roster to archive and as PDF

    for each employee in database
        'email PDF to employees
        sendEmail(employeeData(employee) email field value, "Weekly Roster [date and week number]", body of email)
    end for

    Delete file ROSTERSUGGESTED

    display summary message box (with option to close program)

    if chosen to close then
        close entire application
    end if

end sub