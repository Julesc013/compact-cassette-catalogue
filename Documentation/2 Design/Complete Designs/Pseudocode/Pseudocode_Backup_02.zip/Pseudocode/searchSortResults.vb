'Author: Adrian Janson
'Source: ISBN 978-0-9750764-6-0
'Modifications: TBD

Private Sub btnSortResults_Click Handles btnSortResults.Click

	quickSort(results, timeStart) 'results structure sorted by timeStart

    Clear lstShiftsWorked
    'repopulate listbox
    for each item in results()
        add "year & week & date & timeStart & timeEnd" to lstShiftsWorked
    end for

End Sub
