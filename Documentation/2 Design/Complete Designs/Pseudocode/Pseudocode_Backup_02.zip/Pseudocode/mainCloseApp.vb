Private Sub btnCloseApp_Click Handles btnCloseApp.Click

    if rosterSent = false then
        
        ask user if they want to quit without saving

        if they do then

            close entire application

        end if

    else

        close entire application

    end if

End Sub