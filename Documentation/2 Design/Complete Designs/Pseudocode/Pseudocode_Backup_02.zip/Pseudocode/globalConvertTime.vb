Public Function convertTime(time as string, mode as string) as integer

	if mode = "integer" then
		timeInt = time substring hours * 60 + time substring minutes
		if time substring suffix = "PM" then
			timeInt add 720
		end if
		
		return timeInt

	else
		timeStr = time / 60 rounded to whole & ":" & time % 60
		if time / 60 rounded > 11 then
			timeStr add " PM"
		else 
			timeStr add " AM"
		end if

		return timeStr

End Sub