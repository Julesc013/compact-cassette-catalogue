sub loadRoster(fileName)

	If fileName excel file exists

		Open Excel Application
		Open fileName Workbook
		Open primary Worksheet
		
		for each day of the week
			for each staff box in form 'MAXSTAFF is number of boxes
				
				load data into combination boxes
				
			End For
		End For
		
		close files
		
	Else

		Display "no roster to load" message
		
	End If

End Sub
