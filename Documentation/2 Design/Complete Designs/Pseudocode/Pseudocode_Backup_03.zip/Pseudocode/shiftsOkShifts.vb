Private Sub when ok button is clicked

    close files

    close Shifts form

End Sub