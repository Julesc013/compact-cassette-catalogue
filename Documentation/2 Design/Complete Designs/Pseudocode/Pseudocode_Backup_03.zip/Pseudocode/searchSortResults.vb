Private Sub when sort results button is clicked

	quickSort results by shift start time

    Clear shifts worked listbox
    
    'repopulate listbox
    for each item in sorted list
        add item to listbox
    end for

End Sub
