Public Function convertTime(time as string, mode as string) as integer

	if mode = "integer" then
		
		return time as number of minutes since midnight

	else

		return time as digital time 'eg 3:00 PM

End Sub