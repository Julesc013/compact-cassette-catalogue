Private Sub when cancel is clicked

    close Availability form

End Sub