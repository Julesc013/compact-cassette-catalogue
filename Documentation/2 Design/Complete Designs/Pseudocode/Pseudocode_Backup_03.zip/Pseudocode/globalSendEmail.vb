'Author: M.V.Rajasekhar
'Source: http://www.freevbcode.com/ShowCode.asp?ID=5486
'Modifications: Removed some parameters and modified attachment line.

Public Sub sendEmail(sendTo, subject, body, carbonCopy, blindCarbonCopy, smtpServer)

	With email
		Set input paramaters as varaibles for send main function

		If carbonCopy exists Then
			set carbon copy variable
		end if
		If blindCarbonCopy exists Then
			set blind Carbon Copy variable
		end if

		If ROSTERLATEST exists Then
			attach PDF roster file to email
		end if

	End With

	If smtpServer exists Then
		send email via smtp
	end if

	call send email built-in function

End Sub