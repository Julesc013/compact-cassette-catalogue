Private Sub when logon button pressed

	'figure out whose PIN to use
	set userGroup according to whose logged-on

	If PINDATA file does not exist then

		initialise Excel object

		If excel is installed

			Create Workbook
			Open primary Worksheet

			PinNew = input box 'ask for new PIN

			while not 4 charaters long and only numbers
				PinNew = input box 'ask again
			end while

			save PinNew to spreadsheet cell

			close files

			'logon now
			show main form
			close this form

		Else

		Display "excel not installed" "Cannot log on" message
		
		End If

	else

		Open PINDATA Workbook
		Open primary Worksheet
		
		get PinReal from spreadsheet
		
		close files

		if PinReal = pin entered at logon then
			'logon
			show frmMain
			close this form
		else
			display PIN wrong message
		end if

	end If
	
End Sub
