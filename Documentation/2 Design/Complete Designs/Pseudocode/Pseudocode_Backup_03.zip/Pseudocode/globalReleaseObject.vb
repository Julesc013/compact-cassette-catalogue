'Author: Net-informations.com
'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_create_file.htm
'Modifications: None.

Private Sub releaseObject(ByVal object As Object)
        
    release object
    set object to Nothing
    Call built-in garbage collection routine

End Sub