Private Sub when an employee name is selected

    enable edit/remove buttons when a name is selected

End Sub


Private Sub when employee name unselected

    disable edit/remove buttons when no name is selected

End Sub