Private Sub when Availability form loads

    'set up title label
    lblTitleAvailability = frmData.lstNameFirst.SelectedIndex & "'s Availability"

    populate all textboxes from internal record

End Sub