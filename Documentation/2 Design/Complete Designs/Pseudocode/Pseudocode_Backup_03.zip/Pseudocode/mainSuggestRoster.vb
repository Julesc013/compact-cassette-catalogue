Private Sub when suggest roster button is clicked

    saveRoster(ROSTERSUGGESTED)

End Sub
