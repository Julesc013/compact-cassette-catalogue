Private Sub when send roster button is clicked

    save roster to archive and save as PDF

    for each employee in database
        
        email PDF to employee

    end for

    Delete file ROSTERSUGGESTED

    display summary message box (with option to close program)

    if chosen to close then

        close entire application
        
    end if

end sub