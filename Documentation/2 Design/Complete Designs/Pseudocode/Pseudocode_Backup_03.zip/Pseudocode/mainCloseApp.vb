Private Sub when Close All button is pressed

    if rosterSent = false then
        
        ask user if they want to quit without saving

        if they do then

            close entire application

        end if

    else

        close entire application

    end if

End Sub