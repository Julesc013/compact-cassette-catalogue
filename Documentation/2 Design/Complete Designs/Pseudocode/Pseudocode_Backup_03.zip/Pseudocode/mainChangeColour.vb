Private Sub when an employee is selected

    comboBox text colour = stored employee colour

End Sub
