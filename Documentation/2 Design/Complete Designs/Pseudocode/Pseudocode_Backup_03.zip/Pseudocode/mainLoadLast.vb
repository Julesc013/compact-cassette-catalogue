Private Sub when Load Last Roster button is clicked

    load last weeks roster using subroutine

End Sub
