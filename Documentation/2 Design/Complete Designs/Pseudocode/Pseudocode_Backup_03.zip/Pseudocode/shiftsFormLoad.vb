Private Sub when shifts form is loaded

	if SHIFTDATA file does not exist then

		Create Workbook
		Open primary Worksheet

	else

		Open Excel Application
		Open SHIFTDATA Workbook
		Open primary Worksheet

		reset shiftCount 'set to 0 each time form is loaded

		for each record in shifts structure
			add record to list box
			increment shiftCount
		end for

		'leave file open for use in the form

	end if

End Sub
