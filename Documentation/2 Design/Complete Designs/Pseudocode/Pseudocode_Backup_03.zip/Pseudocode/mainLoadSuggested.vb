Private Sub when load suggested roster button is clicked

    load ROSTERSUGGESTED using subroutine

End Sub
