Private Sub when ok button is clicked

    populate employeeData from start/finish textboxes

    if validaton of every item succeeds then

        Open Excel Application
        Open EMPLOYEEDATA Workbook
        Open primary Worksheet
        
        Unprotect workbook using MASTERKEY

        write all items in to EMPLOYEEDATA sheet cells

        Protect workbook using MASTERKEY
        
        close files

        availabilityStored = "Submitted"

        close file

    else
        show error message

    end if

End Sub