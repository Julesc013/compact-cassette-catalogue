Private Sub when remove shift button is clicked

    delete from record structure
    delete from sheet
    remove from list box

    decrement shiftCount by 1

End Sub