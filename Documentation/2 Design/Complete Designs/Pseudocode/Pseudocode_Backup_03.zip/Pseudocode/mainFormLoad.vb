Private Sub when main form loads

	'show/hide neccessary elements
	if userGroup = 2

		hide function buttons that shouldnt be accessed by this user

		if roster not archived within this week then
			
			disable ability to send rosters
			
		end if

	else
		if ROSTERSUGGESTED exists then
			
			enable ability to load suggested roster

		end if

	end if

	add combo-boxes to 2D collection of objects

	if EMPLOYEEDATA exists then
			
		Open Excel Application
		Open EMPLOYEEDATA Workbook
		Open primary Worksheet
		
		Unprotect workbook using MASTERKEY

		'load in data from database
		for each record in file

			add data to internal record structure

		end for

		Protect workbook using MASTERKEY
		
		close files

	end if

	if SHIFTDATA exists then

		Open Excel Application
		Open SHIFTDATA Workbook
		Open primary Worksheet

		'load in data from database
		for each record in file

			add to shifts record structure

		end for
		
		close files

	end if

End Sub
