Private Sub when data form loads

	if EMPLOYEEDATA does not exist then

		Create Workbook
		Open primary Worksheet

	else

		Open Excel Application
		Open EMPLOYEEDATA Workbook
		Open primary Worksheet

		shiftCount = 0 'reset each time form is loaded

		'populate list box
		for each record in shifts structure

			populate all list boxes
			increment dataCount by 1
			
		end for

		'leave file open for use in the form

	end if

End Sub
