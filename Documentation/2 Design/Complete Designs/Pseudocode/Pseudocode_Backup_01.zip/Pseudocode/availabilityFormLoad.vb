Private Sub frmAvailability_Load Handles frmAvailability.Load

    'set up title label
    lblTitleAvailability = frmData.lstNameFirst.SelectedIndex & "'s Availability"

    populate all txt[Weekday][*] from internal record

End Sub
