Private Sub btnLoadLast_Click Handles btnLoadLast.Click

    loadRoster(suggested roster path)

End Sub
