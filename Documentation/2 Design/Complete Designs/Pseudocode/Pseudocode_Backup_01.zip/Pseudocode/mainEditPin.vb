Private Sub btnEditPin_Click Handles btnEditPin.Click

	Try
			
		Open Excel Application
		Open PINDATA Workbook
		Open primary Worksheet as shtPins
		
		passTry = inputBox 'verify existing password
		passReal = shtPins.Cells(1, userGroup)

		If passTry = passReal Then

			passNew = inputBox 'get new password
			passRedo = inputBox 're-enter new password
			
			While passNew <> passRedo
			
				'if password mismatch, re-get
				passNew = inputBox 'get new password
				passRedo = inputBox 're-enter new password
			
			End While

			If passNew = passRedo
				
				shtPins.Cells(1, userGroup) = passNew 'set new password
				show success message

			Else
				
				show failed message
				
			End If

		Else

			show incorrect message

		End If
		
		'clean up and close files
		releaseObject(excel app)
		releaseObject(workbook)
		releaseObject(worksheet)

	Catch
		Display error message

	End Try

End Sub
