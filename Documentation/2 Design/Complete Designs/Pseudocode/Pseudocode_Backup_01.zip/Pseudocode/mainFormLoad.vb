Private Sub frmMain_Load Handles frmMain.Load

	'show/hide neccessary elements
	if userGroup = 2
		btnLoadSuggested visible = false
		btnEditData visible = false
		btnEditShifts visible = false
		btnSearchArchive visible = false

		if roster not archived within this week then
			btnSendArchive enabled = false
		end if

	else
		if ROSTERSUGGESTED exists then
			btnLoadSuggested enabled = true
		end if

	end if

	'add combo-boxes to 2D collection of objects
	cmbThursday.Add(txtBoxTemp)
	cmbThursday.Add(txtBoxTemp)
	...

	cmbWeek.Add(cmbThursday)
	cmbWeek.Add(cmb...)

	if EMPLOYEEDATA exists then

		try

			Open Excel Application
			Open EMPLOYEEDATA Workbook
			Open primary Worksheet as shtData
			
			Unprotect workbook (using MASTERKEY)

			'load in data from database
			for each record in file
				'store from respective fields (columns in row)
				store firstName
				store lastName
				store phoneNumber
				store emailAddress
				store openClose
				store availabilityStored
				store colourCode
				store availability 'this is an array of record structures
			end for

			Protect workbook (using MASTERKEY)
			
			'clean up and close files
			releaseObject(excel app)
			releaseObject(workbook)
			releaseObject(worksheet)

		Catch
			Display error message
		
		End Try

	end if

	if SHIFTDATA exists then

		try

			Open Excel Application
			Open SHIFTDATA Workbook
			Open primary Worksheet as shtShifts

			'load in data from database
			for each record in file
				add to shifts record structure
			end for

			Protect workbook (using MASTERKEY)
			
			'clean up and close files
			releaseObject(excel app)
			releaseObject(workbook)
			releaseObject(worksheet)

		Catch
			Display error message
		
		End Try

	end if

End Sub
