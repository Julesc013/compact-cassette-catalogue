Private Sub btnAddData_Click Handles btnAddData.Click

    count = lstNameFirst.SelectedIndex 'modify the currently selected person

    'get data from user
    phoneNumber = input box
    while phoneNumber does not match regexPhone
        phoneNumber = input box
    end while

    emailAddress = input box
    while emailAddress does not match regexEmail
        emailAddress = input box
    end while

    openClose = input box
    while openClose is not boolean
        openClose = input box
    end while

    colourCode = input box
    while colourCode is not in list colours() 'if not a recognised colour that can become a byte code...
        colourCode = input box
    end while


    'add all data to internal record structure
    overwrite employeeData(count).phoneNumber = phoneNumber
    overwrite employeeData(count).emailAddress = emailAddress
    overwrite employeeData(count).openClose = openClose
    overwrite employeeData(count).colourCode = colourCode

    'add all to external sheet
    shtData.Cells(3, count + 1) = employeeData(count).phoneNumber
    shtData.Cells(4, count + 1) = employeeData(count).emailAddress
    shtData.Cells(5, count + 1) = employeeData(count).openClose
    shtData.Cells(7, count + 1) = employeeData(count).colourCode

    'add all to list box
    overwrite lstPhoneNumber(count) = employeeData(count).phoneNumber
    overwrite lstEmailAddress(count) = employeeData(count).emailAddress = emailAddress
    overwrite lstOpenClose(count) = employeeData(count).openClose = openClose
    'no listbox for colour codes

End Sub