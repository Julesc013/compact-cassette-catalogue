'Author: Adrian Janson
'Source: ISBN 978-0-9750764-6-0
'Modifications: Sorts record structures, not plain arrays. Allows sorting entire structure by one specific field.

Private Sub quickSort(byRef List, byVal Field)
	'sort by one specific field

	If length(List) > 1 then

        pivot = first element of the array List.Field
        start = first index of List.Field
        end = last index of List.Field

        while start <= end

            while List.Field(start) < pivot
                start = start + 1
            end while

            while List.Field(end) > pivot
                end = end - 1
            end while

            if start <= end then

                'swap results(start) with results(end)... entire record structure at once
                swapTemp = List(start)
                List(start) = List(end)
                List(end) = swapTemp

                start = start + 1
                end = end - 1

            end if

        end while

		quickSort(List.Field from first index to End)
		quickSort(List.Field from Start to last index)

End Sub
