'Author: Net-informations.com
'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_create_file.htm
'Modifications: None.

Private Sub releaseObject(ByVal obj As Object)
        
    Try
        release obj
        set obj to Nothing
    Catch ex As Exception
        set obj to Nothing
    Finally
        Call built-in garbage collection routine
    End Try

End Sub