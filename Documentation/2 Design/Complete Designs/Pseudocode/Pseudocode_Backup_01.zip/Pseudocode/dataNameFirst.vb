Private Sub lstNameFirst_Selected Handles lstNameFirst.Selected

    'enable buttons when a name is selected
    btnEditInfo enabled = true
    btnEditAvailability enabled = true
    btnRemoveData enabled = true

End Sub


Private Sub lstNameFirst_Deselected Handles lstNameFirst.Deselected 'don't know if this is the proper method, but is pseudocode so whatevs

    'disable buttons when no name is selected
    btnEditInfo enabled = false
    btnEditAvailability enabled = false
    btnRemoveData enabled = false

End Sub