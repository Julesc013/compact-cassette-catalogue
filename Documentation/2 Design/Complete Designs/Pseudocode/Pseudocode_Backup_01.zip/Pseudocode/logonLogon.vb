Private Sub btnLogon_Click Handles btnLogon.Click

	'figure out whose PIN to use
	if cmbUserLogon text = "Owner" then
					frmMain.userGroup = 1
				else
					frmMain.userGroup = 2
				end if

	If PINDATA file does not exist then

		initialise Excel object

		If excel is installed

			Try
				
				Create Workbook
				Open primary Worksheet as shtPins

				PinNew = input box 'ask for new PIN

				while not 4 charaters long and only numbers
					PinNew = input box 'ask again
				end while

				shtPins.Cells("A", usergroup) = PinNew

				'clean up and close files
				releaseObject(excel app)
				releaseObject(workbook)
				releaseObject(worksheet)

				'logon now
				show frmMain
				close this form

			catch
				show error message

			end try

		Else

		Display "excel not installed" "Cannot log on" message
		
		End If

	else

		Try
			
			Open Excel Application
			Open PINDATA Workbook
			Open primary Worksheet as shtPins
			
			PinReal = shtPins.Cells(1, userGroup)
			PinTry = txtPinLogon text
			
			'clean up and close files
			releaseObject(excel app)
			releaseObject(workbook)
			releaseObject(worksheet)

			if PinReal = PinTry then
				'logon
				show frmMain
				close this form
			else
				display PIN wrong message
			end if

		Catch
			Display error message
		
		End Try

	end If
	
End Sub
