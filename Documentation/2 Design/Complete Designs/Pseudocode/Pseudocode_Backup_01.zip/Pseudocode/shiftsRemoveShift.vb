Private Sub btnRemoveShifts_Click Handles btnRemoveShift.Click

    'delete from record structure
    remove shifts(lstShifts.SelectedItem) 
    'delete from sheet
    shtShifts.deleteRow(lstShifts.SelectedItem)
    'remove from list box
    remove lstShifts.SelectedItem

    decrement shiftCount

End Sub