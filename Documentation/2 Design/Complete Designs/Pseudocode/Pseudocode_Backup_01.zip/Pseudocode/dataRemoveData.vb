Private Sub btnRemoveData_Click Handles btnRemoveData.Click

    Show message box asking for confirmation of deletion

    if messagebox result = yes then

        'delete from record structure
        remove employeeData(lstNameFirst.SelectedIndex)
        'delete from sheet
        shtData.deleteRow(lstNameFirst.SelectedIndex)
        'remove from all list boxes
        remove lstNameFirst.SelectedItem
        remove lstNameLast.SelectedItem
        ...
        remove lstNameAvailabilityStored.SelectedItem

        decrement dataCount

    end if

End Sub