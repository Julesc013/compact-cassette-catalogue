Private Sub btnAddData_Click Handles btnAddData.Click

'get data from user
nameFirst = input box
while nameFirst does not match regexName
    nameFirst = input box
end while

nameLast = input box
while nameLast does not match regexName
    nameLast = input box
end while

phoneNumber = input box
while phoneNumber does not match regexPhone
    phoneNumber = input box
end while

emailAddress = input box
while emailAddress does not match regexEmail
    emailAddress = input box
end while

openClose = input box
while openClose is not boolean
    openClose = input box
end while

    colourCode = input box
    while colourCode is not in list colours() 'if not a recognised colour that can become a byte code...
        colourCode = input box
    end while

    availabilityStored = "Missing" 'by default... availability has not yet been entered


    'add all data to internal record structure
    add new employeeData(shiftCount - 1).nameFirst = nameFirst
    add new employeeData(shiftCount - 1).nameLast = nameLast
    ... 'etc
    add new employeeData(shiftCount - 1).openClose = openClose
    add new employeeData(shiftCount - 1).availabilityStored = availabilityStored
    add new employeeData(shiftCount - 1).colourCode = colourCode

    'add all to external sheet
    shtData.Cells(1, shiftCount) = employeeData(shiftCount - 1).nameFirst
    shtData.Cells(2, shiftCount) = employeeData(shiftCount - 1).nameLast
    ... 'etc
    shtData.Cells(5, shiftCount) = employeeData(shiftCount - 1).openClose
    shtData.Cells(6, shiftCount) = employeeData(shiftCount - 1).availabilityStored
    shtData.Cells(7, shiftCount) = employeeData(shiftCount - 1).colourCode

    'add all to list box
    lstNameFirst add employeeData(shiftCount - 1).nameFirst
    lstNameLast add employeeData(shiftCount - 1).nameLast
    ... 'etc
    lstAvailabilityStored add employeeData(shiftCount - 1).availabilityStored
    'no listbox for colour codes

    increment shiftCount

End Sub