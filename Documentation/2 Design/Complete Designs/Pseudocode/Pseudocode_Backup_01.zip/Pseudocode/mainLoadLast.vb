Private Sub btnLoadLast_Click Handles btnLoadLast.Click

    loadRoster(last week roster path)

End Sub
