Private Sub btnOkAvailability_Click Handles btnOKAvailability.Click

    get all text from txt[Weekday][*] into corresponding field of employeeData().availability().[startTime/endTime] 'multiline code summary

    if every item matches regexTime then

        try

            Open Excel Application
            Open EMPLOYEEDATA Workbook
            Open primary Worksheet as shtData
            
            Unprotect workbook (using MASTERKEY)

            write all items in employeeData().availability().[startTime/endTime] to EMPLOYEEDATA

            Protect workbook (using MASTERKEY)
            
            'clean up and close files
            releaseObject(excel app)
            releaseObject(workbook)
            releaseObject(worksheet)

            employeeData(frmData.lstNameFirst.SelectedIndex).availabilityStored = "Submitted"

            close frmAvailability 'close form if data saved successfully

        Catch
            Display error message

        End Try

    else
        show error message

    end if

End Sub