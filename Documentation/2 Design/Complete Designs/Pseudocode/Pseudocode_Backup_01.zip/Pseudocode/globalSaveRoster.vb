sub saveRoster(mode) 'mode is for suggesting or sending

	initialise Excel object

	If excel is installed

		Try
			
			Create Workbook
			Open primary Worksheet as shtRoster

			For i = 1 to 7 'for each day of the week
				For j = 1 to 2 * MAXSTAFF 'for each staff box (*2 for shift box)
					
					'transfer data between combination boxes and file
					shtRoster.Cells(i, 2 * j) = cmbWeek(i)(2 * j)
					shtRoster.Cells(i, 2 * j + 1) = cmbWeek(i)(2 * j + 1)

				End For
			End For

			'make font larger
			First 10 rows & columns = Font Size 14

			if mode = "send" then 'if this file is to be sent and archived

				'add header
				shtRoster.InsertRow 'insert two new rows at the top
				shtRoster.InsertRow
				shtRoster.Cells("A", 1) = title & date & time & week number 'add header to first row
				shtRoster.Cells("A", 2) = "Thursday" 'add days of the week to second row
				...
				shtRoster.Cells("G", 2) = "Wednesday"

				'find all names and colour them
				for each name in database
					for each occurance of name
						cell text colour = employeeData(name) colour field value
					end for
				end for

			end if

			if mode = "send" then

				save file to archive folder in home directory as "roster[weekNum][Date].xlsx"

				if roster within same week exists then
					delete old copy
				end If

				export PDF to home directory as ROSTERLATEST

			Else

				save file to home directory as ROSTERSUGGESTED

			end if

			'clean up and close files
			releaseObject(excel app)
			releaseObject(workbook)
			releaseObject(worksheet)
			
		Catch
			Display error message
		
		End Try

	Else

		Display "excel not installed" message
		
	End If

End Sub
