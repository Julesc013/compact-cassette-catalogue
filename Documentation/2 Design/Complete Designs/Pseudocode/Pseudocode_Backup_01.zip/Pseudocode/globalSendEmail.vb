'Author: M.V.Rajasekhar
'Source: http://www.freevbcode.com/ShowCode.asp?ID=5486
'Modifications: Removed some parameters and modified attachment line.

Public Sub sendEmail(sendTo, subject, body, carbonCopy, blindCarbonCopy, smtpServer)

	Try
		myMessage = New MailMessage() 'declare new message

		With myMessage

			.To = sendTo
			.From = MYEMAIL 'address is constant
			.Subject = subject
			.Body = body
			.BodyFormat = MailFormat.Text

			If carbonCopy exists Then .Cc = carbonCopy
			If blindCarbonCopy exists Then .Bcc = blindCarbonCopy

			If FileExists(ROSTERLATEST) Then .Attachments.Add(ROSTERLATEST) 'attachment is constant

		End With

		If smtpServer exists Then _
			SmtpMail.SmtpServer = smtpServer
		SmtpMail.Send(myMessage)

	Catch Exception
		display error message
	End Try

End Sub