﻿' Name:             Data Entry
' Purpose:          Add/edit/remove employee data from the data store.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    16 May 2019

Public Class frmData
    Private Sub btnEditAvailbility_Click(sender As Object, e As EventArgs) Handles btnEditAvailbility.Click
        frmAvailability.Show()
    End Sub

    Private Sub btnEditInfo_Click(sender As Object, e As EventArgs) Handles btnEditInfo.Click
        'dont forget to ask for colour codes:
        'Source: https://stackoverflow.com/questions/33886090/convert-string-to-color-vb-net
        'Dim clrDialog As New ColorDialog
        'If clrDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    TextBox1.Text = clrDialog.Color.ToArgb.ToString
        'End If
        'clrDialog.Dispose()
    End Sub

    Private Sub frmData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'populate boxes (colour coded)
    End Sub
End Class