﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAvailability
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAvailability))
        Me.lblThursday = New System.Windows.Forms.Label()
        Me.txtThursdayStart = New System.Windows.Forms.TextBox()
        Me.txtThursdayFinish = New System.Windows.Forms.TextBox()
        Me.lblTitleAvailability = New System.Windows.Forms.Label()
        Me.txtFridayFinish = New System.Windows.Forms.TextBox()
        Me.txtFridayStart = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSundayFinish = New System.Windows.Forms.TextBox()
        Me.txtSundayStart = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSaturdayFinish = New System.Windows.Forms.TextBox()
        Me.txtSaturdayStart = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtWednesdayFinish = New System.Windows.Forms.TextBox()
        Me.txtWednesdayStart = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTuesdayFinish = New System.Windows.Forms.TextBox()
        Me.txtTuesdayStart = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMondayFinish = New System.Windows.Forms.TextBox()
        Me.txtMondayStart = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnOkAvailability = New System.Windows.Forms.Button()
        Me.btnCancelAvailability = New System.Windows.Forms.Button()
        Me.lblStartTime = New System.Windows.Forms.Label()
        Me.lblEndTime = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblThursday
        '
        Me.lblThursday.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThursday.Location = New System.Drawing.Point(120, 60)
        Me.lblThursday.Name = "lblThursday"
        Me.lblThursday.Size = New System.Drawing.Size(118, 25)
        Me.lblThursday.TabIndex = 10
        Me.lblThursday.Text = "Thursday"
        Me.lblThursday.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtThursdayStart
        '
        Me.txtThursdayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtThursdayStart.Location = New System.Drawing.Point(120, 92)
        Me.txtThursdayStart.Name = "txtThursdayStart"
        Me.txtThursdayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtThursdayStart.TabIndex = 11
        '
        'txtThursdayFinish
        '
        Me.txtThursdayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtThursdayFinish.Location = New System.Drawing.Point(120, 128)
        Me.txtThursdayFinish.Name = "txtThursdayFinish"
        Me.txtThursdayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtThursdayFinish.TabIndex = 12
        '
        'lblTitleAvailability
        '
        Me.lblTitleAvailability.Font = New System.Drawing.Font("Geometos", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleAvailability.Location = New System.Drawing.Point(12, 22)
        Me.lblTitleAvailability.Name = "lblTitleAvailability"
        Me.lblTitleAvailability.Size = New System.Drawing.Size(976, 25)
        Me.lblTitleAvailability.TabIndex = 13
        Me.lblTitleAvailability.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtFridayFinish
        '
        Me.txtFridayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFridayFinish.Location = New System.Drawing.Point(244, 128)
        Me.txtFridayFinish.Name = "txtFridayFinish"
        Me.txtFridayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtFridayFinish.TabIndex = 16
        '
        'txtFridayStart
        '
        Me.txtFridayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFridayStart.Location = New System.Drawing.Point(244, 92)
        Me.txtFridayStart.Name = "txtFridayStart"
        Me.txtFridayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtFridayStart.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(244, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 25)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Friday"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtSundayFinish
        '
        Me.txtSundayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSundayFinish.Location = New System.Drawing.Point(492, 128)
        Me.txtSundayFinish.Name = "txtSundayFinish"
        Me.txtSundayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtSundayFinish.TabIndex = 22
        '
        'txtSundayStart
        '
        Me.txtSundayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSundayStart.Location = New System.Drawing.Point(492, 92)
        Me.txtSundayStart.Name = "txtSundayStart"
        Me.txtSundayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtSundayStart.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(492, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 25)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Sunday"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtSaturdayFinish
        '
        Me.txtSaturdayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaturdayFinish.Location = New System.Drawing.Point(368, 128)
        Me.txtSaturdayFinish.Name = "txtSaturdayFinish"
        Me.txtSaturdayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtSaturdayFinish.TabIndex = 19
        '
        'txtSaturdayStart
        '
        Me.txtSaturdayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaturdayStart.Location = New System.Drawing.Point(368, 92)
        Me.txtSaturdayStart.Name = "txtSaturdayStart"
        Me.txtSaturdayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtSaturdayStart.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(368, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(118, 25)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Saturday"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtWednesdayFinish
        '
        Me.txtWednesdayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWednesdayFinish.Location = New System.Drawing.Point(864, 128)
        Me.txtWednesdayFinish.Name = "txtWednesdayFinish"
        Me.txtWednesdayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtWednesdayFinish.TabIndex = 31
        '
        'txtWednesdayStart
        '
        Me.txtWednesdayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWednesdayStart.Location = New System.Drawing.Point(864, 92)
        Me.txtWednesdayStart.Name = "txtWednesdayStart"
        Me.txtWednesdayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtWednesdayStart.TabIndex = 30
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(864, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 25)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Wednesday"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtTuesdayFinish
        '
        Me.txtTuesdayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTuesdayFinish.Location = New System.Drawing.Point(740, 128)
        Me.txtTuesdayFinish.Name = "txtTuesdayFinish"
        Me.txtTuesdayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtTuesdayFinish.TabIndex = 28
        '
        'txtTuesdayStart
        '
        Me.txtTuesdayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTuesdayStart.Location = New System.Drawing.Point(740, 92)
        Me.txtTuesdayStart.Name = "txtTuesdayStart"
        Me.txtTuesdayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtTuesdayStart.TabIndex = 27
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(740, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 25)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Tuesday"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtMondayFinish
        '
        Me.txtMondayFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMondayFinish.Location = New System.Drawing.Point(616, 128)
        Me.txtMondayFinish.Name = "txtMondayFinish"
        Me.txtMondayFinish.Size = New System.Drawing.Size(118, 30)
        Me.txtMondayFinish.TabIndex = 25
        '
        'txtMondayStart
        '
        Me.txtMondayStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMondayStart.Location = New System.Drawing.Point(616, 92)
        Me.txtMondayStart.Name = "txtMondayStart"
        Me.txtMondayStart.Size = New System.Drawing.Size(118, 30)
        Me.txtMondayStart.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(616, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(118, 25)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Monday"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnOkAvailability
        '
        Me.btnOkAvailability.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOkAvailability.Location = New System.Drawing.Point(864, 176)
        Me.btnOkAvailability.Name = "btnOkAvailability"
        Me.btnOkAvailability.Size = New System.Drawing.Size(118, 37)
        Me.btnOkAvailability.TabIndex = 1
        Me.btnOkAvailability.Text = "Accept"
        Me.btnOkAvailability.UseVisualStyleBackColor = True
        '
        'btnCancelAvailability
        '
        Me.btnCancelAvailability.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelAvailability.Location = New System.Drawing.Point(740, 176)
        Me.btnCancelAvailability.Name = "btnCancelAvailability"
        Me.btnCancelAvailability.Size = New System.Drawing.Size(118, 37)
        Me.btnCancelAvailability.TabIndex = 0
        Me.btnCancelAvailability.Text = "Cancel"
        Me.btnCancelAvailability.UseVisualStyleBackColor = True
        Me.btnCancelAvailability.Visible = False
        '
        'lblStartTime
        '
        Me.lblStartTime.AutoSize = True
        Me.lblStartTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartTime.Location = New System.Drawing.Point(6, 95)
        Me.lblStartTime.Name = "lblStartTime"
        Me.lblStartTime.Size = New System.Drawing.Size(108, 25)
        Me.lblStartTime.TabIndex = 34
        Me.lblStartTime.Text = "Start Time:"
        Me.lblStartTime.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblEndTime
        '
        Me.lblEndTime.AutoSize = True
        Me.lblEndTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEndTime.Location = New System.Drawing.Point(12, 131)
        Me.lblEndTime.Name = "lblEndTime"
        Me.lblEndTime.Size = New System.Drawing.Size(102, 25)
        Me.lblEndTime.TabIndex = 35
        Me.lblEndTime.Text = "End Time:"
        Me.lblEndTime.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmAvailability
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(994, 225)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblEndTime)
        Me.Controls.Add(Me.lblStartTime)
        Me.Controls.Add(Me.btnCancelAvailability)
        Me.Controls.Add(Me.btnOkAvailability)
        Me.Controls.Add(Me.txtWednesdayFinish)
        Me.Controls.Add(Me.txtWednesdayStart)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtTuesdayFinish)
        Me.Controls.Add(Me.txtTuesdayStart)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtMondayFinish)
        Me.Controls.Add(Me.txtMondayStart)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtSundayFinish)
        Me.Controls.Add(Me.txtSundayStart)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtSaturdayFinish)
        Me.Controls.Add(Me.txtSaturdayStart)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtFridayFinish)
        Me.Controls.Add(Me.txtFridayStart)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTitleAvailability)
        Me.Controls.Add(Me.txtThursdayFinish)
        Me.Controls.Add(Me.txtThursdayStart)
        Me.Controls.Add(Me.lblThursday)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAvailability"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Modify Employee Availability"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblThursday As Label
    Friend WithEvents txtThursdayStart As TextBox
    Friend WithEvents txtThursdayFinish As TextBox
    Friend WithEvents lblTitleAvailability As Label
    Friend WithEvents txtFridayFinish As TextBox
    Friend WithEvents txtFridayStart As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSundayFinish As TextBox
    Friend WithEvents txtSundayStart As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtSaturdayFinish As TextBox
    Friend WithEvents txtSaturdayStart As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtWednesdayFinish As TextBox
    Friend WithEvents txtWednesdayStart As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtTuesdayFinish As TextBox
    Friend WithEvents txtTuesdayStart As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtMondayFinish As TextBox
    Friend WithEvents txtMondayStart As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btnOkAvailability As Button
    Friend WithEvents btnCancelAvailability As Button
    Friend WithEvents lblStartTime As Label
    Friend WithEvents lblEndTime As Label
End Class
