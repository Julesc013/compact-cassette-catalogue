﻿' Name:             Logon Dialogue
' Purpose:          Initial form; allows users to logon and shows version information.
' Author:           Jules Carboni
' Date Created:     15 May 2019
' Date Modified:    24 May 2019

Public Class frmLogon

    'Declare variables
    Dim PINDATA As String = FILEPATH & "\Data\UserPins.xlsx" 'Cannot include full path in constant.


    Private Sub frmLogon_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Display about information
        lblAboutProgram.Text = "Version " & VERSION & vbNewLine & "Jules Carboni (VCE), 2019"

        'Validation to ensure user knows their screen resolution is unexpected and the program may not by usable.
        'Get resolution
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

        If screenHeight <> 1080 Or screenWidth <> 1920 Then 'If not expected resolution
            Dim resolutionError As String

            'Determine side-effects
            If screenHeight < 1080 Or screenWidth < 1920 Then
                resolutionError = "Your display is smaller. Some parts of the interface may not appear on screen and may be unusable."
            Else
                resolutionError = "Your display is larger. The usability of the program should not be affected."
            End If

            MsgBox("This program is designed to run on a 1920×1080 monitor." & vbNewLine & "It appears your monitor has a resolution of " & screenWidth & "×" & screenHeight & "." & vbNewLine & vbNewLine & resolutionError & vbNewLine & vbNewLine & "Use of this program will not cause harm to your system.", MsgBoxStyle.Exclamation, "Display Resolution Warning")
        End If

    End Sub

    Private Sub setNewPin(ByRef pinNew As String, userGroup As String)
        'Get new PIN from user via input boxes and validate.

        'Declare variables
        Dim pinRedo As String

        pinNew = InputBox("No PIN currently set." & vbNewLine & "Enter a new PIN for user group: " & userGroup, "Enter new PIN")

        While Not IsNumeric(pinNew) Or Len(pinNew) <> 4 'while PIN is not numeric nor 4 digits
            pinNew = InputBox("No PIN currently set." & vbNewLine & "PIN must be numeric and 4 digits only." & vbNewLine & vbNewLine & "Enter a new PIN for user group: " & userGroup, "Enter new PIN")
        End While

        pinRedo = InputBox("No PIN currently set." & vbNewLine & "Re-enter the same PIN again to verify.", "Re-enter new PIN")

        While pinNew <> pinRedo 'while new PINs dont match
            pinNew = InputBox("No PIN currently set." & vbNewLine & "PINs did not match." & vbNewLine & vbNewLine & "Enter a new PIN for user group: " & userGroup, "Enter new PIN")
            pinRedo = InputBox("No PIN currently set." & vbNewLine & "Re-enter the same PIN again to verify.", "Re-enter new PIN")
        End While

    End Sub

    Private Sub btnLogon_Click(sender As Object, e As EventArgs) Handles btnLogon.Click
        'Validate to ensure PIN is correct before allowing logon

        'Get user-group and PIN
        Dim userGroup As String = cmbUserLogon.Text
        Dim pinTry As String = txtPinLogon.Text
        Dim pinNew As String

        If userGroup = "Owner" Then

            If My.Settings.pinOwner = "null" Then 'If no PIN is set, create a new PIN

                setNewPin(pinNew, userGroup) 'Call routine to get PIN from user

                My.Settings.pinOwner = pinNew 'Save/set new PIN to user-group setting

                'Log on
                frmMain.Show()
                Me.Close()

            ElseIf pinTry = My.Settings.pinOwner Then 'If PIN exists and is a match, logon
                frmMain.Show()
                Me.Close()

            Else 'If PIN doesnt match, show error
                MsgBox("PIN incorrect—does not match." & vbNewLine & "Must be four digits long and contain only numbers.", MsgBoxStyle.Exclamation, "PIN Incorrect.")
            End If

        ElseIf userGroup Is "Chef/Manager" Then

            If My.Settings.pinChefManager = "null" Then 'If no PIN is set, create a new PIN

                setNewPin(pinNew, userGroup) 'Call routine to get PIN from user

                My.Settings.pinChefManager = pinNew 'Save/set new PIN to user-group setting

                'Log on
                frmMain.Show()
                Me.Close()

            ElseIf pinTry = My.Settings.pinChefManager Then 'If PIN exists and is a match, logon
                frmMain.Show()
                Me.Close()

            Else 'If PIN doesnt match, show error
                MsgBox("PIN incorrect—does not match." & vbNewLine & "Must be four digits long and contain only numbers.", MsgBoxStyle.Exclamation, "PIN Incorrect.")
            End If

        End If

    End Sub

    Private Sub picLogoTwo_Click(sender As Object, e As EventArgs) Handles picLogoTwo.Click
        aboutProgram()
    End Sub

    Private Sub picLogoOne_Click(sender As Object, e As EventArgs) Handles picLogoOne.Click
        aboutProgram()
    End Sub

    Private Sub cmbUserLogon_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbUserLogon.SelectedIndexChanged
        'Enable ability to log on once a user is selected
        btnLogon.Enabled = True
    End Sub
End Class