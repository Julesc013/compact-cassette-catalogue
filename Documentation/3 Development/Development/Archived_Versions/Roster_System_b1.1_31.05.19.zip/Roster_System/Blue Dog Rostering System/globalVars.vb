﻿' Name:             Global Variables and Subroutines
' Purpose:          Stores all the global varibales and subroutines used in multiple forms throughout the program.
' Author:           Jules Carboni
' Date Created:     29 May 2019
' Date Modified:    29 May 2019

Module globalVars

    'Decalare global variables

    Public FILEPATH As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\RosterSystem"
    Public Const VERSION As String = "Beta 1.1"


    'Declare global subroutines

    Sub aboutProgram()
        MsgBox("Blue Dog Cafe Rostering System" & vbNewLine & "Version " & VERSION & vbNewLine & "Jules Carboni, 2019" & vbNewLine & vbNewLine & "Program data and roster archive saved in:" & vbNewLine & FILEPATH, MsgBoxStyle.Information, "About Rostering System")
    End Sub

End Module
