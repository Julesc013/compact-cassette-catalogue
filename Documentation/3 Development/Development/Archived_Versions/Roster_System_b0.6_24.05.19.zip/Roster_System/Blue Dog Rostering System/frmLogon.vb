﻿' Name:             Logon Dialogue
' Purpose:          Initial form; allows users to logon and shows version information.
' Author:           Jules Carboni
' Date Created:     15 May 2019
' Date Modified:    24 May 2019

Public Class frmLogon

    'Declare variables
    Dim PINDATA As String = frmMain.FILEPATH & "\Data\UserPins.xlsx" 'Cannot include full path in constant.


    Private Sub frmLogon_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Display about information
        lblAboutProgram.Text = "Version " & frmMain.VERSION & vbNewLine & "Jules Carboni (VCE), 2019"

        'Warn user about screen resolution limitations
        'Get resolution
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

        If screenHeight <> 1080 Or screenWidth <> 1920 Then 'If not expected resolution

            Dim resolutionError As String
            'Determine side-effects
            If screenHeight < 1080 Or screenWidth < 1920 Then
                resolutionError = "Your display is smaller. Some parts of the interface may not appear on screen and may be unusable."
            Else
                resolutionError = "Your display is larger. The usability of the program should not be affected."
            End If

            MsgBox("This program is designed to run on a 1920×1080 monitor." & vbNewLine & "It appears your monitor has a resolution of " & screenWidth & "×" & screenHeight & "." & vbNewLine & vbNewLine & resolutionError & vbNewLine & vbNewLine & "Use of this program will not cause harm to your system.", MsgBoxStyle.Exclamation, "Display Resolution Warning")
        End If

    End Sub

    Private Sub btnLogon_Click(sender As Object, e As EventArgs) Handles btnLogon.Click
        'if password is match
        frmMain.Show()
        Me.Close()
    End Sub

    Private Sub picLogoTwo_Click(sender As Object, e As EventArgs) Handles picLogoTwo.Click
        frmMain.aboutProgram()
    End Sub

    Private Sub picLogoOne_Click(sender As Object, e As EventArgs) Handles picLogoOne.Click
        frmMain.aboutProgram()
    End Sub

End Class