﻿' Name:             Search Archive
' Purpose:          Search And sort archived rosters for shifts by employee name. Get basic statistics on employee. Save results to file.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    16 May 2019

Public Class frmSearch
    Private Sub btnSaveResults_Click(sender As Object, e As EventArgs) Handles btnSaveResults.Click
        dlgSaveResults.ShowDialog()
    End Sub
End Class