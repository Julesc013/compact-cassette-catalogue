# Blue Dog Café Rostering System

## Change Log



### Version 0.6 (May 24)

- Added screen resolution check and warning



### Version 0.1 – 0.5 (May 14)

- Iteratively designed all forms

- Added placeholder code for opening/closing forms
- Added "About Program" information

