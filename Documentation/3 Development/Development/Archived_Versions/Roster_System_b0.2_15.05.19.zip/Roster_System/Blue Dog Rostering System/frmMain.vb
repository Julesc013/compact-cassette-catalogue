﻿Public Class frmMain

    Sub closeApplication()
        'save and close
        Application.Exit()
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        'about information
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        closeApplication()
    End Sub
End Class
