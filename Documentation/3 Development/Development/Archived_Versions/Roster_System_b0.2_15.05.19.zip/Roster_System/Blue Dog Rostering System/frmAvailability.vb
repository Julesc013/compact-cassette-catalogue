﻿Public Class lblNameAvailability

End Class