﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstShifts = New System.Windows.Forms.ListBox()
        Me.btnAddShift = New System.Windows.Forms.Button()
        Me.btnRemoveShift = New System.Windows.Forms.Button()
        Me.lblRemove = New System.Windows.Forms.Label()
        Me.btnOKShifts = New System.Windows.Forms.Button()
        Me.btnCancelShifts = New System.Windows.Forms.Button()
        Me.txtStartTime = New System.Windows.Forms.TextBox()
        Me.txtEndTime = New System.Windows.Forms.TextBox()
        Me.lblAdd = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstShifts
        '
        Me.lstShifts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShifts.FormattingEnabled = True
        Me.lstShifts.ItemHeight = 25
        Me.lstShifts.Location = New System.Drawing.Point(12, 12)
        Me.lstShifts.Name = "lstShifts"
        Me.lstShifts.Size = New System.Drawing.Size(225, 379)
        Me.lstShifts.TabIndex = 0
        '
        'btnAddShift
        '
        Me.btnAddShift.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddShift.Location = New System.Drawing.Point(248, 134)
        Me.btnAddShift.Name = "btnAddShift"
        Me.btnAddShift.Size = New System.Drawing.Size(143, 37)
        Me.btnAddShift.TabIndex = 1
        Me.btnAddShift.Text = "Add Shift"
        Me.btnAddShift.UseVisualStyleBackColor = True
        '
        'btnRemoveShift
        '
        Me.btnRemoveShift.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemoveShift.Location = New System.Drawing.Point(248, 227)
        Me.btnRemoveShift.Name = "btnRemoveShift"
        Me.btnRemoveShift.Size = New System.Drawing.Size(143, 37)
        Me.btnRemoveShift.TabIndex = 2
        Me.btnRemoveShift.Text = "Remove Shift"
        Me.btnRemoveShift.UseVisualStyleBackColor = True
        '
        'lblRemove
        '
        Me.lblRemove.AutoSize = True
        Me.lblRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRemove.Location = New System.Drawing.Point(253, 174)
        Me.lblRemove.Name = "lblRemove"
        Me.lblRemove.Size = New System.Drawing.Size(133, 50)
        Me.lblRemove.TabIndex = 3
        Me.lblRemove.Text = "Or select from" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the list..."
        Me.lblRemove.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnOKShifts
        '
        Me.btnOKShifts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOKShifts.Location = New System.Drawing.Point(248, 354)
        Me.btnOKShifts.Name = "btnOKShifts"
        Me.btnOKShifts.Size = New System.Drawing.Size(143, 37)
        Me.btnOKShifts.TabIndex = 5
        Me.btnOKShifts.Text = "OK"
        Me.btnOKShifts.UseVisualStyleBackColor = True
        '
        'btnCancelShifts
        '
        Me.btnCancelShifts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelShifts.Location = New System.Drawing.Point(248, 311)
        Me.btnCancelShifts.Name = "btnCancelShifts"
        Me.btnCancelShifts.Size = New System.Drawing.Size(143, 37)
        Me.btnCancelShifts.TabIndex = 4
        Me.btnCancelShifts.Text = "Cancel"
        Me.btnCancelShifts.UseVisualStyleBackColor = True
        '
        'txtStartTime
        '
        Me.txtStartTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStartTime.Location = New System.Drawing.Point(248, 62)
        Me.txtStartTime.Name = "txtStartTime"
        Me.txtStartTime.Size = New System.Drawing.Size(143, 30)
        Me.txtStartTime.TabIndex = 6
        Me.txtStartTime.Text = "Start"
        '
        'txtEndTime
        '
        Me.txtEndTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEndTime.Location = New System.Drawing.Point(248, 98)
        Me.txtEndTime.Name = "txtEndTime"
        Me.txtEndTime.Size = New System.Drawing.Size(143, 30)
        Me.txtEndTime.TabIndex = 7
        Me.txtEndTime.Text = "End"
        '
        'lblAdd
        '
        Me.lblAdd.AutoSize = True
        Me.lblAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdd.Location = New System.Drawing.Point(261, 9)
        Me.lblAdd.Name = "lblAdd"
        Me.lblAdd.Size = New System.Drawing.Size(118, 50)
        Me.lblAdd.TabIndex = 8
        Me.lblAdd.Text = "Specify new" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "shift times..."
        Me.lblAdd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(403, 402)
        Me.Controls.Add(Me.lblAdd)
        Me.Controls.Add(Me.txtEndTime)
        Me.Controls.Add(Me.txtStartTime)
        Me.Controls.Add(Me.btnOKShifts)
        Me.Controls.Add(Me.btnCancelShifts)
        Me.Controls.Add(Me.lblRemove)
        Me.Controls.Add(Me.btnRemoveShift)
        Me.Controls.Add(Me.btnAddShift)
        Me.Controls.Add(Me.lstShifts)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmData"
        Me.Text = "Edit Shift Blocks"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstShifts As ListBox
    Friend WithEvents btnAddShift As Button
    Friend WithEvents btnRemoveShift As Button
    Friend WithEvents lblRemove As Label
    Friend WithEvents btnOKShifts As Button
    Friend WithEvents btnCancelShifts As Button
    Friend WithEvents txtStartTime As TextBox
    Friend WithEvents txtEndTime As TextBox
    Friend WithEvents lblAdd As Label
End Class
