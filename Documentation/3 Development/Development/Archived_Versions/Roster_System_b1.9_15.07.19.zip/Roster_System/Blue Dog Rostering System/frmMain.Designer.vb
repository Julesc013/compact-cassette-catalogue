﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnLoadLast = New System.Windows.Forms.Button()
        Me.btnSendRoster = New System.Windows.Forms.Button()
        Me.pnlRoster = New System.Windows.Forms.Panel()
        Me.pnlDay7 = New System.Windows.Forms.Panel()
        Me.cmbShiftWed6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffWed6 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftWed5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffWed5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftWed4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffWed4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftWed3 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffWed3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftWed2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffWed2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftWed1 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbStaffWed1 = New System.Windows.Forms.ComboBox()
        Me.pnlDay6 = New System.Windows.Forms.Panel()
        Me.cmbShiftTue6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffTue6 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftTue5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffTue5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftTue4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffTue4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftTue3 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffTue3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftTue2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffTue2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftTue1 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbStaffTue1 = New System.Windows.Forms.ComboBox()
        Me.pnlDay2 = New System.Windows.Forms.Panel()
        Me.cmbShiftFri6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffFri6 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftFri5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffFri5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftFri4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffFri4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftFri3 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffFri3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftFri2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffFri2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftFri1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbStaffFri1 = New System.Windows.Forms.ComboBox()
        Me.pnlDay5 = New System.Windows.Forms.Panel()
        Me.cmbStaffMon1 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftMon6 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbShiftMon1 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffMon6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffMon2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftMon2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftMon5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffMon3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftMon3 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffMon5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffMon4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftMon4 = New System.Windows.Forms.ComboBox()
        Me.pnlDay4 = New System.Windows.Forms.Panel()
        Me.cmbShiftSun6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSun6 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSun5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSun5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSun4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSun4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSun3 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSun3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSun2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSun2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSun1 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbStaffSun1 = New System.Windows.Forms.ComboBox()
        Me.pnlDay3 = New System.Windows.Forms.Panel()
        Me.cmbShiftSat6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat1 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat6 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbShiftSat5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSat1 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSat4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSat2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffSat3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftSat3 = New System.Windows.Forms.ComboBox()
        Me.pnlDay1 = New System.Windows.Forms.Panel()
        Me.cmbShiftThu6 = New System.Windows.Forms.ComboBox()
        Me.lblThursday = New System.Windows.Forms.Label()
        Me.cmbStaffThu6 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffThu1 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu5 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu1 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffThu5 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffThu2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu4 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu2 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffThu4 = New System.Windows.Forms.ComboBox()
        Me.cmbStaffThu3 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu3 = New System.Windows.Forms.ComboBox()
        Me.lblTitleMain = New System.Windows.Forms.Label()
        Me.ctxGlobal = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.btnAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCloseApp = New System.Windows.Forms.Button()
        Me.btnSearchArchive = New System.Windows.Forms.Button()
        Me.btnEditData = New System.Windows.Forms.Button()
        Me.btnEditPin = New System.Windows.Forms.Button()
        Me.btnEditShifts = New System.Windows.Forms.Button()
        Me.picLogoMain = New System.Windows.Forms.PictureBox()
        Me.btnSuggestRoster = New System.Windows.Forms.Button()
        Me.btnLoadSuggested = New System.Windows.Forms.Button()
        Me.pnlRoster.SuspendLayout()
        Me.pnlDay7.SuspendLayout()
        Me.pnlDay6.SuspendLayout()
        Me.pnlDay2.SuspendLayout()
        Me.pnlDay5.SuspendLayout()
        Me.pnlDay4.SuspendLayout()
        Me.pnlDay3.SuspendLayout()
        Me.pnlDay1.SuspendLayout()
        Me.ctxGlobal.SuspendLayout()
        CType(Me.picLogoMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLoadLast
        '
        Me.btnLoadLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoadLast.Location = New System.Drawing.Point(12, 1008)
        Me.btnLoadLast.Name = "btnLoadLast"
        Me.btnLoadLast.Size = New System.Drawing.Size(180, 60)
        Me.btnLoadLast.TabIndex = 0
        Me.btnLoadLast.Text = "Copy Last" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Roster"
        Me.btnLoadLast.UseVisualStyleBackColor = True
        '
        'btnSendRoster
        '
        Me.btnSendRoster.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSendRoster.Location = New System.Drawing.Point(1728, 1008)
        Me.btnSendRoster.Name = "btnSendRoster"
        Me.btnSendRoster.Size = New System.Drawing.Size(180, 60)
        Me.btnSendRoster.TabIndex = 6
        Me.btnSendRoster.Text = "Send and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Archive"
        Me.btnSendRoster.UseVisualStyleBackColor = True
        '
        'pnlRoster
        '
        Me.pnlRoster.Controls.Add(Me.pnlDay7)
        Me.pnlRoster.Controls.Add(Me.pnlDay6)
        Me.pnlRoster.Controls.Add(Me.pnlDay2)
        Me.pnlRoster.Controls.Add(Me.pnlDay5)
        Me.pnlRoster.Controls.Add(Me.pnlDay4)
        Me.pnlRoster.Controls.Add(Me.pnlDay3)
        Me.pnlRoster.Controls.Add(Me.pnlDay1)
        Me.pnlRoster.Location = New System.Drawing.Point(12, 138)
        Me.pnlRoster.Name = "pnlRoster"
        Me.pnlRoster.Size = New System.Drawing.Size(1896, 864)
        Me.pnlRoster.TabIndex = 0
        '
        'pnlDay7
        '
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed6)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed6)
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed5)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed5)
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed4)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed4)
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed3)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed3)
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed2)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed2)
        Me.pnlDay7.Controls.Add(Me.cmbShiftWed1)
        Me.pnlDay7.Controls.Add(Me.Label6)
        Me.pnlDay7.Controls.Add(Me.cmbStaffWed1)
        Me.pnlDay7.Location = New System.Drawing.Point(1620, 3)
        Me.pnlDay7.Name = "pnlDay7"
        Me.pnlDay7.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay7.TabIndex = 6
        '
        'cmbShiftWed6
        '
        Me.cmbShiftWed6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed6.Enabled = False
        Me.cmbShiftWed6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed6.FormattingEnabled = True
        Me.cmbShiftWed6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftWed6.Name = "cmbShiftWed6"
        Me.cmbShiftWed6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed6.TabIndex = 35
        '
        'cmbStaffWed6
        '
        Me.cmbStaffWed6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed6.FormattingEnabled = True
        Me.cmbStaffWed6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffWed6.Name = "cmbStaffWed6"
        Me.cmbStaffWed6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed6.TabIndex = 34
        '
        'cmbShiftWed5
        '
        Me.cmbShiftWed5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed5.Enabled = False
        Me.cmbShiftWed5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed5.FormattingEnabled = True
        Me.cmbShiftWed5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftWed5.Name = "cmbShiftWed5"
        Me.cmbShiftWed5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed5.TabIndex = 33
        '
        'cmbStaffWed5
        '
        Me.cmbStaffWed5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed5.FormattingEnabled = True
        Me.cmbStaffWed5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffWed5.Name = "cmbStaffWed5"
        Me.cmbStaffWed5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed5.TabIndex = 32
        '
        'cmbShiftWed4
        '
        Me.cmbShiftWed4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed4.Enabled = False
        Me.cmbShiftWed4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed4.FormattingEnabled = True
        Me.cmbShiftWed4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftWed4.Name = "cmbShiftWed4"
        Me.cmbShiftWed4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed4.TabIndex = 31
        '
        'cmbStaffWed4
        '
        Me.cmbStaffWed4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed4.FormattingEnabled = True
        Me.cmbStaffWed4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffWed4.Name = "cmbStaffWed4"
        Me.cmbStaffWed4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed4.TabIndex = 30
        '
        'cmbShiftWed3
        '
        Me.cmbShiftWed3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed3.Enabled = False
        Me.cmbShiftWed3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed3.FormattingEnabled = True
        Me.cmbShiftWed3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftWed3.Name = "cmbShiftWed3"
        Me.cmbShiftWed3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed3.TabIndex = 29
        '
        'cmbStaffWed3
        '
        Me.cmbStaffWed3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed3.FormattingEnabled = True
        Me.cmbStaffWed3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffWed3.Name = "cmbStaffWed3"
        Me.cmbStaffWed3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed3.TabIndex = 28
        '
        'cmbShiftWed2
        '
        Me.cmbShiftWed2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed2.Enabled = False
        Me.cmbShiftWed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed2.FormattingEnabled = True
        Me.cmbShiftWed2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftWed2.Name = "cmbShiftWed2"
        Me.cmbShiftWed2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed2.TabIndex = 27
        '
        'cmbStaffWed2
        '
        Me.cmbStaffWed2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed2.FormattingEnabled = True
        Me.cmbStaffWed2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffWed2.Name = "cmbStaffWed2"
        Me.cmbStaffWed2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed2.TabIndex = 26
        '
        'cmbShiftWed1
        '
        Me.cmbShiftWed1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftWed1.Enabled = False
        Me.cmbShiftWed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftWed1.FormattingEnabled = True
        Me.cmbShiftWed1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftWed1.Name = "cmbShiftWed1"
        Me.cmbShiftWed1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftWed1.TabIndex = 25
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(26, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(221, 35)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Wednesday"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffWed1
        '
        Me.cmbStaffWed1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffWed1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffWed1.FormattingEnabled = True
        Me.cmbStaffWed1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffWed1.Name = "cmbStaffWed1"
        Me.cmbStaffWed1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffWed1.TabIndex = 23
        '
        'pnlDay6
        '
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue6)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue6)
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue5)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue5)
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue4)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue4)
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue3)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue3)
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue2)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue2)
        Me.pnlDay6.Controls.Add(Me.cmbShiftTue1)
        Me.pnlDay6.Controls.Add(Me.Label5)
        Me.pnlDay6.Controls.Add(Me.cmbStaffTue1)
        Me.pnlDay6.Location = New System.Drawing.Point(1351, 3)
        Me.pnlDay6.Name = "pnlDay6"
        Me.pnlDay6.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay6.TabIndex = 5
        '
        'cmbShiftTue6
        '
        Me.cmbShiftTue6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue6.Enabled = False
        Me.cmbShiftTue6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue6.FormattingEnabled = True
        Me.cmbShiftTue6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftTue6.Name = "cmbShiftTue6"
        Me.cmbShiftTue6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue6.TabIndex = 35
        '
        'cmbStaffTue6
        '
        Me.cmbStaffTue6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue6.FormattingEnabled = True
        Me.cmbStaffTue6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffTue6.Name = "cmbStaffTue6"
        Me.cmbStaffTue6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue6.TabIndex = 34
        '
        'cmbShiftTue5
        '
        Me.cmbShiftTue5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue5.Enabled = False
        Me.cmbShiftTue5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue5.FormattingEnabled = True
        Me.cmbShiftTue5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftTue5.Name = "cmbShiftTue5"
        Me.cmbShiftTue5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue5.TabIndex = 33
        '
        'cmbStaffTue5
        '
        Me.cmbStaffTue5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue5.FormattingEnabled = True
        Me.cmbStaffTue5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffTue5.Name = "cmbStaffTue5"
        Me.cmbStaffTue5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue5.TabIndex = 32
        '
        'cmbShiftTue4
        '
        Me.cmbShiftTue4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue4.Enabled = False
        Me.cmbShiftTue4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue4.FormattingEnabled = True
        Me.cmbShiftTue4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftTue4.Name = "cmbShiftTue4"
        Me.cmbShiftTue4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue4.TabIndex = 31
        '
        'cmbStaffTue4
        '
        Me.cmbStaffTue4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue4.FormattingEnabled = True
        Me.cmbStaffTue4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffTue4.Name = "cmbStaffTue4"
        Me.cmbStaffTue4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue4.TabIndex = 30
        '
        'cmbShiftTue3
        '
        Me.cmbShiftTue3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue3.Enabled = False
        Me.cmbShiftTue3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue3.FormattingEnabled = True
        Me.cmbShiftTue3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftTue3.Name = "cmbShiftTue3"
        Me.cmbShiftTue3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue3.TabIndex = 29
        '
        'cmbStaffTue3
        '
        Me.cmbStaffTue3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue3.FormattingEnabled = True
        Me.cmbStaffTue3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffTue3.Name = "cmbStaffTue3"
        Me.cmbStaffTue3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue3.TabIndex = 28
        '
        'cmbShiftTue2
        '
        Me.cmbShiftTue2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue2.Enabled = False
        Me.cmbShiftTue2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue2.FormattingEnabled = True
        Me.cmbShiftTue2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftTue2.Name = "cmbShiftTue2"
        Me.cmbShiftTue2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue2.TabIndex = 27
        '
        'cmbStaffTue2
        '
        Me.cmbStaffTue2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue2.FormattingEnabled = True
        Me.cmbStaffTue2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffTue2.Name = "cmbStaffTue2"
        Me.cmbStaffTue2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue2.TabIndex = 26
        '
        'cmbShiftTue1
        '
        Me.cmbShiftTue1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftTue1.Enabled = False
        Me.cmbShiftTue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftTue1.FormattingEnabled = True
        Me.cmbShiftTue1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftTue1.Name = "cmbShiftTue1"
        Me.cmbShiftTue1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftTue1.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(54, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(165, 35)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Tuesday"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffTue1
        '
        Me.cmbStaffTue1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffTue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffTue1.FormattingEnabled = True
        Me.cmbStaffTue1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffTue1.Name = "cmbStaffTue1"
        Me.cmbStaffTue1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffTue1.TabIndex = 23
        '
        'pnlDay2
        '
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri6)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri6)
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri5)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri5)
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri4)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri4)
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri3)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri3)
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri2)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri2)
        Me.pnlDay2.Controls.Add(Me.cmbShiftFri1)
        Me.pnlDay2.Controls.Add(Me.Label1)
        Me.pnlDay2.Controls.Add(Me.cmbStaffFri1)
        Me.pnlDay2.Location = New System.Drawing.Point(275, 3)
        Me.pnlDay2.Name = "pnlDay2"
        Me.pnlDay2.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay2.TabIndex = 4
        '
        'cmbShiftFri6
        '
        Me.cmbShiftFri6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri6.Enabled = False
        Me.cmbShiftFri6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri6.FormattingEnabled = True
        Me.cmbShiftFri6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftFri6.Name = "cmbShiftFri6"
        Me.cmbShiftFri6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri6.TabIndex = 35
        '
        'cmbStaffFri6
        '
        Me.cmbStaffFri6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri6.FormattingEnabled = True
        Me.cmbStaffFri6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffFri6.Name = "cmbStaffFri6"
        Me.cmbStaffFri6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri6.TabIndex = 34
        '
        'cmbShiftFri5
        '
        Me.cmbShiftFri5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri5.Enabled = False
        Me.cmbShiftFri5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri5.FormattingEnabled = True
        Me.cmbShiftFri5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftFri5.Name = "cmbShiftFri5"
        Me.cmbShiftFri5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri5.TabIndex = 33
        '
        'cmbStaffFri5
        '
        Me.cmbStaffFri5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri5.FormattingEnabled = True
        Me.cmbStaffFri5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffFri5.Name = "cmbStaffFri5"
        Me.cmbStaffFri5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri5.TabIndex = 32
        '
        'cmbShiftFri4
        '
        Me.cmbShiftFri4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri4.Enabled = False
        Me.cmbShiftFri4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri4.FormattingEnabled = True
        Me.cmbShiftFri4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftFri4.Name = "cmbShiftFri4"
        Me.cmbShiftFri4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri4.TabIndex = 31
        '
        'cmbStaffFri4
        '
        Me.cmbStaffFri4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri4.FormattingEnabled = True
        Me.cmbStaffFri4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffFri4.Name = "cmbStaffFri4"
        Me.cmbStaffFri4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri4.TabIndex = 30
        '
        'cmbShiftFri3
        '
        Me.cmbShiftFri3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri3.Enabled = False
        Me.cmbShiftFri3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri3.FormattingEnabled = True
        Me.cmbShiftFri3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftFri3.Name = "cmbShiftFri3"
        Me.cmbShiftFri3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri3.TabIndex = 29
        '
        'cmbStaffFri3
        '
        Me.cmbStaffFri3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri3.FormattingEnabled = True
        Me.cmbStaffFri3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffFri3.Name = "cmbStaffFri3"
        Me.cmbStaffFri3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri3.TabIndex = 28
        '
        'cmbShiftFri2
        '
        Me.cmbShiftFri2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri2.Enabled = False
        Me.cmbShiftFri2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri2.FormattingEnabled = True
        Me.cmbShiftFri2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftFri2.Name = "cmbShiftFri2"
        Me.cmbShiftFri2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri2.TabIndex = 27
        '
        'cmbStaffFri2
        '
        Me.cmbStaffFri2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri2.FormattingEnabled = True
        Me.cmbStaffFri2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffFri2.Name = "cmbStaffFri2"
        Me.cmbStaffFri2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri2.TabIndex = 26
        '
        'cmbShiftFri1
        '
        Me.cmbShiftFri1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftFri1.Enabled = False
        Me.cmbShiftFri1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftFri1.FormattingEnabled = True
        Me.cmbShiftFri1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftFri1.Name = "cmbShiftFri1"
        Me.cmbShiftFri1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftFri1.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 35)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Friday"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffFri1
        '
        Me.cmbStaffFri1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffFri1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffFri1.FormattingEnabled = True
        Me.cmbStaffFri1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffFri1.Name = "cmbStaffFri1"
        Me.cmbStaffFri1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffFri1.TabIndex = 23
        '
        'pnlDay5
        '
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon1)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon6)
        Me.pnlDay5.Controls.Add(Me.Label4)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon1)
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon6)
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon2)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon2)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon5)
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon3)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon3)
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon5)
        Me.pnlDay5.Controls.Add(Me.cmbStaffMon4)
        Me.pnlDay5.Controls.Add(Me.cmbShiftMon4)
        Me.pnlDay5.Location = New System.Drawing.Point(1082, 3)
        Me.pnlDay5.Name = "pnlDay5"
        Me.pnlDay5.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay5.TabIndex = 0
        '
        'cmbStaffMon1
        '
        Me.cmbStaffMon1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon1.FormattingEnabled = True
        Me.cmbStaffMon1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffMon1.Name = "cmbStaffMon1"
        Me.cmbStaffMon1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon1.TabIndex = 23
        '
        'cmbShiftMon6
        '
        Me.cmbShiftMon6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon6.Enabled = False
        Me.cmbShiftMon6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon6.FormattingEnabled = True
        Me.cmbShiftMon6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftMon6.Name = "cmbShiftMon6"
        Me.cmbShiftMon6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon6.TabIndex = 35
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(56, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(158, 35)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Monday"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbShiftMon1
        '
        Me.cmbShiftMon1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon1.Enabled = False
        Me.cmbShiftMon1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon1.FormattingEnabled = True
        Me.cmbShiftMon1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftMon1.Name = "cmbShiftMon1"
        Me.cmbShiftMon1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon1.TabIndex = 25
        '
        'cmbStaffMon6
        '
        Me.cmbStaffMon6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon6.FormattingEnabled = True
        Me.cmbStaffMon6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffMon6.Name = "cmbStaffMon6"
        Me.cmbStaffMon6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon6.TabIndex = 34
        '
        'cmbStaffMon2
        '
        Me.cmbStaffMon2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon2.FormattingEnabled = True
        Me.cmbStaffMon2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffMon2.Name = "cmbStaffMon2"
        Me.cmbStaffMon2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon2.TabIndex = 26
        '
        'cmbShiftMon2
        '
        Me.cmbShiftMon2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon2.Enabled = False
        Me.cmbShiftMon2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon2.FormattingEnabled = True
        Me.cmbShiftMon2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftMon2.Name = "cmbShiftMon2"
        Me.cmbShiftMon2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon2.TabIndex = 27
        '
        'cmbShiftMon5
        '
        Me.cmbShiftMon5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon5.Enabled = False
        Me.cmbShiftMon5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon5.FormattingEnabled = True
        Me.cmbShiftMon5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftMon5.Name = "cmbShiftMon5"
        Me.cmbShiftMon5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon5.TabIndex = 33
        '
        'cmbStaffMon3
        '
        Me.cmbStaffMon3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon3.FormattingEnabled = True
        Me.cmbStaffMon3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffMon3.Name = "cmbStaffMon3"
        Me.cmbStaffMon3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon3.TabIndex = 28
        '
        'cmbShiftMon3
        '
        Me.cmbShiftMon3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon3.Enabled = False
        Me.cmbShiftMon3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon3.FormattingEnabled = True
        Me.cmbShiftMon3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftMon3.Name = "cmbShiftMon3"
        Me.cmbShiftMon3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon3.TabIndex = 29
        '
        'cmbStaffMon5
        '
        Me.cmbStaffMon5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon5.FormattingEnabled = True
        Me.cmbStaffMon5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffMon5.Name = "cmbStaffMon5"
        Me.cmbStaffMon5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon5.TabIndex = 32
        '
        'cmbStaffMon4
        '
        Me.cmbStaffMon4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffMon4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffMon4.FormattingEnabled = True
        Me.cmbStaffMon4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffMon4.Name = "cmbStaffMon4"
        Me.cmbStaffMon4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffMon4.TabIndex = 30
        '
        'cmbShiftMon4
        '
        Me.cmbShiftMon4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftMon4.Enabled = False
        Me.cmbShiftMon4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftMon4.FormattingEnabled = True
        Me.cmbShiftMon4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftMon4.Name = "cmbShiftMon4"
        Me.cmbShiftMon4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftMon4.TabIndex = 31
        '
        'pnlDay4
        '
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun6)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun6)
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun5)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun5)
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun4)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun4)
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun3)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun3)
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun2)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun2)
        Me.pnlDay4.Controls.Add(Me.cmbShiftSun1)
        Me.pnlDay4.Controls.Add(Me.Label3)
        Me.pnlDay4.Controls.Add(Me.cmbStaffSun1)
        Me.pnlDay4.Location = New System.Drawing.Point(813, 3)
        Me.pnlDay4.Name = "pnlDay4"
        Me.pnlDay4.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay4.TabIndex = 3
        '
        'cmbShiftSun6
        '
        Me.cmbShiftSun6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun6.Enabled = False
        Me.cmbShiftSun6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun6.FormattingEnabled = True
        Me.cmbShiftSun6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftSun6.Name = "cmbShiftSun6"
        Me.cmbShiftSun6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun6.TabIndex = 35
        '
        'cmbStaffSun6
        '
        Me.cmbStaffSun6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun6.FormattingEnabled = True
        Me.cmbStaffSun6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffSun6.Name = "cmbStaffSun6"
        Me.cmbStaffSun6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun6.TabIndex = 34
        '
        'cmbShiftSun5
        '
        Me.cmbShiftSun5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun5.Enabled = False
        Me.cmbShiftSun5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun5.FormattingEnabled = True
        Me.cmbShiftSun5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftSun5.Name = "cmbShiftSun5"
        Me.cmbShiftSun5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun5.TabIndex = 33
        '
        'cmbStaffSun5
        '
        Me.cmbStaffSun5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun5.FormattingEnabled = True
        Me.cmbStaffSun5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffSun5.Name = "cmbStaffSun5"
        Me.cmbStaffSun5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun5.TabIndex = 32
        '
        'cmbShiftSun4
        '
        Me.cmbShiftSun4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun4.Enabled = False
        Me.cmbShiftSun4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun4.FormattingEnabled = True
        Me.cmbShiftSun4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftSun4.Name = "cmbShiftSun4"
        Me.cmbShiftSun4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun4.TabIndex = 31
        '
        'cmbStaffSun4
        '
        Me.cmbStaffSun4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun4.FormattingEnabled = True
        Me.cmbStaffSun4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffSun4.Name = "cmbStaffSun4"
        Me.cmbStaffSun4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun4.TabIndex = 30
        '
        'cmbShiftSun3
        '
        Me.cmbShiftSun3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun3.Enabled = False
        Me.cmbShiftSun3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun3.FormattingEnabled = True
        Me.cmbShiftSun3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftSun3.Name = "cmbShiftSun3"
        Me.cmbShiftSun3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun3.TabIndex = 29
        '
        'cmbStaffSun3
        '
        Me.cmbStaffSun3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun3.FormattingEnabled = True
        Me.cmbStaffSun3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffSun3.Name = "cmbStaffSun3"
        Me.cmbStaffSun3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun3.TabIndex = 28
        '
        'cmbShiftSun2
        '
        Me.cmbShiftSun2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun2.Enabled = False
        Me.cmbShiftSun2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun2.FormattingEnabled = True
        Me.cmbShiftSun2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftSun2.Name = "cmbShiftSun2"
        Me.cmbShiftSun2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun2.TabIndex = 27
        '
        'cmbStaffSun2
        '
        Me.cmbStaffSun2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun2.FormattingEnabled = True
        Me.cmbStaffSun2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffSun2.Name = "cmbStaffSun2"
        Me.cmbStaffSun2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun2.TabIndex = 26
        '
        'cmbShiftSun1
        '
        Me.cmbShiftSun1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSun1.Enabled = False
        Me.cmbShiftSun1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSun1.FormattingEnabled = True
        Me.cmbShiftSun1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftSun1.Name = "cmbShiftSun1"
        Me.cmbShiftSun1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSun1.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(60, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 35)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Sunday"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffSun1
        '
        Me.cmbStaffSun1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSun1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSun1.FormattingEnabled = True
        Me.cmbStaffSun1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffSun1.Name = "cmbStaffSun1"
        Me.cmbStaffSun1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSun1.TabIndex = 23
        '
        'pnlDay3
        '
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat6)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat1)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat6)
        Me.pnlDay3.Controls.Add(Me.Label2)
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat5)
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat1)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat5)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat2)
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat4)
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat2)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat4)
        Me.pnlDay3.Controls.Add(Me.cmbStaffSat3)
        Me.pnlDay3.Controls.Add(Me.cmbShiftSat3)
        Me.pnlDay3.Location = New System.Drawing.Point(544, 3)
        Me.pnlDay3.Name = "pnlDay3"
        Me.pnlDay3.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay3.TabIndex = 2
        '
        'cmbShiftSat6
        '
        Me.cmbShiftSat6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat6.Enabled = False
        Me.cmbShiftSat6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat6.FormattingEnabled = True
        Me.cmbShiftSat6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftSat6.Name = "cmbShiftSat6"
        Me.cmbShiftSat6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat6.TabIndex = 48
        '
        'cmbStaffSat1
        '
        Me.cmbStaffSat1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat1.FormattingEnabled = True
        Me.cmbStaffSat1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffSat1.Name = "cmbStaffSat1"
        Me.cmbStaffSat1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat1.TabIndex = 36
        '
        'cmbStaffSat6
        '
        Me.cmbStaffSat6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat6.FormattingEnabled = True
        Me.cmbStaffSat6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffSat6.Name = "cmbStaffSat6"
        Me.cmbStaffSat6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat6.TabIndex = 47
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(43, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(190, 35)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Saturday"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbShiftSat5
        '
        Me.cmbShiftSat5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat5.Enabled = False
        Me.cmbShiftSat5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat5.FormattingEnabled = True
        Me.cmbShiftSat5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftSat5.Name = "cmbShiftSat5"
        Me.cmbShiftSat5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat5.TabIndex = 46
        '
        'cmbShiftSat1
        '
        Me.cmbShiftSat1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat1.Enabled = False
        Me.cmbShiftSat1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat1.FormattingEnabled = True
        Me.cmbShiftSat1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftSat1.Name = "cmbShiftSat1"
        Me.cmbShiftSat1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat1.TabIndex = 38
        '
        'cmbStaffSat5
        '
        Me.cmbStaffSat5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat5.FormattingEnabled = True
        Me.cmbStaffSat5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffSat5.Name = "cmbStaffSat5"
        Me.cmbStaffSat5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat5.TabIndex = 45
        '
        'cmbStaffSat2
        '
        Me.cmbStaffSat2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat2.FormattingEnabled = True
        Me.cmbStaffSat2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffSat2.Name = "cmbStaffSat2"
        Me.cmbStaffSat2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat2.TabIndex = 39
        '
        'cmbShiftSat4
        '
        Me.cmbShiftSat4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat4.Enabled = False
        Me.cmbShiftSat4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat4.FormattingEnabled = True
        Me.cmbShiftSat4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftSat4.Name = "cmbShiftSat4"
        Me.cmbShiftSat4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat4.TabIndex = 44
        '
        'cmbShiftSat2
        '
        Me.cmbShiftSat2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat2.Enabled = False
        Me.cmbShiftSat2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat2.FormattingEnabled = True
        Me.cmbShiftSat2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftSat2.Name = "cmbShiftSat2"
        Me.cmbShiftSat2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat2.TabIndex = 40
        '
        'cmbStaffSat4
        '
        Me.cmbStaffSat4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat4.FormattingEnabled = True
        Me.cmbStaffSat4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffSat4.Name = "cmbStaffSat4"
        Me.cmbStaffSat4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat4.TabIndex = 43
        '
        'cmbStaffSat3
        '
        Me.cmbStaffSat3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffSat3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffSat3.FormattingEnabled = True
        Me.cmbStaffSat3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffSat3.Name = "cmbStaffSat3"
        Me.cmbStaffSat3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffSat3.TabIndex = 41
        '
        'cmbShiftSat3
        '
        Me.cmbShiftSat3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftSat3.Enabled = False
        Me.cmbShiftSat3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftSat3.FormattingEnabled = True
        Me.cmbShiftSat3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftSat3.Name = "cmbShiftSat3"
        Me.cmbShiftSat3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftSat3.TabIndex = 42
        '
        'pnlDay1
        '
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu6)
        Me.pnlDay1.Controls.Add(Me.lblThursday)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu6)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu1)
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu5)
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu1)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu5)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu2)
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu4)
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu2)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu4)
        Me.pnlDay1.Controls.Add(Me.cmbStaffThu3)
        Me.pnlDay1.Controls.Add(Me.cmbShiftThu3)
        Me.pnlDay1.Location = New System.Drawing.Point(6, 3)
        Me.pnlDay1.Name = "pnlDay1"
        Me.pnlDay1.Size = New System.Drawing.Size(270, 858)
        Me.pnlDay1.TabIndex = 1
        '
        'cmbShiftThu6
        '
        Me.cmbShiftThu6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu6.Enabled = False
        Me.cmbShiftThu6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu6.FormattingEnabled = True
        Me.cmbShiftThu6.Location = New System.Drawing.Point(3, 789)
        Me.cmbShiftThu6.Name = "cmbShiftThu6"
        Me.cmbShiftThu6.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu6.TabIndex = 22
        '
        'lblThursday
        '
        Me.lblThursday.AutoSize = True
        Me.lblThursday.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThursday.Location = New System.Drawing.Point(39, 27)
        Me.lblThursday.Name = "lblThursday"
        Me.lblThursday.Size = New System.Drawing.Size(190, 35)
        Me.lblThursday.TabIndex = 11
        Me.lblThursday.Text = "Thursday"
        Me.lblThursday.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffThu6
        '
        Me.cmbStaffThu6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu6.FormattingEnabled = True
        Me.cmbStaffThu6.Location = New System.Drawing.Point(3, 744)
        Me.cmbStaffThu6.Name = "cmbStaffThu6"
        Me.cmbStaffThu6.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu6.TabIndex = 21
        '
        'cmbStaffThu1
        '
        Me.cmbStaffThu1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu1.FormattingEnabled = True
        Me.cmbStaffThu1.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffThu1.Name = "cmbStaffThu1"
        Me.cmbStaffThu1.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu1.TabIndex = 0
        '
        'cmbShiftThu5
        '
        Me.cmbShiftThu5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu5.Enabled = False
        Me.cmbShiftThu5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu5.FormattingEnabled = True
        Me.cmbShiftThu5.Location = New System.Drawing.Point(3, 659)
        Me.cmbShiftThu5.Name = "cmbShiftThu5"
        Me.cmbShiftThu5.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu5.TabIndex = 20
        '
        'cmbShiftThu1
        '
        Me.cmbShiftThu1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu1.Enabled = False
        Me.cmbShiftThu1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu1.FormattingEnabled = True
        Me.cmbShiftThu1.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftThu1.Name = "cmbShiftThu1"
        Me.cmbShiftThu1.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu1.TabIndex = 12
        '
        'cmbStaffThu5
        '
        Me.cmbStaffThu5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu5.FormattingEnabled = True
        Me.cmbStaffThu5.Location = New System.Drawing.Point(3, 614)
        Me.cmbStaffThu5.Name = "cmbStaffThu5"
        Me.cmbStaffThu5.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu5.TabIndex = 19
        '
        'cmbStaffThu2
        '
        Me.cmbStaffThu2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu2.FormattingEnabled = True
        Me.cmbStaffThu2.Location = New System.Drawing.Point(3, 219)
        Me.cmbStaffThu2.Name = "cmbStaffThu2"
        Me.cmbStaffThu2.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu2.TabIndex = 13
        '
        'cmbShiftThu4
        '
        Me.cmbShiftThu4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu4.Enabled = False
        Me.cmbShiftThu4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu4.FormattingEnabled = True
        Me.cmbShiftThu4.Location = New System.Drawing.Point(3, 528)
        Me.cmbShiftThu4.Name = "cmbShiftThu4"
        Me.cmbShiftThu4.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu4.TabIndex = 18
        '
        'cmbShiftThu2
        '
        Me.cmbShiftThu2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu2.Enabled = False
        Me.cmbShiftThu2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu2.FormattingEnabled = True
        Me.cmbShiftThu2.Location = New System.Drawing.Point(3, 264)
        Me.cmbShiftThu2.Name = "cmbShiftThu2"
        Me.cmbShiftThu2.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu2.TabIndex = 14
        '
        'cmbStaffThu4
        '
        Me.cmbStaffThu4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu4.FormattingEnabled = True
        Me.cmbStaffThu4.Location = New System.Drawing.Point(3, 483)
        Me.cmbStaffThu4.Name = "cmbStaffThu4"
        Me.cmbStaffThu4.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu4.TabIndex = 17
        '
        'cmbStaffThu3
        '
        Me.cmbStaffThu3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu3.FormattingEnabled = True
        Me.cmbStaffThu3.Location = New System.Drawing.Point(3, 352)
        Me.cmbStaffThu3.Name = "cmbStaffThu3"
        Me.cmbStaffThu3.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu3.TabIndex = 15
        '
        'cmbShiftThu3
        '
        Me.cmbShiftThu3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu3.Enabled = False
        Me.cmbShiftThu3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu3.FormattingEnabled = True
        Me.cmbShiftThu3.Location = New System.Drawing.Point(3, 397)
        Me.cmbShiftThu3.Name = "cmbShiftThu3"
        Me.cmbShiftThu3.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu3.TabIndex = 16
        '
        'lblTitleMain
        '
        Me.lblTitleMain.AutoSize = True
        Me.lblTitleMain.Font = New System.Drawing.Font("Geometos", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleMain.Location = New System.Drawing.Point(758, 50)
        Me.lblTitleMain.Name = "lblTitleMain"
        Me.lblTitleMain.Size = New System.Drawing.Size(579, 44)
        Me.lblTitleMain.TabIndex = 4
        Me.lblTitleMain.Text = "Roster Creation System"
        '
        'ctxGlobal
        '
        Me.ctxGlobal.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ctxGlobal.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnAbout})
        Me.ctxGlobal.Name = "ctxGlobal"
        Me.ctxGlobal.Size = New System.Drawing.Size(227, 28)
        '
        'btnAbout
        '
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(226, 24)
        Me.btnAbout.Text = "About Roster Program"
        '
        'btnCloseApp
        '
        Me.btnCloseApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseApp.Location = New System.Drawing.Point(1542, 1008)
        Me.btnCloseApp.Name = "btnCloseApp"
        Me.btnCloseApp.Size = New System.Drawing.Size(180, 60)
        Me.btnCloseApp.TabIndex = 5
        Me.btnCloseApp.Text = "Cancel and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Close All"
        Me.btnCloseApp.UseVisualStyleBackColor = True
        '
        'btnSearchArchive
        '
        Me.btnSearchArchive.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchArchive.Location = New System.Drawing.Point(944, 1008)
        Me.btnSearchArchive.Name = "btnSearchArchive"
        Me.btnSearchArchive.Size = New System.Drawing.Size(180, 60)
        Me.btnSearchArchive.TabIndex = 1
        Me.btnSearchArchive.Text = "Search" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Archive"
        Me.btnSearchArchive.UseVisualStyleBackColor = True
        '
        'btnEditData
        '
        Me.btnEditData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditData.Location = New System.Drawing.Point(572, 1008)
        Me.btnEditData.Name = "btnEditData"
        Me.btnEditData.Size = New System.Drawing.Size(180, 60)
        Me.btnEditData.TabIndex = 2
        Me.btnEditData.Text = "Modify" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Employee Data"
        Me.btnEditData.UseVisualStyleBackColor = True
        '
        'btnEditPin
        '
        Me.btnEditPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditPin.Location = New System.Drawing.Point(384, 1008)
        Me.btnEditPin.Name = "btnEditPin"
        Me.btnEditPin.Size = New System.Drawing.Size(180, 60)
        Me.btnEditPin.TabIndex = 4
        Me.btnEditPin.Text = "Change" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "User PIN"
        Me.btnEditPin.UseVisualStyleBackColor = True
        '
        'btnEditShifts
        '
        Me.btnEditShifts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditShifts.Location = New System.Drawing.Point(758, 1008)
        Me.btnEditShifts.Name = "btnEditShifts"
        Me.btnEditShifts.Size = New System.Drawing.Size(180, 60)
        Me.btnEditShifts.TabIndex = 3
        Me.btnEditShifts.Text = "Edit" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Shift Blocks"
        Me.btnEditShifts.UseVisualStyleBackColor = True
        '
        'picLogoMain
        '
        Me.picLogoMain.Image = Global.WindowsApp1.My.Resources.Resources.logo
        Me.picLogoMain.Location = New System.Drawing.Point(632, 12)
        Me.picLogoMain.Name = "picLogoMain"
        Me.picLogoMain.Size = New System.Drawing.Size(120, 120)
        Me.picLogoMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLogoMain.TabIndex = 3
        Me.picLogoMain.TabStop = False
        '
        'btnSuggestRoster
        '
        Me.btnSuggestRoster.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSuggestRoster.Location = New System.Drawing.Point(1356, 1008)
        Me.btnSuggestRoster.Name = "btnSuggestRoster"
        Me.btnSuggestRoster.Size = New System.Drawing.Size(180, 60)
        Me.btnSuggestRoster.TabIndex = 7
        Me.btnSuggestRoster.Text = "Suggest" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Roster"
        Me.btnSuggestRoster.UseVisualStyleBackColor = True
        '
        'btnLoadSuggested
        '
        Me.btnLoadSuggested.Enabled = False
        Me.btnLoadSuggested.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoadSuggested.Location = New System.Drawing.Point(198, 1008)
        Me.btnLoadSuggested.Name = "btnLoadSuggested"
        Me.btnLoadSuggested.Size = New System.Drawing.Size(180, 60)
        Me.btnLoadSuggested.TabIndex = 8
        Me.btnLoadSuggested.Text = "Load Suggested Roster"
        Me.btnLoadSuggested.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1920, 1080)
        Me.ContextMenuStrip = Me.ctxGlobal
        Me.Controls.Add(Me.btnLoadSuggested)
        Me.Controls.Add(Me.btnSuggestRoster)
        Me.Controls.Add(Me.btnEditPin)
        Me.Controls.Add(Me.btnEditShifts)
        Me.Controls.Add(Me.btnEditData)
        Me.Controls.Add(Me.btnSearchArchive)
        Me.Controls.Add(Me.btnCloseApp)
        Me.Controls.Add(Me.lblTitleMain)
        Me.Controls.Add(Me.picLogoMain)
        Me.Controls.Add(Me.pnlRoster)
        Me.Controls.Add(Me.btnSendRoster)
        Me.Controls.Add(Me.btnLoadLast)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "Roster Generation Program"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pnlRoster.ResumeLayout(False)
        Me.pnlDay7.ResumeLayout(False)
        Me.pnlDay7.PerformLayout()
        Me.pnlDay6.ResumeLayout(False)
        Me.pnlDay6.PerformLayout()
        Me.pnlDay2.ResumeLayout(False)
        Me.pnlDay2.PerformLayout()
        Me.pnlDay5.ResumeLayout(False)
        Me.pnlDay5.PerformLayout()
        Me.pnlDay4.ResumeLayout(False)
        Me.pnlDay4.PerformLayout()
        Me.pnlDay3.ResumeLayout(False)
        Me.pnlDay3.PerformLayout()
        Me.pnlDay1.ResumeLayout(False)
        Me.pnlDay1.PerformLayout()
        Me.ctxGlobal.ResumeLayout(False)
        CType(Me.picLogoMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnLoadLast As Button
    Friend WithEvents btnSendRoster As Button
    Friend WithEvents pnlRoster As Panel
    Friend WithEvents picLogoMain As PictureBox
    Friend WithEvents lblTitleMain As Label
    Friend WithEvents ctxGlobal As ContextMenuStrip
    Friend WithEvents btnAbout As ToolStripMenuItem
    Friend WithEvents btnCloseApp As Button
    Friend WithEvents btnSearchArchive As Button
    Friend WithEvents btnEditData As Button
    Friend WithEvents btnEditPin As Button
    Friend WithEvents btnEditShifts As Button
    Friend WithEvents pnlDay5 As Panel
    Friend WithEvents pnlDay7 As Panel
    Friend WithEvents pnlDay6 As Panel
    Friend WithEvents pnlDay2 As Panel
    Friend WithEvents pnlDay4 As Panel
    Friend WithEvents pnlDay3 As Panel
    Friend WithEvents pnlDay1 As Panel
    Friend WithEvents cmbShiftThu1 As ComboBox
    Friend WithEvents lblThursday As Label
    Friend WithEvents cmbStaffThu1 As ComboBox
    Friend WithEvents cmbShiftWed6 As ComboBox
    Friend WithEvents cmbStaffWed6 As ComboBox
    Friend WithEvents cmbShiftWed5 As ComboBox
    Friend WithEvents cmbStaffWed5 As ComboBox
    Friend WithEvents cmbShiftWed4 As ComboBox
    Friend WithEvents cmbStaffWed4 As ComboBox
    Friend WithEvents cmbShiftWed3 As ComboBox
    Friend WithEvents cmbStaffWed3 As ComboBox
    Friend WithEvents cmbShiftWed2 As ComboBox
    Friend WithEvents cmbStaffWed2 As ComboBox
    Friend WithEvents cmbShiftWed1 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbStaffWed1 As ComboBox
    Friend WithEvents cmbShiftTue6 As ComboBox
    Friend WithEvents cmbStaffTue6 As ComboBox
    Friend WithEvents cmbShiftTue5 As ComboBox
    Friend WithEvents cmbStaffTue5 As ComboBox
    Friend WithEvents cmbShiftTue4 As ComboBox
    Friend WithEvents cmbStaffTue4 As ComboBox
    Friend WithEvents cmbShiftTue3 As ComboBox
    Friend WithEvents cmbStaffTue3 As ComboBox
    Friend WithEvents cmbShiftTue2 As ComboBox
    Friend WithEvents cmbStaffTue2 As ComboBox
    Friend WithEvents cmbShiftTue1 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbStaffTue1 As ComboBox
    Friend WithEvents cmbShiftMon6 As ComboBox
    Friend WithEvents cmbStaffMon6 As ComboBox
    Friend WithEvents cmbShiftMon5 As ComboBox
    Friend WithEvents cmbStaffMon5 As ComboBox
    Friend WithEvents cmbShiftMon4 As ComboBox
    Friend WithEvents cmbStaffMon4 As ComboBox
    Friend WithEvents cmbShiftMon3 As ComboBox
    Friend WithEvents cmbStaffMon3 As ComboBox
    Friend WithEvents cmbShiftMon2 As ComboBox
    Friend WithEvents cmbStaffMon2 As ComboBox
    Friend WithEvents cmbShiftMon1 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cmbStaffMon1 As ComboBox
    Friend WithEvents cmbShiftSun6 As ComboBox
    Friend WithEvents cmbStaffSun6 As ComboBox
    Friend WithEvents cmbShiftSun5 As ComboBox
    Friend WithEvents cmbStaffSun5 As ComboBox
    Friend WithEvents cmbShiftSun4 As ComboBox
    Friend WithEvents cmbStaffSun4 As ComboBox
    Friend WithEvents cmbShiftSun3 As ComboBox
    Friend WithEvents cmbStaffSun3 As ComboBox
    Friend WithEvents cmbShiftSun2 As ComboBox
    Friend WithEvents cmbStaffSun2 As ComboBox
    Friend WithEvents cmbShiftSun1 As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbStaffSun1 As ComboBox
    Friend WithEvents cmbShiftSat6 As ComboBox
    Friend WithEvents cmbStaffSat1 As ComboBox
    Friend WithEvents cmbStaffSat6 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbShiftSat5 As ComboBox
    Friend WithEvents cmbShiftSat1 As ComboBox
    Friend WithEvents cmbStaffSat5 As ComboBox
    Friend WithEvents cmbStaffSat2 As ComboBox
    Friend WithEvents cmbShiftSat4 As ComboBox
    Friend WithEvents cmbShiftSat2 As ComboBox
    Friend WithEvents cmbStaffSat4 As ComboBox
    Friend WithEvents cmbStaffSat3 As ComboBox
    Friend WithEvents cmbShiftSat3 As ComboBox
    Friend WithEvents cmbShiftFri6 As ComboBox
    Friend WithEvents cmbStaffFri6 As ComboBox
    Friend WithEvents cmbShiftFri5 As ComboBox
    Friend WithEvents cmbStaffFri5 As ComboBox
    Friend WithEvents cmbShiftFri4 As ComboBox
    Friend WithEvents cmbStaffFri4 As ComboBox
    Friend WithEvents cmbShiftFri3 As ComboBox
    Friend WithEvents cmbStaffFri3 As ComboBox
    Friend WithEvents cmbShiftFri2 As ComboBox
    Friend WithEvents cmbStaffFri2 As ComboBox
    Friend WithEvents cmbShiftFri1 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbStaffFri1 As ComboBox
    Friend WithEvents cmbShiftThu6 As ComboBox
    Friend WithEvents cmbStaffThu6 As ComboBox
    Friend WithEvents cmbShiftThu5 As ComboBox
    Friend WithEvents cmbStaffThu5 As ComboBox
    Friend WithEvents cmbShiftThu4 As ComboBox
    Friend WithEvents cmbStaffThu4 As ComboBox
    Friend WithEvents cmbShiftThu3 As ComboBox
    Friend WithEvents cmbStaffThu3 As ComboBox
    Friend WithEvents cmbShiftThu2 As ComboBox
    Friend WithEvents cmbStaffThu2 As ComboBox
    Friend WithEvents btnSuggestRoster As Button
    Friend WithEvents btnLoadSuggested As Button
End Class
