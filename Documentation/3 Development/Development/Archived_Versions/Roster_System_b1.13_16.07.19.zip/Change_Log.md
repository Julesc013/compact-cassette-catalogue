# Blue Dog Café Rostering System Change Log

## Releases



### To Do

- Regex validation for PINs and Employee Data and Availability.
- Encryption of workbooks.
- Quick information (empty shift combination boxes, shifts not updating).
- Change some public variables to private variables.
- Restore start-up form to log-on screen.
- Check if staff can be put on a closing shift.
- Allow user to cancel changing PIN.
- Add more comprehensive code comments.
- Fix the fact that emails won't send.

fix bug where saving shifts adds another set of employee names to roster board



## Betas



### Version 1.13 (July 16)

- Shifts can now be added.
- Shifts can now be removed.
- Shifts are now saved to file upon accepting changes.
- Added progress bar to shift saving procedure.
- Changed all record structures to 'lists of T'.
- Updated all data loading procedures to handle 'list of T' behaviour.



### Version 1.12 (July 16)

- Search results can now be sorted.
- Made search results record structure public to class.
- Minor changes in displaying and saving results.
- Fixed more minor search bugs.



### Version 1.11 (July 16)

- Added progress bar to search procedure.
- Search results can now be saved to a text file.
- Fixed some minor search bugs.



### Version 1.10 (July 15)

- Fixed a lot of archive searching bugs (basically redid the whole thing).
- Separated search results into two list boxes.
- Some forms now reload when child forms have changed data that they use.
- Fixed bug in time formatting subroutines.



### Version 1.9 (July 15)

- Can now suggest rosters.
- Moved roster saving functionality to a subroutine of its own.



### Version 1.8 (July 15)

- Fixed a stupid amount of roster loading bugs (names and shifts not appearing).
- Added progress bar to roster loading.



### Version 1.7 (July 15)

- Suggested rosters can be loaded.
- Rosters sent within the week and the week prior can be loaded.



### Version 1.6 (July 14)

- Custom colour codes are now stored in the records.
- Can now change user PIN once logged on.
- Roster can now be saved to an Excel spreadsheet (including formatting).
- Roster can now be archived and sent via email.
- Added progress bar for user-friendliness.



### Version 1.5 (July 14)

- Ability to add corresponding shifts to selected staff members in roster.
- Restructured availability storage system (fixed loading bug).
- Lots of bug fixes.



### Version 1.4 (July 13)

- Added global structures to store user data.
- Added code to load data from file upon logon.
- Creates missing files upon first load.
- Added collections of all combination boxes.
- Restructured declarations of variables.



### Version 1.3 (July 12)

- Implemented Linear Search function (and associated methods).
- Modified roster naming and storage methods.
- Can now identify if a roster was sent within the week.



### Version 1.2 (June 1)

- Revised PIN creation prompt text.
- Fixed combo-box names in main form.
- Setup more global variables.
- Declared all variables in main form.
- Added code to show/hide user-specific objects/functions.
- Roster naming and referencing code.
- Added unused code for getting day index of the week.



### Version 1.1 (May 31)

- Added PIN creation code.
- Added logon code (PIN checking).
- Enter key mapped to Log-on button.



### Version 1.0 (May 29)

- Moved global variables and subroutines from forms to a module.
- Added internal settings for storage of user PINs.



### Version 0.6 (May 24)

- Added screen resolution check and warning.



### Version 0.1 – 0.5 (May 16)

- Iteratively designed all forms.
- Added placeholder code for opening/closing forms.
- Added program and version information.

