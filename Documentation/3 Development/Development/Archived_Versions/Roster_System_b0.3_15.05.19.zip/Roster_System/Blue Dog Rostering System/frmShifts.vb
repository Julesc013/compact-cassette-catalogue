﻿Public Class frmShifts
    Private Sub frmData_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtStartTime_Click(sender As Object, e As EventArgs) Handles txtStartTime.Click
        txtStartTime.Text = ""
    End Sub

    Private Sub txtEndTime_Click(sender As Object, e As EventArgs) Handles txtEndTime.Click
        txtEndTime.Text = ""
    End Sub
End Class