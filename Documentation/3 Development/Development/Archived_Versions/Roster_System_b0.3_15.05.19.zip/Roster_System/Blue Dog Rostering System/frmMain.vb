﻿Public Class frmMain

    Const versionNumber As String = "0.3"

    Sub closeApplication()
        'save and close
        Application.Exit()
    End Sub

    Sub aboutProgram()
        MsgBox("Blue Dog Cafe Rostering System" & vbNewLine & "Version " & versionNumber & vbNewLine & "Jules Carboni, 2019", MsgBoxStyle.Information, "About Rostering System")
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        aboutProgram()
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        closeApplication()
    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click
        frmData.Show()
    End Sub

    Private Sub btnEditShifts_Click(sender As Object, e As EventArgs) Handles btnEditShifts.Click
        frmShifts.Show()
    End Sub

    Private Sub btnEditPIN_Click(sender As Object, e As EventArgs) Handles btnEditPIN.Click
        InputBox("Enter current/old PIN for user-group " & "$$")
    End Sub

    Private Sub btnSendRoster_Click(sender As Object, e As EventArgs) Handles btnSendRoster.Click
        MsgBox("Sent, yo.")
    End Sub

    Private Sub btnSearchArchive_Click(sender As Object, e As EventArgs) Handles btnSearchArchive.Click
        frmSearch.Show()
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogo.Click
        aboutProgram()
    End Sub
End Class
