﻿' Name:             Main Roster Generation
' Purpose:          Creates and sends rosters. Provides buttons for accessing other forms (is root from).
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    14 July 2019

Imports System.Globalization
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel 'Import Excel functionality

Public Class frmMain

    Private Sub getShifts(ByVal dayNumber As Integer, ByVal staffNumber As Integer, ByVal employeeName As String)
        'Populate combination boxes with compatible shifts for selected employee
        'dayNumber in range 1 to 7, and staffNumber in range 1 to 6.

        'Find combination box to be modified
        'Source: https://www.daniweb.com/programming/software-development/threads/421591/want-to-find-all-textboxes-on-a-form
        Dim panelList() As Panel = pnlRoster.Controls.OfType(Of Panel)().OrderBy(Function(o) o.Name).ToArray() 'list of each day of the week
        Dim comboList() As ComboBox = panelList(dayNumber - 1).Controls.OfType(Of ComboBox)().OrderBy(Function(o) o.Name).ToArray() 'List of every combobox in that day's panel
        Dim comboBox As ComboBox = comboList(staffNumber - 1)

        comboBox.Items.Clear() 'Clear all items

        If employeeName = "" Then

            comboBox.Enabled = False 'Disable ability to use

        Else

            'Find employee's information in the record structure
            'Source: https://stackoverflow.com/questions/28998204/find-item-in-array-of-structure
            Dim employeeIndex As Integer = Array.FindIndex(employeeData, Function(f) f.nameFull = employeeName)
            Dim employeeAvailability As availabilityStructure = availability(7 * employeeIndex + (dayNumber - 1))

            'Populate with all valid shifts
            Dim index As Integer
            For index = 0 To shiftCount - 1

                Dim shiftStart As Integer = shiftData(index).timeStart
                Dim shiftFinish As Integer = shiftData(index).timeFinish

                If employeeAvailability.timeStart <= shiftStart And employeeAvailability.timeFinish >= shiftFinish Then
                    'If the selected employee can work this shift, add to items.
                    comboBox.Items.Add(minToTime(shiftStart) & " - " & minToTime(shiftFinish))
                End If

            Next

            comboBox.Enabled = True

        End If

    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ''ReDim employeeData(MAXEMPLOYEE).availability(7) 'Resize array (because could not do in declaration)

        'Check that the root folder exists, if not create it
        'Source: https://stackoverflow.com/questions/85996/how-do-i-create-a-folder-in-vb-if-it-doesnt-exist

        If Not Directory.Exists(FILEPATH) Then
            Directory.CreateDirectory(FILEPATH)
        End If
        If Not Directory.Exists(DATAPATH) Then
            Directory.CreateDirectory(DATAPATH)
        End If


        'Check that all necessary files exist and create them if they dont exist
        'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_create_file.htm

        Dim xlApp As Excel.Application
        Dim xlWorkbook As Excel.Workbook
        Dim xlWorksheet As Excel.Worksheet

        xlApp = New Excel.Application

        If xlApp Is Nothing Then
            MsgBox("Microsoft Excel is damaged or not installed on your system." & vbNewLine & "Please install Excel as it is required for this program to function." & vbNewLine & vbNewLine & "This program will close.", MsgBoxStyle.Critical, "Excel Not Installed")
            Application.Exit()

        Else

            'Load user data from files

            Try
                'Load Employee Data

                If File.Exists(EMPLOYEEFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(EMPLOYEEFILE)
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)

                    While CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "1").Text) <> ""

                        employeeData(employeeCount).nameFirst = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "1").Text)
                        employeeData(employeeCount).nameLast = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "2").Text)
                        employeeData(employeeCount).nameFull = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "3").Text)
                        employeeData(employeeCount).phoneNumber = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "4").Text)
                        employeeData(employeeCount).emailAddress = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        employeeData(employeeCount).openClose = CBool(xlWorksheet.Range(getLetter(employeeCount + 1) & "6").Text)
                        employeeData(employeeCount).availabilityStored = CBool(xlWorksheet.Range(getLetter(employeeCount + 1) & "7").Text)
                        employeeData(employeeCount).colourCode = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "8").Text)

                        ''Don't try to convert empty strings to boolean
                        'Dim testString As String
                        'testString = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        'If testString <> "" Then
                        '    employeeData(employeeCount).openClose = CBool(testString)
                        'End If
                        'testString = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        'If testString <> "" Then
                        '    employeeData(employeeCount).availabilityStored = CBool(testString)
                        'End If

                        employeeCount += 1

                    End While

                Else

                    xlWorkbook = xlApp.Workbooks.Add()
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                    xlWorksheet.Name = "Main"
                    xlWorkbook.SaveAs(EMPLOYEEFILE)

                End If

                xlWorkbook.Close(False)

            Catch ex As Exception
                MsgBox("Could not access existing or create new employee data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & EMPLOYEEFILE, MsgBoxStyle.Critical, "Error Loading Employee Data")
            End Try


            Try
                'Load Availability Data

                If File.Exists(AVAILABILITYFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(AVAILABILITYFILE)

                    Dim employeeIndex As Integer
                    For employeeIndex = 0 To employeeCount - 1 'Get each amployee's availability

                        If employeeData(employeeIndex).availabilityStored = True Then

                            xlWorksheet = CType(xlWorkbook.Worksheets(employeeData(employeeIndex).nameFull), Excel.Worksheet)

                            Dim dayNumber As Integer
                            For dayNumber = 1 To 7 'Get for each day of the week

                                availability(7 * employeeIndex + (dayNumber - 1)).timeStart = CInt(xlWorksheet.Range(getLetter(dayNumber) & "1").Text)
                                availability(7 * employeeIndex + (dayNumber - 1)).timeFinish = CInt(xlWorksheet.Range(getLetter(dayNumber) & "2").Text)

                            Next

                        Else

                            MsgBox("No availability stored for " & employeeData(employeeIndex).nameFull & "." & vbNewLine & "Please enter employees' availability into the system via 'Modify Employee Data'.", MsgBoxStyle.Exclamation, "No Availability Stored")

                        End If

                    Next

                    xlWorkbook.Close(False)

                Else

                    MsgBox("No availability stored for any employee." & vbNewLine & "Please enter employees' availability into the system via 'Modify Employee Data'.", MsgBoxStyle.Exclamation, "No Availability On File")

                End If

            Catch ex As Exception
                MsgBox("Could not access existing or create new availability data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & AVAILABILITYFILE, MsgBoxStyle.Critical, "Error Loading Availability Data")
            End Try


            Try
                'Load Shift Data

                If File.Exists(SHIFTFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(SHIFTFILE)
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)

                    While CStr(xlWorksheet.Range(getLetter(shiftCount + 1) & "1").Text) <> ""

                        shiftData(shiftCount).timeStart = CInt(xlWorksheet.Range(getLetter(shiftCount + 1) & "1").Text)
                        shiftData(shiftCount).timeFinish = CInt(xlWorksheet.Range(getLetter(shiftCount + 1) & "2").Text)

                        shiftCount += 1

                    End While

                Else

                    xlWorkbook = xlApp.Workbooks.Add()
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                    xlWorksheet.Name = "Main"
                    xlWorkbook.SaveAs(SHIFTFILE)

                End If

                xlWorkbook.Close(False)

            Catch ex As Exception
                MsgBox("Could not access existing or create new shift data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & SHIFTFILE, MsgBoxStyle.Critical, "Error Loading Shift Data")
            End Try

        End If

        'Close and release all objects
        xlApp.Quit()
        releaseObject(xlApp)
        releaseObject(xlWorkbook)
        releaseObject(xlWorksheet)

        mainReload() 'Show/hide user-group-specific objects and functions, check if roster has been sent within the week, and populate combination boxes.

    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        aboutProgram()
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        'Check if changes have been sent/saved then close
        'Source: https://stackoverflow.com/questions/2256909/messagebox-with-yesnocancel-no-cancel-triggers-same-event

        If rosterSentNow = False Then

            Dim rosterSentWeekMessage As String = ""
            If rosterSentWeek = False Then
                rosterSentWeekMessage = "not "
            End If

            Dim messageBoxResult As Integer
            messageBoxResult = MessageBox.Show("Roster has not been sent during the current session." & vbNewLine & "A roster has " & rosterSentWeekMessage & "been sent during this week." & vbNewLine & vbNewLine & "Quit without sending current changes?", "Changes Not Saved", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)

            If messageBoxResult = DialogResult.Yes Then
                Application.Exit()
            End If

        End If
    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click
        frmData.Show()
    End Sub

    Private Sub btnEditShifts_Click(sender As Object, e As EventArgs) Handles btnEditShifts.Click
        frmShifts.Show()
    End Sub

    Private Sub btnEditPIN_Click(sender As Object, e As EventArgs) Handles btnEditPin.Click
        InputBox("Enter current/old PIN for user-group " & "$$")
    End Sub

    Private Sub btnSendRoster_Click(sender As Object, e As EventArgs) Handles btnSendRoster.Click

        'Check/create roster archive

        Dim xlApp As Excel.Application
        Dim xlWorkbook As Excel.Workbook
        Dim xlWorksheet As Excel.Worksheet

        xlApp = New Excel.Application

        Try

            If Not File.Exists(ROSTERARCHIVE) Then

                xlWorkbook = xlApp.Workbooks.Add()
                xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                xlWorkbook.SaveAs(ROSTERARCHIVE)

                xlWorkbook.Close(True)

            End If

        Catch ex As Exception
            MsgBox("Could not access existing or create new roster archive file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & ROSTERARCHIVE, MsgBoxStyle.Critical, "Error Loading Roster Archive")
        End Try

        If MsgBox("Roster was successfully sent to the following employees:" & vbNewLine & vbNewLine & "Sample Person" & " (" & "email@provider.com" & ")" & vbNewLine & vbNewLine & "Roster sucessfully archived as week " & "## (##/##/##)." & vbNewLine & "No rosters were overwritten." & vbNewLine & vbNewLine & "Would you like to close the program?", MsgBoxStyle.YesNo, "Successfully Sent and Archived") = MsgBoxResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnSearchArchive_Click(sender As Object, e As EventArgs) Handles btnSearchArchive.Click
        frmSearch.Show()
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogoMain.Click
        aboutProgram()
    End Sub

    'Update shift combination box items when a staff member is selected...
    Private Sub cmbStaffThu1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu1.SelectedIndexChanged
        getShifts(1, 1, cmbStaffThu1.Text)
    End Sub
    Private Sub cmbStaffThu2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu2.SelectedIndexChanged
        getShifts(1, 2, cmbStaffThu2.Text)
    End Sub
    Private Sub cmbStaffThu3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu3.SelectedIndexChanged
        getShifts(1, 3, cmbStaffThu3.Text)
    End Sub
    Private Sub cmbStaffThu4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu4.SelectedIndexChanged
        getShifts(1, 4, cmbStaffThu4.Text)
    End Sub
    Private Sub cmbStaffThu5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu5.SelectedIndexChanged
        getShifts(1, 5, cmbStaffThu5.Text)
    End Sub
    Private Sub cmbStaffThu6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffThu6.SelectedIndexChanged
        getShifts(1, 6, cmbStaffThu6.Text)
    End Sub
    Private Sub cmbStaffFri1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri1.SelectedIndexChanged
        getShifts(2, 1, cmbStaffFri1.Text)
    End Sub
    Private Sub cmbStaffFri2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri2.SelectedIndexChanged
        getShifts(2, 2, cmbStaffFri2.Text)
    End Sub
    Private Sub cmbStaffFri3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri3.SelectedIndexChanged
        getShifts(2, 3, cmbStaffFri3.Text)
    End Sub
    Private Sub cmbStaffFri4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri4.SelectedIndexChanged
        getShifts(2, 4, cmbStaffFri4.Text)
    End Sub
    Private Sub cmbStaffFri5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri5.SelectedIndexChanged
        getShifts(2, 5, cmbStaffFri5.Text)
    End Sub
    Private Sub cmbStaffFri6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffFri6.SelectedIndexChanged
        getShifts(2, 6, cmbStaffFri6.Text)
    End Sub
    Private Sub cmbStaffSat1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat1.SelectedIndexChanged
        getShifts(3, 1, cmbStaffSat1.Text)
    End Sub
    Private Sub cmbStaffSat2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat2.SelectedIndexChanged
        getShifts(3, 2, cmbStaffSat2.Text)
    End Sub
    Private Sub cmbStaffSat3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat3.SelectedIndexChanged
        getShifts(3, 3, cmbStaffSat3.Text)
    End Sub
    Private Sub cmbStaffSat4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat4.SelectedIndexChanged
        getShifts(3, 4, cmbStaffSat4.Text)
    End Sub
    Private Sub cmbStaffSat5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat5.SelectedIndexChanged
        getShifts(3, 5, cmbStaffSat5.Text)
    End Sub
    Private Sub cmbStaffSat6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSat6.SelectedIndexChanged
        getShifts(3, 6, cmbStaffSat6.Text)
    End Sub
    Private Sub cmbStaffSun1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun1.SelectedIndexChanged
        getShifts(4, 1, cmbStaffSun1.Text)
    End Sub
    Private Sub cmbStaffSun2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun2.SelectedIndexChanged
        getShifts(4, 2, cmbStaffSun2.Text)
    End Sub
    Private Sub cmbStaffSun3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun3.SelectedIndexChanged
        getShifts(4, 3, cmbStaffSun3.Text)
    End Sub
    Private Sub cmbStaffSun4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun4.SelectedIndexChanged
        getShifts(4, 4, cmbStaffSun4.Text)
    End Sub
    Private Sub cmbStaffSun5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun5.SelectedIndexChanged
        getShifts(4, 5, cmbStaffSun5.Text)
    End Sub
    Private Sub cmbStaffSun6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffSun6.SelectedIndexChanged
        getShifts(4, 6, cmbStaffSun6.Text)
    End Sub
    Private Sub cmbStaffMon1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon1.SelectedIndexChanged
        getShifts(5, 1, cmbStaffMon1.Text)
    End Sub
    Private Sub cmbStaffMon2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon2.SelectedIndexChanged
        getShifts(5, 2, cmbStaffMon2.Text)
    End Sub
    Private Sub cmbStaffMon3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon3.SelectedIndexChanged
        getShifts(5, 3, cmbStaffMon3.Text)
    End Sub
    Private Sub cmbStaffMon4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon4.SelectedIndexChanged
        getShifts(5, 4, cmbStaffMon4.Text)
    End Sub
    Private Sub cmbStaffMon5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon5.SelectedIndexChanged
        getShifts(5, 5, cmbStaffMon5.Text)
    End Sub
    Private Sub cmbStaffMon6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffMon6.SelectedIndexChanged
        getShifts(5, 6, cmbStaffMon6.Text)
    End Sub
    Private Sub cmbStaffTue1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue1.SelectedIndexChanged
        getShifts(6, 1, cmbStaffTue1.Text)
    End Sub
    Private Sub cmbStaffTue2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue2.SelectedIndexChanged
        getShifts(6, 2, cmbStaffTue2.Text)
    End Sub
    Private Sub cmbStaffTue3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue3.SelectedIndexChanged
        getShifts(6, 3, cmbStaffTue3.Text)
    End Sub
    Private Sub cmbStaffTue4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue4.SelectedIndexChanged
        getShifts(6, 4, cmbStaffTue4.Text)
    End Sub
    Private Sub cmbStaffTue5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue5.SelectedIndexChanged
        getShifts(6, 5, cmbStaffTue5.Text)
    End Sub
    Private Sub cmbStaffTue6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffTue6.SelectedIndexChanged
        getShifts(6, 6, cmbStaffTue6.Text)
    End Sub
    Private Sub cmbStaffWed1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed1.SelectedIndexChanged
        getShifts(7, 1, cmbStaffWed1.Text)
    End Sub
    Private Sub cmbStaffWed2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed2.SelectedIndexChanged
        getShifts(7, 2, cmbStaffWed2.Text)
    End Sub
    Private Sub cmbStaffWed3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed3.SelectedIndexChanged
        getShifts(7, 3, cmbStaffWed3.Text)
    End Sub
    Private Sub cmbStaffWed4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed4.SelectedIndexChanged
        getShifts(7, 4, cmbStaffWed4.Text)
    End Sub
    Private Sub cmbStaffWed5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed5.SelectedIndexChanged
        getShifts(7, 5, cmbStaffWed5.Text)
    End Sub
    Private Sub cmbStaffWed6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStaffWed6.SelectedIndexChanged
        getShifts(7, 6, cmbStaffWed6.Text)
    End Sub

End Class
