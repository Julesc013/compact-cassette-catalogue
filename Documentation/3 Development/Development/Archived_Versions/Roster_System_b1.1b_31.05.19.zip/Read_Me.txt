This version (1.1b) has been modified specifically for testing purposes.
It will not write newly created PINs to the internal settings and will not log on.