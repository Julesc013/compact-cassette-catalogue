# Blue Dog Café Rostering System Change Log

## Beta 



### Version 1.2 (June 1)

- Revised PIN creation prompt text.



### Version 1.1 (May 31)

- Added PIN creation code.
- Added logon code (PIN checking).
- Enter key mapped to Log-on button.



### Version 1.0 (May 29)

- Moved global variables and subroutines from forms to a module
- Added internal settings for storage of user PINs



### Version 0.6 (May 24)

- Added screen resolution check and warning



### Version 0.1 – 0.5 (May 14)

- Iteratively designed all forms
- Added placeholder code for opening/closing forms
- Added program and version information

