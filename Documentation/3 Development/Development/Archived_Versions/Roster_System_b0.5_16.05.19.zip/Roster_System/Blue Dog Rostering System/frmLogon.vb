﻿Public Class frmLogon
    Private Sub frmLogon_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'display about information
        lblAboutProgram.Text = "Version " & frmMain.VERSION & vbNewLine & "Jules Carboni (VCE), 2019"
    End Sub

    Private Sub btnLogon_Click(sender As Object, e As EventArgs) Handles btnLogon.Click
        'if password is match
        frmMain.Show()
        Me.Close()
    End Sub

    Private Sub picLogoTwo_Click(sender As Object, e As EventArgs) Handles picLogoTwo.Click
        frmMain.aboutProgram()
    End Sub

    Private Sub picLogoOne_Click(sender As Object, e As EventArgs) Handles picLogoOne.Click
        frmMain.aboutProgram()
    End Sub
End Class