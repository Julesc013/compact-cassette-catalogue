﻿Public Class frmMain

    Public Const VERSION As String = "0.5"

    Sub aboutProgram()
        MsgBox("Blue Dog Cafe Rostering System" & vbNewLine & "Version " & VERSION & vbNewLine & "Jules Carboni, 2019" & vbNewLine & vbNewLine & "Program data written to " & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Roster_System", MsgBoxStyle.Information, "About Rostering System")
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        aboutProgram()
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        'save and close
        Application.Exit()
    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click
        frmData.Show()
    End Sub

    Private Sub btnEditShifts_Click(sender As Object, e As EventArgs) Handles btnEditShifts.Click
        frmShifts.Show()
    End Sub

    Private Sub btnEditPIN_Click(sender As Object, e As EventArgs) Handles btnEditPin.Click
        InputBox("Enter current/old PIN for user-group " & "$$")
    End Sub

    Private Sub btnSendRoster_Click(sender As Object, e As EventArgs) Handles btnSendRoster.Click
        If MsgBox("Roster was successfully sent to the following employees:" & vbNewLine & vbNewLine & "Sample Person" & " (" & "email@provider.com" & ")" & vbNewLine & vbNewLine & "Roster sucessfully archived as week " & "## (##/##/##)." & vbNewLine & "No rosters were overwritten." & vbNewLine & vbNewLine & "Would you like to close the program?", MsgBoxStyle.YesNo, "Successfully Sent and Archived") = MsgBoxResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnSearchArchive_Click(sender As Object, e As EventArgs) Handles btnSearchArchive.Click
        frmSearch.Show()
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogoMain.Click
        aboutProgram()
    End Sub
End Class
