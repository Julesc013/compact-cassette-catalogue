﻿Public Class frmSearch
    Private Sub btnSaveResults_Click(sender As Object, e As EventArgs) Handles btnSaveResults.Click
        dlgSaveResults.ShowDialog()
    End Sub
End Class