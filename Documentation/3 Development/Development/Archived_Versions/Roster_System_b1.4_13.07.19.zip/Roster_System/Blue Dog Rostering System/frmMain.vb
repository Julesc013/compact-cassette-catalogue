﻿' Name:             Main Roster Generation
' Purpose:          Creates and sends rosters. Provides buttons for accessing other forms (is root from).
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    5 June 2019

Imports System.Globalization
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel 'Import Excel functionality

Public Class frmMain

    Private Sub getShifts(ByVal employeeName As String)
        'populate cmbbox with compatible shifts for employee
        ''treat 1440 as "close" for shifts
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ''Populate collections of comboboxes
        ''Source: https://stackoverflow.com/questions/22736666/how-to-add-textbox0-in-visual-basic-2012

        'colStaff.Add(cmbStaffThu1)
        'colStaff.Add(cmbStaffThu2)
        'colStaff.Add(cmbStaffThu3)
        'colStaff.Add(cmbStaffThu4)
        'colStaff.Add(cmbStaffThu5)
        'colStaff.Add(cmbStaffThu6)
        'colStaff.Add(cmbStaffFri1)
        'colStaff.Add(cmbStaffFri2)
        'colStaff.Add(cmbStaffFri3)
        'colStaff.Add(cmbStaffFri4)
        'colStaff.Add(cmbStaffFri5)
        'colStaff.Add(cmbStaffFri6)
        'colStaff.Add(cmbStaffSat1)
        'colStaff.Add(cmbStaffSat2)
        'colStaff.Add(cmbStaffSat3)
        'colStaff.Add(cmbStaffSat4)
        'colStaff.Add(cmbStaffSat5)
        'colStaff.Add(cmbStaffSat6)
        'colStaff.Add(cmbStaffSun1)
        'colStaff.Add(cmbStaffSun2)
        'colStaff.Add(cmbStaffSun3)
        'colStaff.Add(cmbStaffSun4)
        'colStaff.Add(cmbStaffSun5)
        'colStaff.Add(cmbStaffSun6)
        'colStaff.Add(cmbStaffMon1)
        'colStaff.Add(cmbStaffMon2)
        'colStaff.Add(cmbStaffMon3)
        'colStaff.Add(cmbStaffMon4)
        'colStaff.Add(cmbStaffMon5)
        'colStaff.Add(cmbStaffMon6)
        'colStaff.Add(cmbStaffTue1)
        'colStaff.Add(cmbStaffTue2)
        'colStaff.Add(cmbStaffTue3)
        'colStaff.Add(cmbStaffTue4)
        'colStaff.Add(cmbStaffTue5)
        'colStaff.Add(cmbStaffTue6)
        'colStaff.Add(cmbStaffWed1)
        'colStaff.Add(cmbStaffWed2)
        'colStaff.Add(cmbStaffWed3)
        'colStaff.Add(cmbStaffWed4)
        'colStaff.Add(cmbStaffWed5)
        'colStaff.Add(cmbStaffWed6)
        ''Next collection...
        'colShift.Add(cmbShiftThu1)
        'colShift.Add(cmbShiftThu2)
        'colShift.Add(cmbShiftThu3)
        'colShift.Add(cmbShiftThu4)
        'colShift.Add(cmbShiftThu5)
        'colShift.Add(cmbShiftThu6)
        'colShift.Add(cmbShiftFri1)
        'colShift.Add(cmbShiftFri2)
        'colShift.Add(cmbShiftFri3)
        'colShift.Add(cmbShiftFri4)
        'colShift.Add(cmbShiftFri5)
        'colShift.Add(cmbShiftFri6)
        'colShift.Add(cmbShiftSat1)
        'colShift.Add(cmbShiftSat2)
        'colShift.Add(cmbShiftSat3)
        'colShift.Add(cmbShiftSat4)
        'colShift.Add(cmbShiftSat5)
        'colShift.Add(cmbShiftSat6)
        'colShift.Add(cmbShiftSun1)
        'colShift.Add(cmbShiftSun2)
        'colShift.Add(cmbShiftSun3)
        'colShift.Add(cmbShiftSun4)
        'colShift.Add(cmbShiftSun5)
        'colShift.Add(cmbShiftSun6)
        'colShift.Add(cmbShiftMon1)
        'colShift.Add(cmbShiftMon2)
        'colShift.Add(cmbShiftMon3)
        'colShift.Add(cmbShiftMon4)
        'colShift.Add(cmbShiftMon5)
        'colShift.Add(cmbShiftMon6)
        'colShift.Add(cmbShiftTue1)
        'colShift.Add(cmbShiftTue2)
        'colShift.Add(cmbShiftTue3)
        'colShift.Add(cmbShiftTue4)
        'colShift.Add(cmbShiftTue5)
        'colShift.Add(cmbShiftTue6)
        'colShift.Add(cmbShiftWed1)
        'colShift.Add(cmbShiftWed2)
        'colShift.Add(cmbShiftWed3)
        'colShift.Add(cmbShiftWed4)
        'colShift.Add(cmbShiftWed5)
        'colShift.Add(cmbShiftWed6)


        'Check that the root folder exists, if not create it
        'Source: https://stackoverflow.com/questions/85996/how-do-i-create-a-folder-in-vb-if-it-doesnt-exist

        If Not Directory.Exists(FILEPATH) Then
            Directory.CreateDirectory(FILEPATH)
        End If
        If Not Directory.Exists(DATAPATH) Then
            Directory.CreateDirectory(DATAPATH)
        End If


        'Check that all necessary files exist and create them if they dont exist
        'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_create_file.htm

        Dim xlApp As Excel.Application
        Dim xlWorkbook As Excel.Workbook
        Dim xlWorksheet As Excel.Worksheet

        xlApp = New Excel.Application

        If xlApp Is Nothing Then
            MsgBox("Microsoft Excel is damaged or not installed on your system." & vbNewLine & "Please install Excel as it is required for this program t function." & vbNewLine & vbNewLine & "This program will close.", MsgBoxStyle.Critical, "Excel Not Installed")
            Application.Exit()

        Else

            'Load user data from files

            Try
                'Load Employee Data

                If File.Exists(EMPLOYEEFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(EMPLOYEEFILE)
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)

                    While CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "1").Text) <> ""

                        employeeData(employeeCount).nameFirst = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "1").Text)
                        employeeData(employeeCount).nameLast = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "2").Text)
                        employeeData(employeeCount).phoneNumber = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "3").Text)
                        employeeData(employeeCount).emailAddress = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "4").Text)
                        employeeData(employeeCount).openClose = CBool(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        employeeData(employeeCount).availabilityStored = CBool(xlWorksheet.Range(getLetter(employeeCount + 1) & "6").Text)
                        employeeData(employeeCount).colourCode = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "7").Text)

                        ''Don't try to convert empty strings to boolean
                        'Dim testString As String
                        'testString = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        'If testString <> "" Then
                        '    employeeData(employeeCount).openClose = CBool(testString)
                        'End If
                        'testString = CStr(xlWorksheet.Range(getLetter(employeeCount + 1) & "5").Text)
                        'If testString <> "" Then
                        '    employeeData(employeeCount).availabilityStored = CBool(testString)
                        'End If

                        employeeCount += 1

                    End While

                Else

                    xlWorkbook = xlApp.Workbooks.Add()
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                    xlWorksheet.Name = "Main"
                    xlWorkbook.SaveAs(EMPLOYEEFILE)

                End If

                xlWorkbook.Close(False)

            Catch ex As Exception
                MsgBox("Could not access existing or create new employee data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & EMPLOYEEFILE, MsgBoxStyle.Critical, "Error Loading Employee Data")
            End Try


            'Try
            'Load Availability Data

            If File.Exists(AVAILABILITYFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(AVAILABILITYFILE)

                    Dim index As Integer
                    For index = 0 To employeeCount - 1 'Get each amployee's availability

                        If employeeData(index).availabilityStored = True Then

                            xlWorksheet = CType(xlWorkbook.Worksheets(employeeData(index).nameFirst & " " & employeeData(index).nameLast), Excel.Worksheet)

                            Dim day As Integer
                            For day = 0 To 6 'Get for each day of the week

                            employeeData(index).timeStart(day) = CInt(xlWorksheet.Range(getLetter(day + 1) & "1").Text)
                            employeeData(index).timeFinish(day) = CInt(xlWorksheet.Range(getLetter(day + 1) & "1").Text)

                        Next

                        Else

                            MsgBox("No availability stored for " & employeeData(index).nameFirst & " " & employeeData(index).nameLast & "." & vbNewLine & "Please enter employees' availability into the system via 'Modify Employee Data'.", MsgBoxStyle.Exclamation, "No Availability Stored")

                        End If

                    Next

                    xlWorkbook.Close(False)

                Else

                    MsgBox("No availability stored for any employee." & vbNewLine & "Please enter employees' availability into the system via 'Modify Employee Data'.", MsgBoxStyle.Exclamation, "No Availability On File")

                End If

            'Catch ex As Exception
            'MsgBox("Could not access existing or create new availability data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & AVAILABILITYFILE, MsgBoxStyle.Critical, "Error Loading Availability Data")
            'End Try


            Try
                'Load Shift Data

                If File.Exists(SHIFTFILE) Then

                    xlWorkbook = xlApp.Workbooks.Open(SHIFTFILE)
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)

                    While CStr(xlWorksheet.Range(getLetter(shiftCount + 1) & "1").Text) <> ""

                        shiftData(shiftCount).shiftStart = CInt(xlWorksheet.Range(getLetter(shiftCount + 1) & "1").Text)
                        shiftData(shiftCount).shiftFinish = CInt(xlWorksheet.Range(getLetter(shiftCount + 1) & "2").Text)

                        shiftCount += 1

                    End While

                Else

                    xlWorkbook = xlApp.Workbooks.Add()
                    xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                    xlWorksheet.Name = "Main"
                    xlWorkbook.SaveAs(SHIFTFILE)

                End If

                xlWorkbook.Close(False)

            Catch ex As Exception
                MsgBox("Could not access existing or create new shift data file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & SHIFTFILE, MsgBoxStyle.Critical, "Error Loading Shift Data")
            End Try

        End If

        'Close and release all objects
        xlApp.Quit()
        releaseObject(xlApp)
        releaseObject(xlWorkbook)
        releaseObject(xlWorksheet)

        mainReload() 'Show/hide user-group-specific objects and functions, check if roster has been sent within the week, and populate combination boxes.

    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        aboutProgram()
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        'Check if changes have been sent/saved then close
        'Source: https://stackoverflow.com/questions/2256909/messagebox-with-yesnocancel-no-cancel-triggers-same-event

        If rosterSentNow = False Then

            Dim rosterSentWeekMessage As String = ""
            If rosterSentWeek = False Then
                rosterSentWeekMessage = "not "
            End If

            Dim messageBoxResult As Integer
            messageBoxResult = MessageBox.Show("Roster has not been sent during the current session." & vbNewLine & "A roster has " & rosterSentWeekMessage & "been sent during this week." & vbNewLine & vbNewLine & "Quit without sending current changes?", "Changes Not Saved", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)

            If messageBoxResult = DialogResult.Yes Then
                Application.Exit()
            End If

        End If
    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click
        frmData.Show()
    End Sub

    Private Sub btnEditShifts_Click(sender As Object, e As EventArgs) Handles btnEditShifts.Click
        frmShifts.Show()
    End Sub

    Private Sub btnEditPIN_Click(sender As Object, e As EventArgs) Handles btnEditPin.Click
        InputBox("Enter current/old PIN for user-group " & "$$")
    End Sub

    Private Sub btnSendRoster_Click(sender As Object, e As EventArgs) Handles btnSendRoster.Click

        'Check/create roster archive

        Dim xlApp As Excel.Application
        Dim xlWorkbook As Excel.Workbook
        Dim xlWorksheet As Excel.Worksheet

        xlApp = New Excel.Application

        Try

            If Not File.Exists(ROSTERARCHIVE) Then

                xlWorkbook = xlApp.Workbooks.Add()
                xlWorksheet = CType(xlWorkbook.Worksheets(1), Excel.Worksheet)
                xlWorkbook.SaveAs(ROSTERARCHIVE)

                xlWorkbook.Close(True)

            End If

        Catch ex As Exception
            MsgBox("Could not access existing or create new roster archive file." & vbNewLine & "Please close any applications that may be using the file and restart this program." & vbNewLine & vbNewLine & "Error: " & ROSTERARCHIVE, MsgBoxStyle.Critical, "Error Loading Roster Archive")
        End Try

        If MsgBox("Roster was successfully sent to the following employees:" & vbNewLine & vbNewLine & "Sample Person" & " (" & "email@provider.com" & ")" & vbNewLine & vbNewLine & "Roster sucessfully archived as week " & "## (##/##/##)." & vbNewLine & "No rosters were overwritten." & vbNewLine & vbNewLine & "Would you like to close the program?", MsgBoxStyle.YesNo, "Successfully Sent and Archived") = MsgBoxResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnSearchArchive_Click(sender As Object, e As EventArgs) Handles btnSearchArchive.Click
        frmSearch.Show()
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogoMain.Click
        aboutProgram()
    End Sub

End Class
