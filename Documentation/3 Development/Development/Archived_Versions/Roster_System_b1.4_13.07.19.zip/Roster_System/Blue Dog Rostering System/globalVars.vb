﻿' Name:             Global Variables and Subroutines
' Purpose:          Stores all the global varibales and subroutines used in multiple forms throughout the program.
' Author:           Jules Carboni
' Date Created:     29 May 2019
' Date Modified:    13 July 2019

Imports System.Globalization
Imports System.IO

Module globalVars

    'Decalare global variables

    Public Const VERSION As String = "Beta 1.4"
    Public Const MASTERKEY As String = "UiNdY9yIwt7F" 'Key used to encrypt data files
    Public Const OWNEREMAIL As String = "julescarboni013@gmail.com" 'Email from which rosters are sent 'TBD

    'File paths (cannot be literal constants)
    Public ReadOnly FILEPATH As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Roster_System"
    Public ReadOnly DATAPATH As String = FILEPATH & "\Data"

    Public ReadOnly EMPLOYEEFILE As String = DATAPATH & "\Employees.xlsx"
    Public ReadOnly AVAILABILITYFILE As String = DATAPATH & "\Availability.xlsx"
    Public ReadOnly SHIFTFILE As String = DATAPATH & "\Shifts.xlsx"

    Public ReadOnly ROSTERARCHIVE As String = FILEPATH & "\Roster_Archive.xlsx"
    Public ReadOnly ROSTERLATEST As String = FILEPATH & "\Roster_Latest.pdf" 'Exported roster to send
    Public ReadOnly ROSTERSUGGESTED As String = FILEPATH & "\Roster_Suggested.xlsx" 'Roster suggested by chef/managers

    Public Const MAXEMPLOYEE As Integer = 40
    Public Const MAXSHIFT As Integer = 20

    Public employeeData(MAXEMPLOYEE) As employeeDataStructure
    Public shiftData(MAXSHIFT) As shiftDataStrcuture

    Public userGroup As String

    Public employeeCount As Integer = 0
    Public shiftCount As Integer = 0

    Public Structure employeeDataStructure
        Public nameFirst As String
        Public nameLast As String
        Public phoneNumber As String
        Public emailAddress As String
        Public openClose As Boolean
        Public availabilityStored As Boolean
        Public colourCode As String
        'For each day of the week
        Public timeStart() As Integer
        Public timeFinish() As Integer
    End Structure

    Public Structure shiftDataStrcuture
        Public shiftStart As Integer
        Public shiftFinish As Integer
    End Structure

    ''Collections of comboboxes (see form load for rest of code and source)
    'Dim colStaff As Collection
    'Dim colShift As Collection

    'Source: https://stackoverflow.com/questions/5560019/vb-net-get-only-year-from-date
    'Source: https://stackoverflow.com/questions/12712300/get-the-week-number-of-the-year-counting-from-a-given-date-in-vb
    'Changes: Subtracted 2019 from current year to get index-based year

    Public ReadOnly YEARNUMBER As Integer = Date.Today.Year - 2019 'Index of years elapsed since 2019
    Public ReadOnly WEEKNUMBER As Integer = DateTimeFormatInfo.CurrentInfo.Calendar.GetWeekOfYear(DateTime.Now, DateTimeFormatInfo.CurrentInfo.CalendarWeekRule, DayOfWeek.Thursday) 'Number of weeks elapsed (starting with Thursday)

    Public ReadOnly ROSTERNAME As String = "Y" & YEARNUMBER.ToString("D2") & "_W" & WEEKNUMBER.ToString("D2")

    Public rosterSentNow As Boolean = False 'Has roster been sent in this program session
    Public rosterSentWeek As Boolean 'Has roster been sent in the last week

    Public rosterLastSentWeek As Integer = DateTimeFormatInfo.CurrentInfo.Calendar.GetWeekOfYear(My.Settings.rosterLastSent, DateTimeFormatInfo.CurrentInfo.CalendarWeekRule, DayOfWeek.Thursday)

    Public rosterSuggestedExists As Boolean = File.Exists(ROSTERSUGGESTED)

    'Declare global subroutines

    Sub aboutProgram()
        MsgBox("Blue Dog Cafe Rostering System" & vbNewLine & "Version " & VERSION & vbNewLine & "Jules Carboni, 2019" & vbNewLine & vbNewLine & "Program data and roster archive saved in:" & vbNewLine & FILEPATH, MsgBoxStyle.Information, "About Rostering System")
    End Sub

    Sub releaseObject(ByVal obj As Object)
        'Post-close clean-up of excel objects
        'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_create_file.htm
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Sub mainReload()
        'Included in frmMain_Load subroutine

        'Show/hide user-group-specific objects and functions
        '(Default values have been set in the object properties)

        'Check if roster has been sent within the week
        If weekNumber = rosterLastSentWeek Then
            rosterSentWeek = True
        Else
            rosterSentWeek = False
        End If

        If rosterSuggestedExists = True Then
            'Allow loading suggested roster only if it exists
            frmMain.btnLoadSuggested.Enabled = True
        End If

        If userGroup = "Chef/Manager" Then
            frmMain.btnSuggestRoster.Visible = True

            frmMain.btnEditData.Visible = False
            frmMain.btnEditShifts.Visible = False
            frmMain.btnSearchArchive.Visible = False

            If rosterSentWeek = False Then
                frmMain.btnSearchArchive.Enabled = False
            End If
        End If


        'Populate combination boxes
        'Source: https://stackoverflow.com/questions/30604633/loop-through-textboxes-in-vb-net

        For Each panelDay As Panel In frmMain.pnlRoster.Controls.OfType(Of Panel)() 'For each panel/day in the roster
            For Each comboBoxStaff As ComboBox In panelDay.Controls.OfType(Of ComboBox)() 'For each staff slot

                If comboBoxStaff.Name.Contains("Staff") Then 'Ignore non-staff/shift comboboxes

                    comboBoxStaff.Items.Add("") 'Empty selection for 'no staff member'

                    Dim index As Integer
                    For index = 0 To employeeCount - 1
                        comboBoxStaff.Items.Add(employeeData(index).nameFirst & " " & employeeData(index).nameLast)
                    Next

                End If

            Next
        Next

    End Sub

    Function getLetter(columnNumber As Integer) As String
        'Convert integer to letter of the alphabet
        'Source: https://stackoverflow.com/questions/31974538/converting-numbers-to-excel-letter-column-vb-net
        'Modifications: None.
        Dim dividend As Integer = columnNumber
        Dim columnName As String = String.Empty
        Dim modulo As Integer

        While dividend > 0
            modulo = (dividend - 1) Mod 26
            columnName = Convert.ToChar(65 + modulo).ToString() & columnName
            dividend = CInt((dividend - modulo) / 26)
        End While

        Return columnName
    End Function

End Module
