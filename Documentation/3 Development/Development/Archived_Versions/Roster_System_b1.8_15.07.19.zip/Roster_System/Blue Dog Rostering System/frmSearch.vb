﻿' Name:             Search Archive
' Purpose:          Search And sort archived rosters for shifts by employee name. Get basic statistics on employee. Save results to file.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    14 July 2019

Imports Excel = Microsoft.Office.Interop.Excel 'Import Excel functionality
Imports System.IO

Public Class frmSearch

    Const MAXSEARCH As Integer = 1000 'No limit requested by client, but because of the slow search algorithm used this maxsize was set. This limit should not be during the 5-year life of the program.

    Dim dayName As New Dictionary(Of Integer, String) From {{1, "Thursday"}, {2, "Friday"}, {3, "Saturday"}, {4, "Sunday"}, {5, "Monday"}, {6, "Tuesday"}, {7, "Wednesday"}} 'Dictionary to convert integer to name of the day

    Private Structure resultStructure
        'Structure to store results
        Dim year As Integer
        Dim week As Integer '0 to 52
        Dim day As String
        Dim calDate As Date 'Calendar date
        Dim timeStart As String
        Dim timeFinish As String
        '24hr values for sorting and calculating
        Dim timeStartInt As Integer
        Dim timeFinishInt As Integer
        Dim duration As Integer 'Number of minutes
    End Structure

    Dim results(MAXSEARCH) As resultStructure

    Private Sub frmSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'populate combobox
    End Sub

    Private Sub btnSaveResults_Click(sender As Object, e As EventArgs) Handles btnSaveResults.Click
        dlgSaveResults.ShowDialog()
        'unfinished
    End Sub

    ' Having considered both Quicksort And Selection Sort And Binary Search And Linear Search, I have chosen Not use the Quicksort Or the Binary Search because I don't need it as my data set contains less than one throusand elements and therefore my effeciency in terms of time is not affected that much.
    '
    ' This is the function that I would have considered
    '
    ' Function Quicksort(list, first, last)
    '     Begin
    '     If last > first Then
    '         Pivot = first element Of the array list
    ' 	  Left = first index Of the list
    ' 	  Right = last index Of the list
    '     While Left <= Right
    '             While list(Left) < pivot
    '                 Left = Left + 1
    '             End While
    '             While list(Right) > pivot
    '                 Right = Right - 1
    '             End While
    '             If Left <= Right Then
    '                 swap list(Left) With list(right)
    '	              Left = Left + 1
    '                 Right = Right – 1
    '             End If
    '         End While
    '         Quicksort(list, first, Right)
    '         Quicksort(list, Left, last)
    '     End If
    'End
    '
    ''''''''INCLUDE LINEAR SEARCH

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'Search archive for worked shifts and diplay them in a list box

        'Source: http://vb.net-informations.com/excel-2007/vb.net_excel_2007_open_file.htm
        'Source: https://stackoverflow.com/questions/21000965/check-to-see-if-sheet-exists-in-excel-and-record-result-as-boolean
        'Source: https://stackoverflow.com/questions/2483659/interop-type-cannot-be-embedded
        'Source: https://docs.microsoft.com/en-us/dotnet/visual-basic/language-reference/statements/for-next-statement

        Dim searchItem As String = cmbEmployeeSearch.Text 'Employee to search for
        Dim resultCount As Integer = 0 'Index for records

        Dim xlApp As Excel.Application
        Dim xlWorkbook As Excel.Workbook
        Dim xlWorksheet As Excel.Worksheet

        'Open archive file
        xlApp = New Excel.Application

        If xlApp Is Nothing Then
            MsgBox("Microsoft Excel is damaged or not installed on your system." & vbNewLine & "Please install Excel as it is required for this program to function." & vbNewLine & vbNewLine & "This program will close.", MsgBoxStyle.Critical, "Excel Not Installed")
            Application.Exit()

        Else

            If Not File.Exists(ROSTERARCHIVE) Then
                MsgBox("No archived rosters to search.", MsgBoxStyle.Information, "No Archived Rosters")

            Else
                Try

                    xlWorkbook = xlApp.Workbooks.Open(ROSTERARCHIVE)

                    Try

                        For Each xlWorksheet In xlWorkbook.Sheets 'for each week...
                            'Open each roster within archive
                            xlWorksheet.Activate()

                            Dim day As Integer
                            Dim worker As Integer

                            Dim xlRange As Excel.Range
                            Dim shiftTimes As Object

                            'For Each day In xlWorksheet.Rows
                            For day = 1 To 7
                                'Search each day of the week

                                For worker = 2 To 12 Step 2
                                    'Search each worker assigned for that day

                                    If xlWorksheet.Cells(worker, day).Equals(searchItem) Then
                                        'If found, store data in record
                                        'Source: https://stackoverflow.com/questions/38114793/how-to-extract-excel-sheet-name-from-workbook-using-vb-net
                                        'Source: https://www.dotnetperls.com/substring-vbnet
                                        'Source: https://stackoverflow.com/questions/23004274/vb-net-excel-worksheet-cells-value

                                        results(resultCount).year = 2019 + CInt(xlWorksheet.Name.Substring(1, 2))
                                        results(resultCount).week = CInt(xlWorksheet.Name.Substring(5, 2))
                                        results(resultCount).day = dayName(day)
                                        results(resultCount).calDate = calendarDate(results(resultCount).year, results(resultCount).week, day)

                                        xlRange = CType(xlWorksheet.Cells(worker, day + 1), Excel.Range) 'Get shift times from corresponding cell
                                        shiftTimes = xlRange.Value()

                                        results(resultCount).timeStart = CStr(shiftTimes).Substring(0, 8)
                                        results(resultCount).timeFinish = CStr(shiftTimes).Substring(11, 8)

                                        'Convert to minutes-since-midnight value
                                        results(resultCount).timeStartInt = timeToMin(results(resultCount).timeStart)
                                        results(resultCount).timeFinishInt = timeToMin(results(resultCount).timeFinish)

                                        results(resultCount).duration = results(resultCount).timeFinishInt - results(resultCount).timeStartInt

                                        resultCount += 1

                                    End If

                                Next
                            Next
                        Next

                    Catch ex As Exception
                        'If MAXSIZE of record structure exceeded stop searching

                    End Try

                    'Display data in list box
                    lstShiftsWorked.Items.Clear()

                    Dim index As Integer
                    For index = 0 To resultCount - 1

                        lstShiftsWorked.Items.Add(results(index).timeStart & " - " & results(index).timeFinish & " " & results(index).day.Substring(0, 3) & " " & results(index).calDate & " (" & results(index).week & ")")
                    Next

                    'Display statistics
                    'Source: https://stackoverflow.com/questions/11118896/split-string-by-in-vb-net
                    'Source: https://stackoverflow.com/questions/1785403/vb-net-linq-query-getting-the-sum-of-all-values-for-a-specific-structure-member
                    txtNameFirst.Text = searchItem.Split(CChar(" "))(0) & " " & searchItem.Split(CChar(" "))(1).Substring(0, 1)
                    txtTotalShifts.Text = CStr(resultCount)
                    txtTotalHours.Text = CStr(Math.Round(results.Sum(Function(total) total.duration) / 60))
                    txtEarliestTime.Text = minToTime(results.Min(Function(earliest) earliest.timeStartInt))
                    txtLatestTime.Text = minToTime(results.Max(Function(earliest) earliest.timeFinishInt))

                    'Enable functions
                    btnSortResults.Enabled = True
                    btnSaveResults.Enabled = True

                    'Close file safely
                    xlWorkbook.Close(False)

                Catch ex As Exception
                    MsgBox("Could not access existing roster archive file." & vbNewLine & "Error: " & ROSTERARCHIVE, MsgBoxStyle.Critical, "Error Loading Roster Archive")
                End Try

            End If

        End If

        'Close and release all objects
        xlApp.Quit()

        releaseObject(xlApp)
        releaseObject(xlWorkbook)
        releaseObject(xlWorksheet)

    End Sub

    Private Sub btnOkSearch_Click(sender As Object, e As EventArgs) Handles btnOkSearch.Click
        mainReload()
        Me.Close()
    End Sub
End Class