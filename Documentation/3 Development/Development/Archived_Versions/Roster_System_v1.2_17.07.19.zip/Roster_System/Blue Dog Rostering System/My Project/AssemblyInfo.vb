﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Blue Dog Rostering System")>
<Assembly: AssemblyDescription("Create, search and send rosters to employees.")>
<Assembly: AssemblyCompany("Jules Carboni")>
<Assembly: AssemblyProduct("Blue Dog Rostering System")>
<Assembly: AssemblyCopyright("Copyright ©Jules Carboni 2019")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c5918ecb-6e12-4e2f-bb23-d6a304d1a040")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("0.0.0.0")>
<Assembly: AssemblyFileVersion("0.0.0.0")>
