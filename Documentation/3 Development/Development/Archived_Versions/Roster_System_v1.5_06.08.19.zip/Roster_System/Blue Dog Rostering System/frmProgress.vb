﻿' Name:             Progress Bar
' Purpose:          Displays progress of current procedure to let user know the program is not hanging.
' Author:           Jules Carboni
' Date Created:     15 July 2019
' Date Modified:    16 July 2019

Public Class frmProgress

End Class