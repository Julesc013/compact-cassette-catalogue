﻿' Name:             Availability Entry
' Purpose:          Add/edit employee's availability and save to data store.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    16 May 2019

Public Class frmAvailability

    Private Sub frmAvailability_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'update name title
        'populate boxes
    End Sub

    Private Sub btnOkAvailability_Click(sender As Object, e As EventArgs) Handles btnOkAvailability.Click
        'Store new values in records (they will be saved later)

        '!!!!!!!!

        'Inform users that they must OK changes in data form for availability changes to be saved
        MsgBox("Availability has been stored and is ready for saving." & vbNewLine & "For these changes to take effect, you must accept your employee data changes.", MsgBoxStyle.Information, "Availability Ready For Saving")

        'Refresh employee data displayed in main form, then close this form
        frmData.populateLists()
        Me.Close()
    End Sub

    Private Sub btnCancelAvailability_Click(sender As Object, e As EventArgs) Handles btnCancelAvailability.Click
        'Close without saving changes to file
        'Refresh employee data displayed in main form, then close this form
        frmData.populateLists()
        Me.Close()
    End Sub

End Class