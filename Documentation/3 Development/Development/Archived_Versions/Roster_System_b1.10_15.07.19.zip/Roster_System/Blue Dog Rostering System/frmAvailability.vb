﻿' Name:             Availability Entry
' Purpose:          Add/edit employee's availability and save to data store.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    16 May 2019

Public Class frmAvailability
    Private Sub btnOkAvailability_Click(sender As Object, e As EventArgs) Handles btnOkAvailability.Click
        'Refresh employee data displayed in main form, then close this form
        frmData.Refresh()
        Me.Close()
    End Sub
End Class