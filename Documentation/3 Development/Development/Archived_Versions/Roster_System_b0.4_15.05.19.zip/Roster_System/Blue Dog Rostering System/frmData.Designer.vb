﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstNameFirst = New System.Windows.Forms.ListBox()
        Me.lblNameFirst = New System.Windows.Forms.Label()
        Me.lblNameLast = New System.Windows.Forms.Label()
        Me.lstNameLast = New System.Windows.Forms.ListBox()
        Me.lblPhoneNumber = New System.Windows.Forms.Label()
        Me.lstPhoneNumber = New System.Windows.Forms.ListBox()
        Me.lblEmailAddress = New System.Windows.Forms.Label()
        Me.lstEmailAddress = New System.Windows.Forms.ListBox()
        Me.lblOpenClose = New System.Windows.Forms.Label()
        Me.lstOpenClose = New System.Windows.Forms.ListBox()
        Me.btnEditAvailbility = New System.Windows.Forms.Button()
        Me.btnOKData = New System.Windows.Forms.Button()
        Me.btnAddData = New System.Windows.Forms.Button()
        Me.lblSelectData = New System.Windows.Forms.Label()
        Me.btnRemoveData = New System.Windows.Forms.Button()
        Me.lblAvailabilityStored = New System.Windows.Forms.Label()
        Me.lstAvailabilityStored = New System.Windows.Forms.ListBox()
        Me.lblTitleData = New System.Windows.Forms.Label()
        Me.btnEditInfo = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstNameFirst
        '
        Me.lstNameFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstNameFirst.FormattingEnabled = True
        Me.lstNameFirst.ItemHeight = 25
        Me.lstNameFirst.Location = New System.Drawing.Point(12, 90)
        Me.lstNameFirst.Name = "lstNameFirst"
        Me.lstNameFirst.Size = New System.Drawing.Size(152, 379)
        Me.lstNameFirst.TabIndex = 5
        '
        'lblNameFirst
        '
        Me.lblNameFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameFirst.Location = New System.Drawing.Point(12, 58)
        Me.lblNameFirst.Name = "lblNameFirst"
        Me.lblNameFirst.Size = New System.Drawing.Size(152, 25)
        Me.lblNameFirst.TabIndex = 9
        Me.lblNameFirst.Text = "First Name"
        Me.lblNameFirst.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblNameLast
        '
        Me.lblNameLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameLast.Location = New System.Drawing.Point(170, 58)
        Me.lblNameLast.Name = "lblNameLast"
        Me.lblNameLast.Size = New System.Drawing.Size(178, 25)
        Me.lblNameLast.TabIndex = 11
        Me.lblNameLast.Text = "Last Name"
        Me.lblNameLast.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstNameLast
        '
        Me.lstNameLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstNameLast.FormattingEnabled = True
        Me.lstNameLast.ItemHeight = 25
        Me.lstNameLast.Location = New System.Drawing.Point(170, 90)
        Me.lstNameLast.Name = "lstNameLast"
        Me.lstNameLast.Size = New System.Drawing.Size(178, 379)
        Me.lstNameLast.TabIndex = 10
        '
        'lblPhoneNumber
        '
        Me.lblPhoneNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhoneNumber.Location = New System.Drawing.Point(354, 58)
        Me.lblPhoneNumber.Name = "lblPhoneNumber"
        Me.lblPhoneNumber.Size = New System.Drawing.Size(148, 25)
        Me.lblPhoneNumber.TabIndex = 13
        Me.lblPhoneNumber.Text = "Phone Number"
        Me.lblPhoneNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstPhoneNumber
        '
        Me.lstPhoneNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPhoneNumber.FormattingEnabled = True
        Me.lstPhoneNumber.ItemHeight = 25
        Me.lstPhoneNumber.Location = New System.Drawing.Point(354, 90)
        Me.lstPhoneNumber.Name = "lstPhoneNumber"
        Me.lstPhoneNumber.Size = New System.Drawing.Size(148, 379)
        Me.lstPhoneNumber.TabIndex = 12
        '
        'lblEmailAddress
        '
        Me.lblEmailAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmailAddress.Location = New System.Drawing.Point(508, 58)
        Me.lblEmailAddress.Name = "lblEmailAddress"
        Me.lblEmailAddress.Size = New System.Drawing.Size(289, 25)
        Me.lblEmailAddress.TabIndex = 15
        Me.lblEmailAddress.Text = "Email Address"
        Me.lblEmailAddress.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstEmailAddress
        '
        Me.lstEmailAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstEmailAddress.FormattingEnabled = True
        Me.lstEmailAddress.ItemHeight = 25
        Me.lstEmailAddress.Location = New System.Drawing.Point(508, 90)
        Me.lstEmailAddress.Name = "lstEmailAddress"
        Me.lstEmailAddress.Size = New System.Drawing.Size(289, 379)
        Me.lstEmailAddress.TabIndex = 14
        '
        'lblOpenClose
        '
        Me.lblOpenClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOpenClose.Location = New System.Drawing.Point(799, 58)
        Me.lblOpenClose.Name = "lblOpenClose"
        Me.lblOpenClose.Size = New System.Drawing.Size(129, 25)
        Me.lblOpenClose.TabIndex = 17
        Me.lblOpenClose.Text = "Open/Close?"
        Me.lblOpenClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstOpenClose
        '
        Me.lstOpenClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOpenClose.FormattingEnabled = True
        Me.lstOpenClose.ItemHeight = 25
        Me.lstOpenClose.Location = New System.Drawing.Point(803, 90)
        Me.lstOpenClose.Name = "lstOpenClose"
        Me.lstOpenClose.Size = New System.Drawing.Size(119, 379)
        Me.lstOpenClose.TabIndex = 16
        '
        'btnEditAvailbility
        '
        Me.btnEditAvailbility.Enabled = False
        Me.btnEditAvailbility.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditAvailbility.Location = New System.Drawing.Point(508, 475)
        Me.btnEditAvailbility.Name = "btnEditAvailbility"
        Me.btnEditAvailbility.Size = New System.Drawing.Size(165, 37)
        Me.btnEditAvailbility.TabIndex = 2
        Me.btnEditAvailbility.Text = "Edit Availability"
        Me.btnEditAvailbility.UseVisualStyleBackColor = True
        '
        'btnOKData
        '
        Me.btnOKData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOKData.Location = New System.Drawing.Point(927, 475)
        Me.btnOKData.Name = "btnOKData"
        Me.btnOKData.Size = New System.Drawing.Size(105, 37)
        Me.btnOKData.TabIndex = 4
        Me.btnOKData.Text = "OK"
        Me.btnOKData.UseVisualStyleBackColor = True
        '
        'btnAddData
        '
        Me.btnAddData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddData.Location = New System.Drawing.Point(12, 475)
        Me.btnAddData.Name = "btnAddData"
        Me.btnAddData.Size = New System.Drawing.Size(105, 37)
        Me.btnAddData.TabIndex = 0
        Me.btnAddData.Text = "Add"
        Me.btnAddData.UseVisualStyleBackColor = True
        '
        'lblSelectData
        '
        Me.lblSelectData.AutoSize = True
        Me.lblSelectData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectData.Location = New System.Drawing.Point(135, 481)
        Me.lblSelectData.Name = "lblSelectData"
        Me.lblSelectData.Size = New System.Drawing.Size(243, 25)
        Me.lblSelectData.TabIndex = 21
        Me.lblSelectData.Text = "Or select an employee to..."
        Me.lblSelectData.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnRemoveData
        '
        Me.btnRemoveData.Enabled = False
        Me.btnRemoveData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemoveData.Location = New System.Drawing.Point(679, 475)
        Me.btnRemoveData.Name = "btnRemoveData"
        Me.btnRemoveData.Size = New System.Drawing.Size(118, 37)
        Me.btnRemoveData.TabIndex = 3
        Me.btnRemoveData.Text = "Remove "
        Me.btnRemoveData.UseVisualStyleBackColor = True
        '
        'lblAvailabilityStored
        '
        Me.lblAvailabilityStored.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvailabilityStored.Location = New System.Drawing.Point(922, 58)
        Me.lblAvailabilityStored.Name = "lblAvailabilityStored"
        Me.lblAvailabilityStored.Size = New System.Drawing.Size(119, 25)
        Me.lblAvailabilityStored.TabIndex = 24
        Me.lblAvailabilityStored.Text = "Availability?"
        Me.lblAvailabilityStored.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstAvailabilityStored
        '
        Me.lstAvailabilityStored.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstAvailabilityStored.FormattingEnabled = True
        Me.lstAvailabilityStored.ItemHeight = 25
        Me.lstAvailabilityStored.Location = New System.Drawing.Point(928, 90)
        Me.lstAvailabilityStored.Name = "lstAvailabilityStored"
        Me.lstAvailabilityStored.Size = New System.Drawing.Size(104, 379)
        Me.lstAvailabilityStored.TabIndex = 23
        '
        'lblTitleData
        '
        Me.lblTitleData.Font = New System.Drawing.Font("Geometos", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleData.Location = New System.Drawing.Point(12, 22)
        Me.lblTitleData.Name = "lblTitleData"
        Me.lblTitleData.Size = New System.Drawing.Size(1020, 25)
        Me.lblTitleData.TabIndex = 25
        Me.lblTitleData.Text = "Stored Employee Data"
        Me.lblTitleData.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnEditInfo
        '
        Me.btnEditInfo.Enabled = False
        Me.btnEditInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditInfo.Location = New System.Drawing.Point(384, 475)
        Me.btnEditInfo.Name = "btnEditInfo"
        Me.btnEditInfo.Size = New System.Drawing.Size(118, 37)
        Me.btnEditInfo.TabIndex = 1
        Me.btnEditInfo.Text = "Edit Info"
        Me.btnEditInfo.UseVisualStyleBackColor = True
        '
        'frmData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1043, 523)
        Me.Controls.Add(Me.btnEditInfo)
        Me.Controls.Add(Me.lblTitleData)
        Me.Controls.Add(Me.lblAvailabilityStored)
        Me.Controls.Add(Me.lstAvailabilityStored)
        Me.Controls.Add(Me.btnRemoveData)
        Me.Controls.Add(Me.lblSelectData)
        Me.Controls.Add(Me.btnAddData)
        Me.Controls.Add(Me.btnOKData)
        Me.Controls.Add(Me.btnEditAvailbility)
        Me.Controls.Add(Me.lblOpenClose)
        Me.Controls.Add(Me.lstOpenClose)
        Me.Controls.Add(Me.lblEmailAddress)
        Me.Controls.Add(Me.lstEmailAddress)
        Me.Controls.Add(Me.lblPhoneNumber)
        Me.Controls.Add(Me.lstPhoneNumber)
        Me.Controls.Add(Me.lblNameLast)
        Me.Controls.Add(Me.lstNameLast)
        Me.Controls.Add(Me.lblNameFirst)
        Me.Controls.Add(Me.lstNameFirst)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmData"
        Me.Text = "Modify Employee Data"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstNameFirst As ListBox
    Friend WithEvents lblNameFirst As Label
    Friend WithEvents lblNameLast As Label
    Friend WithEvents lstNameLast As ListBox
    Friend WithEvents lblPhoneNumber As Label
    Friend WithEvents lstPhoneNumber As ListBox
    Friend WithEvents lblEmailAddress As Label
    Friend WithEvents lstEmailAddress As ListBox
    Friend WithEvents lblOpenClose As Label
    Friend WithEvents lstOpenClose As ListBox
    Friend WithEvents btnEditAvailbility As Button
    Friend WithEvents btnOKData As Button
    Friend WithEvents btnAddData As Button
    Friend WithEvents lblSelectData As Label
    Friend WithEvents btnRemoveData As Button
    Friend WithEvents lblAvailabilityStored As Label
    Friend WithEvents lstAvailabilityStored As ListBox
    Friend WithEvents lblTitleData As Label
    Friend WithEvents btnEditInfo As Button
End Class
