﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnCopyLast = New System.Windows.Forms.Button()
        Me.btnSendRoster = New System.Windows.Forms.Button()
        Me.pnlRoster = New System.Windows.Forms.Panel()
        Me.pnlWednesday = New System.Windows.Forms.Panel()
        Me.ComboBox71 = New System.Windows.Forms.ComboBox()
        Me.ComboBox72 = New System.Windows.Forms.ComboBox()
        Me.ComboBox73 = New System.Windows.Forms.ComboBox()
        Me.ComboBox74 = New System.Windows.Forms.ComboBox()
        Me.ComboBox75 = New System.Windows.Forms.ComboBox()
        Me.ComboBox76 = New System.Windows.Forms.ComboBox()
        Me.ComboBox77 = New System.Windows.Forms.ComboBox()
        Me.ComboBox78 = New System.Windows.Forms.ComboBox()
        Me.ComboBox79 = New System.Windows.Forms.ComboBox()
        Me.ComboBox80 = New System.Windows.Forms.ComboBox()
        Me.ComboBox81 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ComboBox82 = New System.Windows.Forms.ComboBox()
        Me.pnlTuesday = New System.Windows.Forms.Panel()
        Me.ComboBox59 = New System.Windows.Forms.ComboBox()
        Me.ComboBox60 = New System.Windows.Forms.ComboBox()
        Me.ComboBox61 = New System.Windows.Forms.ComboBox()
        Me.ComboBox62 = New System.Windows.Forms.ComboBox()
        Me.ComboBox63 = New System.Windows.Forms.ComboBox()
        Me.ComboBox64 = New System.Windows.Forms.ComboBox()
        Me.ComboBox65 = New System.Windows.Forms.ComboBox()
        Me.ComboBox66 = New System.Windows.Forms.ComboBox()
        Me.ComboBox67 = New System.Windows.Forms.ComboBox()
        Me.ComboBox68 = New System.Windows.Forms.ComboBox()
        Me.ComboBox69 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox70 = New System.Windows.Forms.ComboBox()
        Me.pnlMonday = New System.Windows.Forms.Panel()
        Me.ComboBox47 = New System.Windows.Forms.ComboBox()
        Me.ComboBox48 = New System.Windows.Forms.ComboBox()
        Me.ComboBox49 = New System.Windows.Forms.ComboBox()
        Me.ComboBox50 = New System.Windows.Forms.ComboBox()
        Me.ComboBox51 = New System.Windows.Forms.ComboBox()
        Me.ComboBox52 = New System.Windows.Forms.ComboBox()
        Me.ComboBox53 = New System.Windows.Forms.ComboBox()
        Me.ComboBox54 = New System.Windows.Forms.ComboBox()
        Me.ComboBox55 = New System.Windows.Forms.ComboBox()
        Me.ComboBox56 = New System.Windows.Forms.ComboBox()
        Me.ComboBox57 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ComboBox58 = New System.Windows.Forms.ComboBox()
        Me.pnlSunday = New System.Windows.Forms.Panel()
        Me.ComboBox35 = New System.Windows.Forms.ComboBox()
        Me.ComboBox36 = New System.Windows.Forms.ComboBox()
        Me.ComboBox37 = New System.Windows.Forms.ComboBox()
        Me.ComboBox38 = New System.Windows.Forms.ComboBox()
        Me.ComboBox39 = New System.Windows.Forms.ComboBox()
        Me.ComboBox40 = New System.Windows.Forms.ComboBox()
        Me.ComboBox41 = New System.Windows.Forms.ComboBox()
        Me.ComboBox42 = New System.Windows.Forms.ComboBox()
        Me.ComboBox43 = New System.Windows.Forms.ComboBox()
        Me.ComboBox44 = New System.Windows.Forms.ComboBox()
        Me.ComboBox45 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox46 = New System.Windows.Forms.ComboBox()
        Me.pnlSaturday = New System.Windows.Forms.Panel()
        Me.ComboBox23 = New System.Windows.Forms.ComboBox()
        Me.ComboBox34 = New System.Windows.Forms.ComboBox()
        Me.ComboBox24 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox25 = New System.Windows.Forms.ComboBox()
        Me.ComboBox33 = New System.Windows.Forms.ComboBox()
        Me.ComboBox26 = New System.Windows.Forms.ComboBox()
        Me.ComboBox32 = New System.Windows.Forms.ComboBox()
        Me.ComboBox27 = New System.Windows.Forms.ComboBox()
        Me.ComboBox31 = New System.Windows.Forms.ComboBox()
        Me.ComboBox28 = New System.Windows.Forms.ComboBox()
        Me.ComboBox30 = New System.Windows.Forms.ComboBox()
        Me.ComboBox29 = New System.Windows.Forms.ComboBox()
        Me.pnlFriday = New System.Windows.Forms.Panel()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox22 = New System.Windows.Forms.ComboBox()
        Me.lblTitleMain = New System.Windows.Forms.Label()
        Me.ctxGlobal = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.btnAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCloseApp = New System.Windows.Forms.Button()
        Me.btnSearchArchive = New System.Windows.Forms.Button()
        Me.btnEditData = New System.Windows.Forms.Button()
        Me.btnEditPin = New System.Windows.Forms.Button()
        Me.btnEditShifts = New System.Windows.Forms.Button()
        Me.pnlThursday = New System.Windows.Forms.Panel()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.cmbShiftThu = New System.Windows.Forms.ComboBox()
        Me.lblThursday = New System.Windows.Forms.Label()
        Me.cmbStaffThu = New System.Windows.Forms.ComboBox()
        Me.picLogoMain = New System.Windows.Forms.PictureBox()
        Me.pnlRoster.SuspendLayout()
        Me.pnlWednesday.SuspendLayout()
        Me.pnlTuesday.SuspendLayout()
        Me.pnlMonday.SuspendLayout()
        Me.pnlSunday.SuspendLayout()
        Me.pnlSaturday.SuspendLayout()
        Me.pnlFriday.SuspendLayout()
        Me.ctxGlobal.SuspendLayout()
        Me.pnlThursday.SuspendLayout()
        CType(Me.picLogoMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCopyLast
        '
        Me.btnCopyLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCopyLast.Location = New System.Drawing.Point(12, 1008)
        Me.btnCopyLast.Name = "btnCopyLast"
        Me.btnCopyLast.Size = New System.Drawing.Size(180, 60)
        Me.btnCopyLast.TabIndex = 0
        Me.btnCopyLast.Text = "Copy Last" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Roster"
        Me.btnCopyLast.UseVisualStyleBackColor = True
        '
        'btnSendRoster
        '
        Me.btnSendRoster.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSendRoster.Location = New System.Drawing.Point(1728, 1008)
        Me.btnSendRoster.Name = "btnSendRoster"
        Me.btnSendRoster.Size = New System.Drawing.Size(180, 60)
        Me.btnSendRoster.TabIndex = 6
        Me.btnSendRoster.Text = "Send and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Archive"
        Me.btnSendRoster.UseVisualStyleBackColor = True
        '
        'pnlRoster
        '
        Me.pnlRoster.Controls.Add(Me.pnlWednesday)
        Me.pnlRoster.Controls.Add(Me.pnlTuesday)
        Me.pnlRoster.Controls.Add(Me.pnlMonday)
        Me.pnlRoster.Controls.Add(Me.pnlSunday)
        Me.pnlRoster.Controls.Add(Me.pnlSaturday)
        Me.pnlRoster.Controls.Add(Me.pnlFriday)
        Me.pnlRoster.Location = New System.Drawing.Point(12, 138)
        Me.pnlRoster.Name = "pnlRoster"
        Me.pnlRoster.Size = New System.Drawing.Size(1896, 864)
        Me.pnlRoster.TabIndex = 0
        '
        'pnlWednesday
        '
        Me.pnlWednesday.Controls.Add(Me.ComboBox71)
        Me.pnlWednesday.Controls.Add(Me.ComboBox72)
        Me.pnlWednesday.Controls.Add(Me.ComboBox73)
        Me.pnlWednesday.Controls.Add(Me.ComboBox74)
        Me.pnlWednesday.Controls.Add(Me.ComboBox75)
        Me.pnlWednesday.Controls.Add(Me.ComboBox76)
        Me.pnlWednesday.Controls.Add(Me.ComboBox77)
        Me.pnlWednesday.Controls.Add(Me.ComboBox78)
        Me.pnlWednesday.Controls.Add(Me.ComboBox79)
        Me.pnlWednesday.Controls.Add(Me.ComboBox80)
        Me.pnlWednesday.Controls.Add(Me.ComboBox81)
        Me.pnlWednesday.Controls.Add(Me.Label6)
        Me.pnlWednesday.Controls.Add(Me.ComboBox82)
        Me.pnlWednesday.Location = New System.Drawing.Point(1620, 3)
        Me.pnlWednesday.Name = "pnlWednesday"
        Me.pnlWednesday.Size = New System.Drawing.Size(270, 858)
        Me.pnlWednesday.TabIndex = 6
        '
        'ComboBox71
        '
        Me.ComboBox71.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox71.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox71.FormattingEnabled = True
        Me.ComboBox71.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox71.Name = "ComboBox71"
        Me.ComboBox71.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox71.TabIndex = 35
        '
        'ComboBox72
        '
        Me.ComboBox72.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox72.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox72.FormattingEnabled = True
        Me.ComboBox72.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox72.Name = "ComboBox72"
        Me.ComboBox72.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox72.TabIndex = 34
        '
        'ComboBox73
        '
        Me.ComboBox73.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox73.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox73.FormattingEnabled = True
        Me.ComboBox73.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox73.Name = "ComboBox73"
        Me.ComboBox73.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox73.TabIndex = 33
        '
        'ComboBox74
        '
        Me.ComboBox74.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox74.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox74.FormattingEnabled = True
        Me.ComboBox74.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox74.Name = "ComboBox74"
        Me.ComboBox74.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox74.TabIndex = 32
        '
        'ComboBox75
        '
        Me.ComboBox75.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox75.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox75.FormattingEnabled = True
        Me.ComboBox75.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox75.Name = "ComboBox75"
        Me.ComboBox75.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox75.TabIndex = 31
        '
        'ComboBox76
        '
        Me.ComboBox76.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox76.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox76.FormattingEnabled = True
        Me.ComboBox76.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox76.Name = "ComboBox76"
        Me.ComboBox76.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox76.TabIndex = 30
        '
        'ComboBox77
        '
        Me.ComboBox77.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox77.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox77.FormattingEnabled = True
        Me.ComboBox77.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox77.Name = "ComboBox77"
        Me.ComboBox77.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox77.TabIndex = 29
        '
        'ComboBox78
        '
        Me.ComboBox78.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox78.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox78.FormattingEnabled = True
        Me.ComboBox78.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox78.Name = "ComboBox78"
        Me.ComboBox78.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox78.TabIndex = 28
        '
        'ComboBox79
        '
        Me.ComboBox79.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox79.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox79.FormattingEnabled = True
        Me.ComboBox79.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox79.Name = "ComboBox79"
        Me.ComboBox79.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox79.TabIndex = 27
        '
        'ComboBox80
        '
        Me.ComboBox80.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox80.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox80.FormattingEnabled = True
        Me.ComboBox80.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox80.Name = "ComboBox80"
        Me.ComboBox80.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox80.TabIndex = 26
        '
        'ComboBox81
        '
        Me.ComboBox81.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox81.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox81.FormattingEnabled = True
        Me.ComboBox81.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox81.Name = "ComboBox81"
        Me.ComboBox81.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox81.TabIndex = 25
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(26, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(221, 35)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Wednesday"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox82
        '
        Me.ComboBox82.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox82.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox82.FormattingEnabled = True
        Me.ComboBox82.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox82.Name = "ComboBox82"
        Me.ComboBox82.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox82.TabIndex = 23
        '
        'pnlTuesday
        '
        Me.pnlTuesday.Controls.Add(Me.ComboBox59)
        Me.pnlTuesday.Controls.Add(Me.ComboBox60)
        Me.pnlTuesday.Controls.Add(Me.ComboBox61)
        Me.pnlTuesday.Controls.Add(Me.ComboBox62)
        Me.pnlTuesday.Controls.Add(Me.ComboBox63)
        Me.pnlTuesday.Controls.Add(Me.ComboBox64)
        Me.pnlTuesday.Controls.Add(Me.ComboBox65)
        Me.pnlTuesday.Controls.Add(Me.ComboBox66)
        Me.pnlTuesday.Controls.Add(Me.ComboBox67)
        Me.pnlTuesday.Controls.Add(Me.ComboBox68)
        Me.pnlTuesday.Controls.Add(Me.ComboBox69)
        Me.pnlTuesday.Controls.Add(Me.Label5)
        Me.pnlTuesday.Controls.Add(Me.ComboBox70)
        Me.pnlTuesday.Location = New System.Drawing.Point(1351, 3)
        Me.pnlTuesday.Name = "pnlTuesday"
        Me.pnlTuesday.Size = New System.Drawing.Size(270, 858)
        Me.pnlTuesday.TabIndex = 5
        '
        'ComboBox59
        '
        Me.ComboBox59.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox59.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox59.FormattingEnabled = True
        Me.ComboBox59.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox59.Name = "ComboBox59"
        Me.ComboBox59.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox59.TabIndex = 35
        '
        'ComboBox60
        '
        Me.ComboBox60.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox60.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox60.FormattingEnabled = True
        Me.ComboBox60.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox60.Name = "ComboBox60"
        Me.ComboBox60.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox60.TabIndex = 34
        '
        'ComboBox61
        '
        Me.ComboBox61.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox61.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox61.FormattingEnabled = True
        Me.ComboBox61.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox61.Name = "ComboBox61"
        Me.ComboBox61.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox61.TabIndex = 33
        '
        'ComboBox62
        '
        Me.ComboBox62.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox62.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox62.FormattingEnabled = True
        Me.ComboBox62.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox62.Name = "ComboBox62"
        Me.ComboBox62.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox62.TabIndex = 32
        '
        'ComboBox63
        '
        Me.ComboBox63.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox63.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox63.FormattingEnabled = True
        Me.ComboBox63.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox63.Name = "ComboBox63"
        Me.ComboBox63.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox63.TabIndex = 31
        '
        'ComboBox64
        '
        Me.ComboBox64.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox64.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox64.FormattingEnabled = True
        Me.ComboBox64.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox64.Name = "ComboBox64"
        Me.ComboBox64.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox64.TabIndex = 30
        '
        'ComboBox65
        '
        Me.ComboBox65.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox65.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox65.FormattingEnabled = True
        Me.ComboBox65.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox65.Name = "ComboBox65"
        Me.ComboBox65.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox65.TabIndex = 29
        '
        'ComboBox66
        '
        Me.ComboBox66.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox66.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox66.FormattingEnabled = True
        Me.ComboBox66.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox66.Name = "ComboBox66"
        Me.ComboBox66.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox66.TabIndex = 28
        '
        'ComboBox67
        '
        Me.ComboBox67.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox67.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox67.FormattingEnabled = True
        Me.ComboBox67.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox67.Name = "ComboBox67"
        Me.ComboBox67.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox67.TabIndex = 27
        '
        'ComboBox68
        '
        Me.ComboBox68.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox68.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox68.FormattingEnabled = True
        Me.ComboBox68.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox68.Name = "ComboBox68"
        Me.ComboBox68.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox68.TabIndex = 26
        '
        'ComboBox69
        '
        Me.ComboBox69.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox69.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox69.FormattingEnabled = True
        Me.ComboBox69.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox69.Name = "ComboBox69"
        Me.ComboBox69.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox69.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(54, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(165, 35)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Tuesday"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox70
        '
        Me.ComboBox70.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox70.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox70.FormattingEnabled = True
        Me.ComboBox70.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox70.Name = "ComboBox70"
        Me.ComboBox70.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox70.TabIndex = 23
        '
        'pnlMonday
        '
        Me.pnlMonday.Controls.Add(Me.ComboBox47)
        Me.pnlMonday.Controls.Add(Me.ComboBox48)
        Me.pnlMonday.Controls.Add(Me.ComboBox49)
        Me.pnlMonday.Controls.Add(Me.ComboBox50)
        Me.pnlMonday.Controls.Add(Me.ComboBox51)
        Me.pnlMonday.Controls.Add(Me.ComboBox52)
        Me.pnlMonday.Controls.Add(Me.ComboBox53)
        Me.pnlMonday.Controls.Add(Me.ComboBox54)
        Me.pnlMonday.Controls.Add(Me.ComboBox55)
        Me.pnlMonday.Controls.Add(Me.ComboBox56)
        Me.pnlMonday.Controls.Add(Me.ComboBox57)
        Me.pnlMonday.Controls.Add(Me.Label4)
        Me.pnlMonday.Controls.Add(Me.ComboBox58)
        Me.pnlMonday.Location = New System.Drawing.Point(1082, 3)
        Me.pnlMonday.Name = "pnlMonday"
        Me.pnlMonday.Size = New System.Drawing.Size(270, 858)
        Me.pnlMonday.TabIndex = 4
        '
        'ComboBox47
        '
        Me.ComboBox47.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox47.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox47.FormattingEnabled = True
        Me.ComboBox47.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox47.Name = "ComboBox47"
        Me.ComboBox47.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox47.TabIndex = 35
        '
        'ComboBox48
        '
        Me.ComboBox48.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox48.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox48.FormattingEnabled = True
        Me.ComboBox48.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox48.Name = "ComboBox48"
        Me.ComboBox48.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox48.TabIndex = 34
        '
        'ComboBox49
        '
        Me.ComboBox49.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox49.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox49.FormattingEnabled = True
        Me.ComboBox49.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox49.Name = "ComboBox49"
        Me.ComboBox49.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox49.TabIndex = 33
        '
        'ComboBox50
        '
        Me.ComboBox50.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox50.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox50.FormattingEnabled = True
        Me.ComboBox50.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox50.Name = "ComboBox50"
        Me.ComboBox50.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox50.TabIndex = 32
        '
        'ComboBox51
        '
        Me.ComboBox51.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox51.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox51.FormattingEnabled = True
        Me.ComboBox51.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox51.Name = "ComboBox51"
        Me.ComboBox51.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox51.TabIndex = 31
        '
        'ComboBox52
        '
        Me.ComboBox52.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox52.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox52.FormattingEnabled = True
        Me.ComboBox52.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox52.Name = "ComboBox52"
        Me.ComboBox52.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox52.TabIndex = 30
        '
        'ComboBox53
        '
        Me.ComboBox53.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox53.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox53.FormattingEnabled = True
        Me.ComboBox53.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox53.Name = "ComboBox53"
        Me.ComboBox53.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox53.TabIndex = 29
        '
        'ComboBox54
        '
        Me.ComboBox54.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox54.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox54.FormattingEnabled = True
        Me.ComboBox54.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox54.Name = "ComboBox54"
        Me.ComboBox54.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox54.TabIndex = 28
        '
        'ComboBox55
        '
        Me.ComboBox55.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox55.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox55.FormattingEnabled = True
        Me.ComboBox55.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox55.Name = "ComboBox55"
        Me.ComboBox55.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox55.TabIndex = 27
        '
        'ComboBox56
        '
        Me.ComboBox56.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox56.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox56.FormattingEnabled = True
        Me.ComboBox56.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox56.Name = "ComboBox56"
        Me.ComboBox56.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox56.TabIndex = 26
        '
        'ComboBox57
        '
        Me.ComboBox57.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox57.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox57.FormattingEnabled = True
        Me.ComboBox57.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox57.Name = "ComboBox57"
        Me.ComboBox57.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox57.TabIndex = 25
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(56, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(158, 35)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Monday"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox58
        '
        Me.ComboBox58.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox58.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox58.FormattingEnabled = True
        Me.ComboBox58.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox58.Name = "ComboBox58"
        Me.ComboBox58.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox58.TabIndex = 23
        '
        'pnlSunday
        '
        Me.pnlSunday.Controls.Add(Me.ComboBox35)
        Me.pnlSunday.Controls.Add(Me.ComboBox36)
        Me.pnlSunday.Controls.Add(Me.ComboBox37)
        Me.pnlSunday.Controls.Add(Me.ComboBox38)
        Me.pnlSunday.Controls.Add(Me.ComboBox39)
        Me.pnlSunday.Controls.Add(Me.ComboBox40)
        Me.pnlSunday.Controls.Add(Me.ComboBox41)
        Me.pnlSunday.Controls.Add(Me.ComboBox42)
        Me.pnlSunday.Controls.Add(Me.ComboBox43)
        Me.pnlSunday.Controls.Add(Me.ComboBox44)
        Me.pnlSunday.Controls.Add(Me.ComboBox45)
        Me.pnlSunday.Controls.Add(Me.Label3)
        Me.pnlSunday.Controls.Add(Me.ComboBox46)
        Me.pnlSunday.Location = New System.Drawing.Point(813, 3)
        Me.pnlSunday.Name = "pnlSunday"
        Me.pnlSunday.Size = New System.Drawing.Size(270, 858)
        Me.pnlSunday.TabIndex = 3
        '
        'ComboBox35
        '
        Me.ComboBox35.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox35.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox35.FormattingEnabled = True
        Me.ComboBox35.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox35.Name = "ComboBox35"
        Me.ComboBox35.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox35.TabIndex = 35
        '
        'ComboBox36
        '
        Me.ComboBox36.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox36.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox36.FormattingEnabled = True
        Me.ComboBox36.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox36.Name = "ComboBox36"
        Me.ComboBox36.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox36.TabIndex = 34
        '
        'ComboBox37
        '
        Me.ComboBox37.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox37.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox37.FormattingEnabled = True
        Me.ComboBox37.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox37.Name = "ComboBox37"
        Me.ComboBox37.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox37.TabIndex = 33
        '
        'ComboBox38
        '
        Me.ComboBox38.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox38.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox38.FormattingEnabled = True
        Me.ComboBox38.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox38.Name = "ComboBox38"
        Me.ComboBox38.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox38.TabIndex = 32
        '
        'ComboBox39
        '
        Me.ComboBox39.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox39.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox39.FormattingEnabled = True
        Me.ComboBox39.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox39.Name = "ComboBox39"
        Me.ComboBox39.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox39.TabIndex = 31
        '
        'ComboBox40
        '
        Me.ComboBox40.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox40.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox40.FormattingEnabled = True
        Me.ComboBox40.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox40.Name = "ComboBox40"
        Me.ComboBox40.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox40.TabIndex = 30
        '
        'ComboBox41
        '
        Me.ComboBox41.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox41.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox41.FormattingEnabled = True
        Me.ComboBox41.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox41.Name = "ComboBox41"
        Me.ComboBox41.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox41.TabIndex = 29
        '
        'ComboBox42
        '
        Me.ComboBox42.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox42.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox42.FormattingEnabled = True
        Me.ComboBox42.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox42.Name = "ComboBox42"
        Me.ComboBox42.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox42.TabIndex = 28
        '
        'ComboBox43
        '
        Me.ComboBox43.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox43.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox43.FormattingEnabled = True
        Me.ComboBox43.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox43.Name = "ComboBox43"
        Me.ComboBox43.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox43.TabIndex = 27
        '
        'ComboBox44
        '
        Me.ComboBox44.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox44.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox44.FormattingEnabled = True
        Me.ComboBox44.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox44.Name = "ComboBox44"
        Me.ComboBox44.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox44.TabIndex = 26
        '
        'ComboBox45
        '
        Me.ComboBox45.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox45.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox45.FormattingEnabled = True
        Me.ComboBox45.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox45.Name = "ComboBox45"
        Me.ComboBox45.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox45.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(60, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 35)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Sunday"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox46
        '
        Me.ComboBox46.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox46.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox46.FormattingEnabled = True
        Me.ComboBox46.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox46.Name = "ComboBox46"
        Me.ComboBox46.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox46.TabIndex = 23
        '
        'pnlSaturday
        '
        Me.pnlSaturday.Controls.Add(Me.ComboBox23)
        Me.pnlSaturday.Controls.Add(Me.ComboBox34)
        Me.pnlSaturday.Controls.Add(Me.ComboBox24)
        Me.pnlSaturday.Controls.Add(Me.Label2)
        Me.pnlSaturday.Controls.Add(Me.ComboBox25)
        Me.pnlSaturday.Controls.Add(Me.ComboBox33)
        Me.pnlSaturday.Controls.Add(Me.ComboBox26)
        Me.pnlSaturday.Controls.Add(Me.ComboBox32)
        Me.pnlSaturday.Controls.Add(Me.ComboBox27)
        Me.pnlSaturday.Controls.Add(Me.ComboBox31)
        Me.pnlSaturday.Controls.Add(Me.ComboBox28)
        Me.pnlSaturday.Controls.Add(Me.ComboBox30)
        Me.pnlSaturday.Controls.Add(Me.ComboBox29)
        Me.pnlSaturday.Location = New System.Drawing.Point(544, 3)
        Me.pnlSaturday.Name = "pnlSaturday"
        Me.pnlSaturday.Size = New System.Drawing.Size(270, 858)
        Me.pnlSaturday.TabIndex = 2
        '
        'ComboBox23
        '
        Me.ComboBox23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox23.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox23.Name = "ComboBox23"
        Me.ComboBox23.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox23.TabIndex = 48
        '
        'ComboBox34
        '
        Me.ComboBox34.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox34.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox34.FormattingEnabled = True
        Me.ComboBox34.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox34.Name = "ComboBox34"
        Me.ComboBox34.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox34.TabIndex = 36
        '
        'ComboBox24
        '
        Me.ComboBox24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox24.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox24.Name = "ComboBox24"
        Me.ComboBox24.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox24.TabIndex = 47
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(43, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(190, 35)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Saturday"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox25
        '
        Me.ComboBox25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox25.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox25.Name = "ComboBox25"
        Me.ComboBox25.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox25.TabIndex = 46
        '
        'ComboBox33
        '
        Me.ComboBox33.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox33.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox33.FormattingEnabled = True
        Me.ComboBox33.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox33.Name = "ComboBox33"
        Me.ComboBox33.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox33.TabIndex = 38
        '
        'ComboBox26
        '
        Me.ComboBox26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox26.FormattingEnabled = True
        Me.ComboBox26.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox26.Name = "ComboBox26"
        Me.ComboBox26.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox26.TabIndex = 45
        '
        'ComboBox32
        '
        Me.ComboBox32.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox32.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox32.FormattingEnabled = True
        Me.ComboBox32.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox32.Name = "ComboBox32"
        Me.ComboBox32.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox32.TabIndex = 39
        '
        'ComboBox27
        '
        Me.ComboBox27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox27.Name = "ComboBox27"
        Me.ComboBox27.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox27.TabIndex = 44
        '
        'ComboBox31
        '
        Me.ComboBox31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox31.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox31.Name = "ComboBox31"
        Me.ComboBox31.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox31.TabIndex = 40
        '
        'ComboBox28
        '
        Me.ComboBox28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox28.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox28.FormattingEnabled = True
        Me.ComboBox28.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox28.Name = "ComboBox28"
        Me.ComboBox28.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox28.TabIndex = 43
        '
        'ComboBox30
        '
        Me.ComboBox30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox30.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox30.FormattingEnabled = True
        Me.ComboBox30.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox30.Name = "ComboBox30"
        Me.ComboBox30.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox30.TabIndex = 41
        '
        'ComboBox29
        '
        Me.ComboBox29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox29.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox29.Name = "ComboBox29"
        Me.ComboBox29.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox29.TabIndex = 42
        '
        'pnlFriday
        '
        Me.pnlFriday.Controls.Add(Me.ComboBox11)
        Me.pnlFriday.Controls.Add(Me.ComboBox12)
        Me.pnlFriday.Controls.Add(Me.ComboBox13)
        Me.pnlFriday.Controls.Add(Me.ComboBox14)
        Me.pnlFriday.Controls.Add(Me.ComboBox15)
        Me.pnlFriday.Controls.Add(Me.ComboBox16)
        Me.pnlFriday.Controls.Add(Me.ComboBox17)
        Me.pnlFriday.Controls.Add(Me.ComboBox18)
        Me.pnlFriday.Controls.Add(Me.ComboBox19)
        Me.pnlFriday.Controls.Add(Me.ComboBox20)
        Me.pnlFriday.Controls.Add(Me.ComboBox21)
        Me.pnlFriday.Controls.Add(Me.Label1)
        Me.pnlFriday.Controls.Add(Me.ComboBox22)
        Me.pnlFriday.Location = New System.Drawing.Point(275, 3)
        Me.pnlFriday.Name = "pnlFriday"
        Me.pnlFriday.Size = New System.Drawing.Size(270, 858)
        Me.pnlFriday.TabIndex = 1
        '
        'ComboBox11
        '
        Me.ComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox11.TabIndex = 35
        '
        'ComboBox12
        '
        Me.ComboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox12.TabIndex = 34
        '
        'ComboBox13
        '
        Me.ComboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox13.TabIndex = 33
        '
        'ComboBox14
        '
        Me.ComboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox14.TabIndex = 32
        '
        'ComboBox15
        '
        Me.ComboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox15.TabIndex = 31
        '
        'ComboBox16
        '
        Me.ComboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox16.TabIndex = 30
        '
        'ComboBox17
        '
        Me.ComboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox17.TabIndex = 29
        '
        'ComboBox18
        '
        Me.ComboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox18.TabIndex = 28
        '
        'ComboBox19
        '
        Me.ComboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox19.TabIndex = 27
        '
        'ComboBox20
        '
        Me.ComboBox20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox20.TabIndex = 26
        '
        'ComboBox21
        '
        Me.ComboBox21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(3, 132)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox21.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 35)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Friday"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ComboBox22
        '
        Me.ComboBox22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Location = New System.Drawing.Point(3, 87)
        Me.ComboBox22.Name = "ComboBox22"
        Me.ComboBox22.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox22.TabIndex = 23
        '
        'lblTitleMain
        '
        Me.lblTitleMain.AutoSize = True
        Me.lblTitleMain.Font = New System.Drawing.Font("Geometos", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleMain.Location = New System.Drawing.Point(758, 50)
        Me.lblTitleMain.Name = "lblTitleMain"
        Me.lblTitleMain.Size = New System.Drawing.Size(579, 44)
        Me.lblTitleMain.TabIndex = 4
        Me.lblTitleMain.Text = "Roster Creation System"
        '
        'ctxGlobal
        '
        Me.ctxGlobal.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ctxGlobal.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnAbout})
        Me.ctxGlobal.Name = "ctxGlobal"
        Me.ctxGlobal.Size = New System.Drawing.Size(217, 28)
        '
        'btnAbout
        '
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(216, 24)
        Me.btnAbout.Text = "About Roster System"
        '
        'btnCloseApp
        '
        Me.btnCloseApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseApp.Location = New System.Drawing.Point(1542, 1008)
        Me.btnCloseApp.Name = "btnCloseApp"
        Me.btnCloseApp.Size = New System.Drawing.Size(180, 60)
        Me.btnCloseApp.TabIndex = 5
        Me.btnCloseApp.Text = "Cancel and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Close All"
        Me.btnCloseApp.UseVisualStyleBackColor = True
        '
        'btnSearchArchive
        '
        Me.btnSearchArchive.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchArchive.Location = New System.Drawing.Point(198, 1008)
        Me.btnSearchArchive.Name = "btnSearchArchive"
        Me.btnSearchArchive.Size = New System.Drawing.Size(180, 60)
        Me.btnSearchArchive.TabIndex = 1
        Me.btnSearchArchive.Text = "Search" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Archive"
        Me.btnSearchArchive.UseVisualStyleBackColor = True
        '
        'btnEditData
        '
        Me.btnEditData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditData.Location = New System.Drawing.Point(384, 1008)
        Me.btnEditData.Name = "btnEditData"
        Me.btnEditData.Size = New System.Drawing.Size(180, 60)
        Me.btnEditData.TabIndex = 2
        Me.btnEditData.Text = "Modify" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Employee Data"
        Me.btnEditData.UseVisualStyleBackColor = True
        '
        'btnEditPin
        '
        Me.btnEditPin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditPin.Location = New System.Drawing.Point(756, 1008)
        Me.btnEditPin.Name = "btnEditPin"
        Me.btnEditPin.Size = New System.Drawing.Size(180, 60)
        Me.btnEditPin.TabIndex = 4
        Me.btnEditPin.Text = "Change" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "User PIN"
        Me.btnEditPin.UseVisualStyleBackColor = True
        '
        'btnEditShifts
        '
        Me.btnEditShifts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditShifts.Location = New System.Drawing.Point(570, 1008)
        Me.btnEditShifts.Name = "btnEditShifts"
        Me.btnEditShifts.Size = New System.Drawing.Size(180, 60)
        Me.btnEditShifts.TabIndex = 3
        Me.btnEditShifts.Text = "Edit" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Shift Blocks"
        Me.btnEditShifts.UseVisualStyleBackColor = True
        '
        'pnlThursday
        '
        Me.pnlThursday.Controls.Add(Me.ComboBox7)
        Me.pnlThursday.Controls.Add(Me.ComboBox8)
        Me.pnlThursday.Controls.Add(Me.ComboBox9)
        Me.pnlThursday.Controls.Add(Me.ComboBox10)
        Me.pnlThursday.Controls.Add(Me.ComboBox3)
        Me.pnlThursday.Controls.Add(Me.ComboBox4)
        Me.pnlThursday.Controls.Add(Me.ComboBox5)
        Me.pnlThursday.Controls.Add(Me.ComboBox6)
        Me.pnlThursday.Controls.Add(Me.ComboBox1)
        Me.pnlThursday.Controls.Add(Me.ComboBox2)
        Me.pnlThursday.Controls.Add(Me.cmbShiftThu)
        Me.pnlThursday.Controls.Add(Me.lblThursday)
        Me.pnlThursday.Controls.Add(Me.cmbStaffThu)
        Me.pnlThursday.Location = New System.Drawing.Point(18, 141)
        Me.pnlThursday.Name = "pnlThursday"
        Me.pnlThursday.Size = New System.Drawing.Size(270, 858)
        Me.pnlThursday.TabIndex = 0
        '
        'ComboBox7
        '
        Me.ComboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(3, 789)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox7.TabIndex = 22
        '
        'ComboBox8
        '
        Me.ComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(3, 744)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox8.TabIndex = 21
        '
        'ComboBox9
        '
        Me.ComboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(3, 659)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox9.TabIndex = 20
        '
        'ComboBox10
        '
        Me.ComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(3, 614)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox10.TabIndex = 19
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(3, 528)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox3.TabIndex = 18
        '
        'ComboBox4
        '
        Me.ComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(3, 483)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox4.TabIndex = 17
        '
        'ComboBox5
        '
        Me.ComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(3, 397)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox5.TabIndex = 16
        '
        'ComboBox6
        '
        Me.ComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(3, 352)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox6.TabIndex = 15
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(3, 264)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox1.TabIndex = 14
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(3, 219)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(264, 39)
        Me.ComboBox2.TabIndex = 13
        '
        'cmbShiftThu
        '
        Me.cmbShiftThu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbShiftThu.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbShiftThu.FormattingEnabled = True
        Me.cmbShiftThu.Location = New System.Drawing.Point(3, 132)
        Me.cmbShiftThu.Name = "cmbShiftThu"
        Me.cmbShiftThu.Size = New System.Drawing.Size(264, 39)
        Me.cmbShiftThu.TabIndex = 12
        '
        'lblThursday
        '
        Me.lblThursday.AutoSize = True
        Me.lblThursday.Font = New System.Drawing.Font("Geometos", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThursday.Location = New System.Drawing.Point(39, 27)
        Me.lblThursday.Name = "lblThursday"
        Me.lblThursday.Size = New System.Drawing.Size(190, 35)
        Me.lblThursday.TabIndex = 11
        Me.lblThursday.Text = "Thursday"
        Me.lblThursday.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmbStaffThu
        '
        Me.cmbStaffThu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStaffThu.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStaffThu.FormattingEnabled = True
        Me.cmbStaffThu.Location = New System.Drawing.Point(3, 87)
        Me.cmbStaffThu.Name = "cmbStaffThu"
        Me.cmbStaffThu.Size = New System.Drawing.Size(264, 39)
        Me.cmbStaffThu.TabIndex = 0
        '
        'picLogoMain
        '
        Me.picLogoMain.Image = Global.WindowsApp1.My.Resources.Resources.logo
        Me.picLogoMain.Location = New System.Drawing.Point(632, 12)
        Me.picLogoMain.Name = "picLogoMain"
        Me.picLogoMain.Size = New System.Drawing.Size(120, 120)
        Me.picLogoMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLogoMain.TabIndex = 3
        Me.picLogoMain.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1920, 1080)
        Me.ContextMenuStrip = Me.ctxGlobal
        Me.Controls.Add(Me.pnlThursday)
        Me.Controls.Add(Me.btnEditPin)
        Me.Controls.Add(Me.btnEditShifts)
        Me.Controls.Add(Me.btnEditData)
        Me.Controls.Add(Me.btnSearchArchive)
        Me.Controls.Add(Me.btnCloseApp)
        Me.Controls.Add(Me.lblTitleMain)
        Me.Controls.Add(Me.picLogoMain)
        Me.Controls.Add(Me.pnlRoster)
        Me.Controls.Add(Me.btnSendRoster)
        Me.Controls.Add(Me.btnCopyLast)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "frmMain"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pnlRoster.ResumeLayout(False)
        Me.pnlWednesday.ResumeLayout(False)
        Me.pnlWednesday.PerformLayout()
        Me.pnlTuesday.ResumeLayout(False)
        Me.pnlTuesday.PerformLayout()
        Me.pnlMonday.ResumeLayout(False)
        Me.pnlMonday.PerformLayout()
        Me.pnlSunday.ResumeLayout(False)
        Me.pnlSunday.PerformLayout()
        Me.pnlSaturday.ResumeLayout(False)
        Me.pnlSaturday.PerformLayout()
        Me.pnlFriday.ResumeLayout(False)
        Me.pnlFriday.PerformLayout()
        Me.ctxGlobal.ResumeLayout(False)
        Me.pnlThursday.ResumeLayout(False)
        Me.pnlThursday.PerformLayout()
        CType(Me.picLogoMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCopyLast As Button
    Friend WithEvents btnSendRoster As Button
    Friend WithEvents pnlRoster As Panel
    Friend WithEvents picLogoMain As PictureBox
    Friend WithEvents lblTitleMain As Label
    Friend WithEvents ctxGlobal As ContextMenuStrip
    Friend WithEvents btnAbout As ToolStripMenuItem
    Friend WithEvents btnCloseApp As Button
    Friend WithEvents btnSearchArchive As Button
    Friend WithEvents btnEditData As Button
    Friend WithEvents btnEditPin As Button
    Friend WithEvents btnEditShifts As Button
    Friend WithEvents pnlThursday As Panel
    Friend WithEvents pnlWednesday As Panel
    Friend WithEvents pnlTuesday As Panel
    Friend WithEvents pnlMonday As Panel
    Friend WithEvents pnlSunday As Panel
    Friend WithEvents pnlSaturday As Panel
    Friend WithEvents pnlFriday As Panel
    Friend WithEvents cmbShiftThu As ComboBox
    Friend WithEvents lblThursday As Label
    Friend WithEvents cmbStaffThu As ComboBox
    Friend WithEvents ComboBox71 As ComboBox
    Friend WithEvents ComboBox72 As ComboBox
    Friend WithEvents ComboBox73 As ComboBox
    Friend WithEvents ComboBox74 As ComboBox
    Friend WithEvents ComboBox75 As ComboBox
    Friend WithEvents ComboBox76 As ComboBox
    Friend WithEvents ComboBox77 As ComboBox
    Friend WithEvents ComboBox78 As ComboBox
    Friend WithEvents ComboBox79 As ComboBox
    Friend WithEvents ComboBox80 As ComboBox
    Friend WithEvents ComboBox81 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ComboBox82 As ComboBox
    Friend WithEvents ComboBox59 As ComboBox
    Friend WithEvents ComboBox60 As ComboBox
    Friend WithEvents ComboBox61 As ComboBox
    Friend WithEvents ComboBox62 As ComboBox
    Friend WithEvents ComboBox63 As ComboBox
    Friend WithEvents ComboBox64 As ComboBox
    Friend WithEvents ComboBox65 As ComboBox
    Friend WithEvents ComboBox66 As ComboBox
    Friend WithEvents ComboBox67 As ComboBox
    Friend WithEvents ComboBox68 As ComboBox
    Friend WithEvents ComboBox69 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox70 As ComboBox
    Friend WithEvents ComboBox47 As ComboBox
    Friend WithEvents ComboBox48 As ComboBox
    Friend WithEvents ComboBox49 As ComboBox
    Friend WithEvents ComboBox50 As ComboBox
    Friend WithEvents ComboBox51 As ComboBox
    Friend WithEvents ComboBox52 As ComboBox
    Friend WithEvents ComboBox53 As ComboBox
    Friend WithEvents ComboBox54 As ComboBox
    Friend WithEvents ComboBox55 As ComboBox
    Friend WithEvents ComboBox56 As ComboBox
    Friend WithEvents ComboBox57 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox58 As ComboBox
    Friend WithEvents ComboBox35 As ComboBox
    Friend WithEvents ComboBox36 As ComboBox
    Friend WithEvents ComboBox37 As ComboBox
    Friend WithEvents ComboBox38 As ComboBox
    Friend WithEvents ComboBox39 As ComboBox
    Friend WithEvents ComboBox40 As ComboBox
    Friend WithEvents ComboBox41 As ComboBox
    Friend WithEvents ComboBox42 As ComboBox
    Friend WithEvents ComboBox43 As ComboBox
    Friend WithEvents ComboBox44 As ComboBox
    Friend WithEvents ComboBox45 As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox46 As ComboBox
    Friend WithEvents ComboBox23 As ComboBox
    Friend WithEvents ComboBox34 As ComboBox
    Friend WithEvents ComboBox24 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox25 As ComboBox
    Friend WithEvents ComboBox33 As ComboBox
    Friend WithEvents ComboBox26 As ComboBox
    Friend WithEvents ComboBox32 As ComboBox
    Friend WithEvents ComboBox27 As ComboBox
    Friend WithEvents ComboBox31 As ComboBox
    Friend WithEvents ComboBox28 As ComboBox
    Friend WithEvents ComboBox30 As ComboBox
    Friend WithEvents ComboBox29 As ComboBox
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents ComboBox16 As ComboBox
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents ComboBox18 As ComboBox
    Friend WithEvents ComboBox19 As ComboBox
    Friend WithEvents ComboBox20 As ComboBox
    Friend WithEvents ComboBox21 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox22 As ComboBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
End Class
