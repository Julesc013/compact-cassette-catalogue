﻿Public Class frmData
    Private Sub btnEditAvailbility_Click(sender As Object, e As EventArgs) Handles btnEditAvailbility.Click
        frmAvailability.Show()
    End Sub
End Class