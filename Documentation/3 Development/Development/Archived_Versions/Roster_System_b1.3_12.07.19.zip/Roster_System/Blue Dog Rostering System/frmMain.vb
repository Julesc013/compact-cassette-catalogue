﻿' Name:             Main Roster Generation
' Purpose:          Creates and sends rosters. Provides buttons for accessing other forms (is root from).
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    5 June 2019

Imports System.Globalization
Imports System.IO

Public Class frmMain

    'Declare variables

    'Paths to files (cannot be literal constant)
    Dim EMPLOYEEDATA As String = FILEPATH & "\Data\Employees.xlsx"
    Dim SHIFTDATA As String = FILEPATH & "\Data\Shifts.xlsx"

    ''Dim ROSTERCURRENT As String = FILEPATH & "\Archive\" & rosterName & ".xlsx" 'Roster to archive and export
    Dim ROSTERLATEST As String = FILEPATH & "\Roster_Latest.pdf" 'Exported roster to send
    Dim ROSTERSUGGESTED As String = FILEPATH & "\Roster_Suggested.xlsx" 'Roster suggested by chef/managers


    Const OWNEREMAIL As String = "dummyemail@service.com" 'Email from which rosters are sent 'TBD

    ''\\\Unused code for day of the week identification...
    ''Source: https://stackoverflow.com/questions/3771922/add-keys-values-to-dictionary-at-declaration
    ''Changes: Use integer as key instead of string
    'Dim dayConvert As New Dictionary(Of Integer, Integer) From {{1, 5}, {2, 6}, {3, 7}, {4, 1}, {5, 2}, {6, 3}, {0, 4}} 'Dictionary to convert VB supplied day-of-the-week index to custom "Thursday index"
    '
    'Dim dayNumber As Integer = dayConvert(Date.Today.DayOfWeek)
    ''\\\

    'Source: https://stackoverflow.com/questions/5560019/vb-net-get-only-year-from-date
    'Source: https://stackoverflow.com/questions/12712300/get-the-week-number-of-the-year-counting-from-a-given-date-in-vb
    'Changes: Subtracted 2019 from current year to get index-based year

    Dim yearNumber As Integer = Date.Today.Year - 2019 'Index of years elapsed since 2019
    Dim weekNumber As Integer = DateTimeFormatInfo.CurrentInfo.Calendar.GetWeekOfYear(DateTime.Now, DateTimeFormatInfo.CurrentInfo.CalendarWeekRule, DayOfWeek.Thursday) 'Number of weeks elapsed (starting with Thursday).

    Dim rosterName As String = "Y" & yearNumber.ToString("D2") & "_W" & weekNumber.ToString("D2")

    Dim rosterSentNow As Boolean = False 'Has roster been sent in this program session
    Dim rosterSentWeek As Boolean 'Has roster been sent in the last week

    Dim rosterLastSentWeek As Integer = DateTimeFormatInfo.CurrentInfo.Calendar.GetWeekOfYear(My.Settings.rosterLastSent, DateTimeFormatInfo.CurrentInfo.CalendarWeekRule, DayOfWeek.Thursday)

    Dim rosterSuggestedExists As Boolean = File.Exists(ROSTERSUGGESTED)


    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        aboutProgram()
    End Sub

    Private Sub btnCloseApp_Click(sender As Object, e As EventArgs) Handles btnCloseApp.Click
        'check if save and close
        Application.Exit()
    End Sub

    Private Sub btnEditData_Click(sender As Object, e As EventArgs) Handles btnEditData.Click
        frmData.Show()
    End Sub

    Private Sub btnEditShifts_Click(sender As Object, e As EventArgs) Handles btnEditShifts.Click
        frmShifts.Show()
    End Sub

    Private Sub btnEditPIN_Click(sender As Object, e As EventArgs) Handles btnEditPin.Click
        InputBox("Enter current/old PIN for user-group " & "$$")
    End Sub

    Private Sub btnSendRoster_Click(sender As Object, e As EventArgs) Handles btnSendRoster.Click
        If MsgBox("Roster was successfully sent to the following employees:" & vbNewLine & vbNewLine & "Sample Person" & " (" & "email@provider.com" & ")" & vbNewLine & vbNewLine & "Roster sucessfully archived as week " & "## (##/##/##)." & vbNewLine & "No rosters were overwritten." & vbNewLine & vbNewLine & "Would you like to close the program?", MsgBoxStyle.YesNo, "Successfully Sent and Archived") = MsgBoxResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnSearchArchive_Click(sender As Object, e As EventArgs) Handles btnSearchArchive.Click
        frmSearch.Show()
    End Sub

    Private Sub picLogo_Click(sender As Object, e As EventArgs) Handles picLogoMain.Click
        aboutProgram()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Show/hide user-group-specific objects and functions
        '(Default values have been set in the object properties)

        'Check if roster has been sent within the week
        If weekNumber = rosterLastSentWeek Then
            rosterSentWeek = True
        Else
            rosterSentWeek = False
        End If

        If rosterSuggestedExists = True Then
            'Allow loading suggested roster only if it exists
            btnLoadSuggested.Enabled = True
        End If

        If userGroup = "Chef/Manager" Then
            btnSuggestRoster.Visible = True

            btnEditData.Visible = False
            btnEditShifts.Visible = False
            btnSearchArchive.Visible = False

            If rosterSentWeek = False Then
                btnSearchArchive.Enabled = False
            End If
        End If

        'LOAD EMPLOYEE AND SHIFT DATA

    End Sub

End Class
