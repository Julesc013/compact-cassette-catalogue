﻿' Name:             Global Variables and Subroutines
' Purpose:          Stores all the global varibales and subroutines used in multiple forms throughout the program.
' Author:           Jules Carboni
' Date Created:     29 May 2019
' Date Modified:    29 May 2019

Module globalVars

    'Decalare global variables

    Public Const VERSION As String = "Beta 1.3"
    Const MASTERKEY As String = "UiNdY9yIwt7F" 'Key used to encrypt data files
    Public FILEPATH As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\RosterSystem"

    Public userGroup As String


    'Declare global subroutines

    Sub aboutProgram()
        MsgBox("Blue Dog Cafe Rostering System" & vbNewLine & "Version " & VERSION & vbNewLine & "Jules Carboni, 2019" & vbNewLine & vbNewLine & "Program data and roster archive saved in:" & vbNewLine & FILEPATH, MsgBoxStyle.Information, "About Rostering System")
    End Sub

    Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

End Module
