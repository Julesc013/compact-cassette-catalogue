﻿' Name:             Shifts Entry
' Purpose:          Add/remove shift-blocks and save to the data store.
' Author:           Jules Carboni
' Date Created:     14 May 2019
' Date Modified:    16 May 2019

Public Class frmShifts
    Private Sub frmData_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class